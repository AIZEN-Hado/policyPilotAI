# PolicyPilot Runpod controls — proposed design, 2026-11-11

Status: design approved with black/graphite/mint at 60/30/10. Source implementation
has started; see IMPLEMENTATION_PLAN.md and deploy/GPU_WORKER.md. No resources
provisioned. Interview target is 2026-11-12, time not yet supplied. Synthetic data only.

## Outcome and recommendation

Use one dedicated queue-based Runpod Serverless endpoint controlled through the
authenticated PolicyPilot backend. Add Start model, Stop model, status, model
provenance and estimated compute cost to the existing workspace. GPU workers load
the chosen model; the user's computer needs only a browser.

Alternatives: ordinary Pods give direct machine control but add boot/SSH/storage
management. Always-warm Serverless workers avoid repeated cold starts but bill
continuously and need an independent expiry controller. Recommend scale-to-zero
Serverless for the first demo, with a five-minute idle window to reuse the loaded
model across nearby questions. This window is billable. It does not guarantee that
the model stays loaded for the entire browser session.

Default proposed configuration: minimum workers zero; maximum one when enabled,
zero when disabled; one request at a time; 300-second idle timeout; bounded job
execution and queue lifetime; 512 output tokens initially. Begin with a 24 GB
GPU group after reading current stock and rate. Quantized 7–9B sizing remains a
candidate, not a proven fit or quality result. This architecture would replace
the earlier under-2-GB model-process RAM target; confirm that scope change before
accepting a larger model as the final runtime. No GPU hardware is purchased.

## Website, data and document processing without a VPS

Propose a free Render web service for UI/API, an eligible free PostgreSQL database
for the short demonstration, and the existing private R2 document bucket within
its available allowance. No paid Render worker or model service. Free hosting can
sleep; the free Render database expires after 30 days. Verify account eligibility,
quota and access before committing to this path. Do not apply the current paid
render.yaml unchanged.

Move PDF extraction/OCR and inference into a custom Runpod queue handler. The API
generates short-lived, case-scoped download URLs for documents; the worker validates
the fixed storage host, byte/page limits and hashes, and removes temporary files.
Do not put R2 account credentials into jobs or expose model management credentials
to the browser. URLs may expire on a long queue delay: fail safely and refresh
only through an explicit retry, not an unbounded resubmission loop.

The handler returns bounded extracted pages, selected evidence and model output.
The API independently validates evidence/citations and stores the result in
PostgreSQL when polling observes job completion. Native PDF and OCR checks remain
required. Running OCR on the GPU worker also incurs billed worker time.

## Start / assess / stop

Start: acquire a database lock for the dedicated endpoint; reconcile its state;
enable at most one worker; read configuration back; submit one idempotent warm-up
job with no claim data. Warm-up loads and exercises the pinned model and returns
its artifact/release identity. Display Starting -> Loading -> Ready only after
actual successful output, never solely from /models registration. Store the job
ID and progress in PostgreSQL so refreshes do not launch another warm-up.

Assess: validate user and enabled state; create one durable application job;
submit once and save the provider job ID. Poll by ID; never resubmit on a client
timeout. The provider's own retry/restart behavior must be inspected and bounded;
handler execution must be idempotent. Use a server-owned request ID to reconcile
an uncertain submission instead of claiming exactly-once provider execution.
Account for every invocation attempt that may bill. Preserve current case-scoped
evidence rules and human-review notices. An idle worker can disappear while the
app remains enabled; the next request legitimately cold-starts it.

Stop: immediately block new submissions under the same lock; invalidate concurrent
start operations with a control generation/version; cancel only this application's
known outstanding jobs; set min/max to zero; read configuration back. Poll job and
worker state until confirmed quiescent. Confirm whether max-zero is supported by
the live API and how in-flight cancellation drains before shipping the control.
Display Stopping or Stop unconfirmed on delayed/failed verification, not Off.
Stopping never deletes stored claims or model artifacts. Worker termination can
lag the button press, and storage can continue billing after compute stops.

Multiple tabs share one workspace GPU. Stop therefore affects all its jobs;
show this explicitly and restrict controls to the operator. Do not expose generic
account-wide Runpod CRUD from the browser.

## Backend and UI changes

Add separate provider-control, job and cost-accounting modules. Keep management
and inference credentials separate where provider permissions allow it; restrict
the controller in code to its configured endpoint. No arbitrary endpoint IDs,
model URLs, prices or resource shapes from browser requests. All changes require
operator authorization and existing exact-Origin protection.

Proposed API: GET /api/model/status; POST /api/model/start; POST /api/model/stop;
GET /api/model/session; existing case assess/detail routes extended for job state.
PostgreSQL stores desired control state/version, owned endpoint ID, job IDs,
timestamps, active model revision/digests and usage estimates. Add an operator
permission rather than assuming any authenticated future reviewer can spend money.

Status labels: Off, Starting, Loading, Ready, Processing, Idle, Stopping, Error,
and Status unavailable. Separately show enabled/disabled and observed workers.
The UI displays the actual base/adapter revision, whether the artifact is fine-tuned,
time online and estimated cost. Estimate is not a provider invoice; reconcile
against available provider billing reads and retain an unknown state on read failure.
Do not poll generation endpoints as health checks.

## Costs and recovery

Preserve the strictly under-USD-2 cumulative training experiment limit. Proposed
per-answer allowances from discussion are estimates, not hard dollar caps or an
approved recurring budget. Obtain an explicit total inference/demo allowance before
paid verification. Bound requests/tokens/time; reserve startup, idle, termination,
storage and tax margin. Maximum one worker is not a spending cap.

Native scale-to-zero with minimum zero is the safety mechanism if the browser or
API disappears. No fake requests to keep a worker alive. An optional keep-warm
mode with minimum one is out of the first release until a separate durable
watchdog can enforce session expiry even when the web service is asleep/offline.
Browser tab closure alone must not be the shutdown mechanism.

On provider failure, keep admission closed, preserve job IDs, show recoverable
errors and reconcile before retrying. On backend restart, recover state from the
database and provider. Cancellation and cleanup requests may need bounded retries;
generation is never blindly retried. No frontend secrets or sensitive logs.

## Model artifact and training gates

No fine-tuned model currently exists. Freeze a narrow extraction/citation task and
review a varied synthetic dataset with splits by independent claim family. The
three existing exemplar bundles alone are insufficient. Record unchanged base
quality before a small QLoRA experiment. Select model and training settings against
the actual budget and GPU read; do not promise useful 7–9B fine-tuning under USD 2.

Export adapter, base revision, tokenizer/config, dataset provenance, environment
versions, training settings and held-out results. Verify hashes and reload saved
artifacts from independent storage before deleting training compute and temporary
storage. A Drive copy is an archive; the inference worker needs a reliably
retrievable versioned artifact, using private model hosting or a tested cached
image/storage path. A private registry/model host must be accessible at worker boot.
Never make weights public implicitly. Promote the fine-tuned release only if
checks pass; an unchanged base can be an explicitly labeled demo option, with no
silent substitution or invented fine-tuning claim.

## UI direction — added first priority

User brief: clean and futuristic, apparent three-dimensional depth drawn in 2D,
no WebGL, and a creative thinking orb for loading and chat. User approved the
black/graphite/mint direction. Follow the existing HTML/CSS/JavaScript stack; no framework rewrite.

Recommended direction: graphite surfaces, porcelain text, restrained mint light,
and consistent upper-left lighting. Use broad calm surfaces, crisp typography,
shallow bevels and soft contact shadows to create depth. Keep policy text and
citations highly readable. Alternatives are a porcelain/light studio direction or
a more technical dark instrument-panel direction; avoid decorative density.

Workspace layout: compact case/navigation rail, a central case-grounded conversation,
and a collapsible source/document drawer. A persistent compact model-control strip
shows actual worker state, model identity, session estimate and Start/Stop. Source
links remain usable while the model is off. Login and upload states share the same
visual system. Responsive mobile view uses a drawer for documents and citations.

Orb concept: a floating pearl-like core wrapped in offset ribbons and drifting
points. Use CanvasRenderingContext2D with projected point depth, radial shading,
occlusion and soft shadows. No WebGL, Three.js, shaders or 3D runtime dependency.
Use one shared animation loop; cap device pixel ratio, reduce detail on mobile,
pause hidden/off-screen canvases and respect reduced-motion preferences. Keep
forms, messages, buttons and status text in semantic HTML outside the canvas.

Map observable application states to visual motion: off is a still dim core;
startup assembles the ribbons; loading uses slow orbital motion; queued uses a
restrained pulse distinct from generation; generating uses flowing strands; a
verified result settles; stopping winds down; provider errors pause motion with
readable retry guidance. The animation never asserts hidden model reasoning or
uses invented completion percentages. Labels say what is actually known.

Use a larger orb for model startup and an empty conversation; use a small orb
beside the active assistant message. Avoid full-screen blockers after startup so
Stop, source inspection and navigation remain available. Never stretch an actual
loading operation to show an animation, or animate an error indefinitely.

Case chat is new functionality, not present in the existing review-draft interface.
Add persisted case-scoped messages, evidence-bounded prompts, source citations and
job ownership. Bind each answer to a document snapshot and model revision; uploads
mark older answers stale. Reuse citation validation. Do not imply streaming until
the selected worker transport actually supports and verifies it. Use whole-answer
delivery first if needed for tomorrow's deadline; do not fabricate a token stream.

Work order: approve the visual direction; build/review the UI states with clearly
labeled preview data and no paid side effects; preserve existing upload/review
flows; then connect the real controls and implement case chat. Preview controls
must not claim the GPU started or stopped. Check keyboard/focus, readability,
reduced motion, small screens, errors and long messages before integration.

## Implementation order and acceptance

1. Prioritize the UI direction and states above. Restore Runpod access in parallel
   where possible; verify the hosting connections and current inventory.
2. Validate the deployment path and container dependencies. Freeze artifact schema
   and reviewable handler input/output contracts before provisioning paid compute.
3. Add migrations, controller, operator permissions and lifecycle/job tests.
4. Implement the bounded OCR/model handler and idempotent submission/result path.
5. Add UI controls, polling, model provenance and honest cost/worker states.
6. Verify model artifacts, provision one endpoint, read all settings back, and
   execute one budgeted synthetic request before broader checks.
7. Test native and scanned PDFs, citations, start/stop/restart, duplicated clicks,
   multiple tabs, unauthenticated/forged controls, queue failure and browser closure.
   Verify zero workers after stop and native idle scale-down. Record startup/warm
   latency and costs. No successful release claim if HTTP tests are skipped.
8. Rehearse the interview flow; start/warm explicitly shortly before it. Keep an
   operator recovery runbook. Fine-tuning is a separate gated track and must not
   destabilize the verified application immediately before the demonstration.

Current blockers: shell DNS prevents Runpod account reads; API packages/Docker
execution remain unavailable locally; no verified live host, model endpoint or
fine-tuned artifact exists. No billable work was started for this plan.

References checked:
- https://docs.runpod.io/serverless/endpoints/endpoint-configurations
- https://docs.runpod.io/serverless/endpoints/send-requests
- https://docs.runpod.io/serverless/pricing
- https://render.com/docs/free
