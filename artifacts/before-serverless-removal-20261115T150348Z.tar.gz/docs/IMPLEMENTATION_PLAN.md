# PolicyPilot implementation sequence — 2026-11-11

## Current authorization — one additional dollar for compiler-fixed verification

User explicitly adds USD 1 for this work on 2026-11-15. The total planning ceiling
is now $2.99 (previous $1.99 plus $1), with $2 inference allowance: $1.70 compute
and the existing $0.30 overhead provision. All previous spend and $0.678335
reservations remain counted; do not release more closed holds or reset the ledger.
This supersedes the earlier numerical caps below. Synthetic-only data, RAM target,
artifact verification and cleanup requirements persist. No new training compute
or additional automatic retries are authorized by this budget increment.

The compiler-fixed GPU image is uploaded/applied and read-back verified at
2026-11-15T14:37:46Z, digest 537c877f3c2fce36265cf360f4e9ff8e2ff92d19fe81680e5a55313672a105c2.
Reported account spend at 14:38:54Z is $0.6198162269574823 and may lag. The new
allowance is authorized but not yet verified/applied in Render/database.

Deploy RUNPOD_SESSION_COMPUTE_LIMIT_USD=1.70 in Render, with model controls and
budget approval enabled. Use extend_inference_budget.py --apply once: it requires
matching live app/database/off state, complete receipts and prior audit, the
closed known compiler-failure job, current billing and fresh provider idle reads.
It changes only the two database limits and adds an idempotent audit event;
reservations/jobs stay intact. After verified commit it records the explicit
authorization in local setup state. Repeating it cannot grant another dollar.

Only then use rehearse_model.py --run-warmup --compiler-fix. It requires that
committed budget receipt and exact reviewed compiler image, uses a fresh no-repeat
report and the existing six-minute watchdog, and reserves $0.118750, cumulative
$0.797085. Stop and freshly verify provider/app shutdown. Preserve every previous
attempt report. If this corrected-image test fails, no blind paid retry is allowed.

## Previous authorization — compiler repair before the dollar extension

The user subsequently asks to fix the known error one last time. This supersedes
the historical retirement instruction below for this narrow repair. Add GCC/C
headers to the GPU image and set CC explicitly. Prove Triton's own C-extension
build/load path offline as the non-root worker user before publishing or any
GPU job. Preserve pinned model/library versions, prior artifacts and the original
under-$2 total / $1 inference / $0.70 compute limits. Do not reset reservations.

The compiler layer belongs after the existing large pip dependency layer so a
cached build can reuse PyTorch/CUDA downloads. GPU image publication and a stopped
image-only update remain separate from a paid generation test. New paid work must
fit current billed spend and retained reservations, use a fresh one-run report
and preserve watchdog/shutdown safeguards. The old loader-diagnostic report is
already consumed and must not be overwritten or bypassed. No budget expansion,
replacement endpoint, successful generation or RAM result is implied by the fix.

## Historical decision — Serverless abandoned, fine-tuning pivot

The final authorized attempt failed. The user explicitly confirms that Serverless
will no longer be continued. Do not repair its image, add its missing compiler,
build/publish another Serverless worker, issue another test job, recreate its
endpoint or increase its budget. The historical final-attempt authorization below
is spent and no longer authorizes a run. Existing reports and artifacts are evidence.

Read runpod-warmup-loader-diagnostic.json: generation=false, provider/app shutdown
verified=true, failure at check_quantizer with RuntimeError: Failed to find C
compiler. Please specify via CC environment variable. Trusted frames locate the
bitsandbytes/Triton import path. This establishes an environment dependency failure
for this final attempt, not the cause of every previous failure. Actual generation,
fine-tuning and full model-process memory remain unverified.

Latest reported account charge is $0.6198162269574823 and may lag. Cumulative
compute reservations are $0.678335; do not mistake these for actual billed spend
or erase them to fund new jobs. The original under-$2 total, synthetic-only data
and <2,000,000,000-byte model-process RAM target persist. No budget extension or
new training compute is authorized by abandoning Serverless.

Render follow-through: set ENABLE_MODEL_CONTROL=0 on the existing service and
save/deploy so the retired provider cannot be started from the browser. Do not
change database/auth/storage settings or describe this manual change as completed
until verified. The last provider/app shutdown is already verified. No training
compute or persistent model volume exists to delete at this checkpoint.

The fine-tuning work begins with the previously approved synthetic-data and
evaluation design in SYNTHETIC_DATA_SPEC.md and PHASE_0_EVALUATION_PROTOCOL.md.
There are only three development exemplar cases today; they are not a held-out
benchmark or a sufficient basis for an extreme-accuracy claim. Build and review
independent case families, split before expanding variants, retain canonical
labels outside inference inputs, and compare a frozen base against the tuned
candidate on JSON validity, supported facts/quotes, missing-evidence abstention
and adversarial cases. Keep the final acceptance split out of selection/tuning.

Choose a separate training environment only after current spend, remaining
allowance, model licensing and measured baseline/memory constraints are resolved.
Training does not itself provide hosted inference. No model size/platform switch
or successful fine-tune is implied by this pivot. Save/hash/independently reload
training artifacts before deleting dedicated training compute/temporary storage.
Keep the working authenticated Render application as the interview priority.

## Historical authorization — final Serverless attempt, now consumed

The user permits exactly one final Serverless attempt using the reviewed
5c4c20537587ab0317ac7515b7fcf94f9d5e1cd0abfa983c52783ed10f7e733e GPU image.
Use only the prepared --paused-hold settlement and --loader-diagnostic rehearsal.
Keep the original under-$2 overall limit, $1 inference allowance, $0.70 compute
cap, synthetic-only data and under-2,000,000,000-byte process-RAM target. The
settlement is accounting for a closed padded time bound, not a budget increase.

The last reviewed local artifacts show no paused-hold settlement and no final
loader-diagnostic attempt yet. Its run-once report guard and six-minute watchdog
are already implemented. A clean success requires verified generation and both
provider/app shutdown; billing and memory claims remain bounded by actual evidence.
If setup, preflight or execution fails, do not prolong Serverless troubleshooting,
create a replacement endpoint, issue another paid probe or increase allowances.
Finish necessary shutdown verification and retain logs/reports, then abandon this
deployment approach. Recovery actions may only stop/verify the existing resource;
they must not start more compute. The live Render application remains the priority.

After failure, pivot to a separate fine-tuning workflow using synthetic training
families and held-out evaluation, targeting measurable accuracy/citation validity/
abstention behavior. Do not promise extreme accuracy, imply it has been achieved,
or start training beyond remaining approved funds. Choose the training/execution
environment after the final outcome and current spend are known; do not assume
fine-tuning fixes the observed loader issue. Save/hash/independently reload model
artifacts before deleting dedicated training compute and temporary storage.

The user approved building the interface and app-managed Runpod design, with a
60/30/10 black/graphite/mint palette. This file tracks implementation, not deployment.

1. **UI first:** preserve current case/upload/review flows; add the dark palette,
   dimensional Canvas 2D orb, model console and case conversation. Cover empty,
   loading, disabled, failure and reduced-motion states. Never simulate live GPU state.
2. **Provider transport:** fixed configured endpoint only; server-side credentials;
   bounded no-redirect HTTPS control/invocation calls; job status/cancel operations;
   no automatic generation retry. Validate provider replies before recording state.
3. **Durable controls:** migrations for control generation, desired state and jobs;
   serialized start/stop, uncertain submissions retained, provider read-back, real
   warm-up proof and verified shutdown. Controls gated by operator identity and
   explicit configured inference allowance. Keep native minimum-zero scale-down.
4. **Conversation:** persisted case messages; case evidence and document hashes;
   independently validated citations; snapshot changes invalidate old answers;
   bounded questions, outputs and one job at a time. No fake token streaming.
5. **Remote processing:** custom queue handler for warm-up, extraction/OCR and
   inference; model/base/adapter identity; bounded temporary PDF handling and
   cleanup; case-scoped signed storage downloads, no broad credentials in jobs.
6. **Free hosting adaptation:** replace the paid Render worker topology with
   UI/API plus eligible temporary free database; R2 for documents; process jobs on
   Runpod. Validate quotas, account access and model artifact retrieval first.
7. **Fine-tune separately:** reviewed synthetic family splits, unchanged-base
   evaluation, small budgeted experiment, export and verify artifacts, independent
   reload, then delete training compute/storage. Do not claim a fine-tune exists.
8. **Live verification:** run all HTTP tests without skips, build image, native and
   scanned PDF flow, refresh/race/error tests, observed stop/idle shutdown, measured
   latency and billing, browser desktop/mobile review. Rehearse interview workflow.

No GPU is provisioned by these edits. The strict under-USD-2 training experiment
budget remains. A total inference allowance, reachable Runpod access and hosting
access are release prerequisites; the larger model's memory requirement must be
explicitly resolved rather than claiming it meets the original 2 GB target.

Current environment: Runpod access rechecked and failed on network/DNS; API
dependencies unavailable; no verified model artifact or endpoint. Git metadata is
inaccessible here, so source edits and documentation cannot be committed locally.

## Progress at this checkpoint

- UI/theme/orb, control transport, migrations, API routes, persisted case chat,
  remote assessment validation and queue handler are authored.
- `render-demo.yaml` and the GPU worker build/handoff files are authored, unbuilt
  and unprovisioned. Controls remain disabled by default.
- 63 tests passed; 20 HTTP tests skipped. Syntax checks passed. Browser launch was
  blocked by sandbox socket permissions. The source package and offline UI preview
  are saved, with source archive verification.
- Outstanding: provider compatibility/permission checks, clean Docker installs,
  PostgreSQL and browser integration, actual free hosting deployment, real warm-up
  and start/stop verification, cost accounting/cutoffs, durable free-topology file
  cleanup, and the entire separately budgeted fine-tuning/artifact track.

## Follow-up checkpoint

- Added activity-driven, bounded object cleanup and an operator queue/retry view;
  intent survives restarts and retries resume on later app activity. No independent
  scheduler runs while free hosting sleeps.
- Invalid remote output now records terminal failure; assessment submission locks
  the case so uploads cannot race the initial document snapshot/state transition.
- Added verified-rate wall-time estimates, a per-session admission check, and a
  cumulative demo inference reservation ledger that never resets on Start/Stop.
- User approved USD 1 inference within the original under-USD-2 total. Reserve USD
  0.70 for compute plus USD 0.30 overhead; remaining training/overhead maximum USD
  0.99. No paid work started; live rate and billing enforcement remain unverified.
- 95 tests discovered: 75 pass, 20 HTTP tests skip. Deployment and fine-tuning
  remain blocked by missing provider/dependency access. No hard spending-cap claim.
