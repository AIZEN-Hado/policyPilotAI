"""Dependency-free evidence selection and output validation."""
import re

KINDS = {'policy', 'schedule', 'endorsement', 'bill', 'discharge', 'receipt', 'other'}

def make_chunks(documents):
    chunks = []
    for doc in documents:
        for page in doc['pages']:
            text = page['text'].strip()
            for start in range(0, len(text), 1050):
                part = text[start:start+1200]
                if part.strip():
                    chunks.append({'id': f"{doc['id']}:p{page['page']}:c{start//1050}",
                                   'document_id': doc['id'], 'filename': doc['filename'],
                                   'kind': doc['kind'], 'page': page['page'], 'text': part})
    return chunks


def select_evidence(chunks, query, limit=12000):
    """Transparent lexical baseline with document coverage; never global search."""
    terms = set(re.findall(r'\w{3,}', query.lower()))
    ranked = sorted(chunks, key=lambda x: len(terms & set(re.findall(r'\w{3,}', x['text'].lower()))), reverse=True)
    selected, used, total = [], set(), 0
    # Represent every document before adding extra high-scoring chunks.
    first = []
    docs = set()
    for chunk in ranked:
        if chunk['document_id'] not in docs:
            docs.add(chunk['document_id']); first.append(chunk)
    for chunk in first + ranked:
        if chunk['id'] in used or total + len(chunk['text']) > limit:
            continue
        selected.append(chunk); used.add(chunk['id']); total += len(chunk['text'])
    return selected, len(selected) < len(chunks)


def validate_output(raw, evidence, truncated=False):
    if not isinstance(raw, dict):
        raise ValueError('Output must be an object')
    sources = {e['id']: e for e in evidence}
    findings = raw.get('findings')
    if not isinstance(findings, list) or len(findings) > 12:
        raise ValueError('Invalid findings')
    valid = []
    for item in findings:
        if not isinstance(item, dict): raise ValueError('Invalid finding')
        source = sources.get(item.get('source_id'))
        quote = item.get('quote', '')
        statement = item.get('statement', '')
        if not isinstance(quote, str) or not 12 <= len(quote) <= 800:
            raise ValueError('Invalid quotation')
        if source is None or ' '.join(quote.split()) not in ' '.join(source['text'].split()):
            raise ValueError('Unsupported citation')
        if not isinstance(statement, str) or not 1 <= len(statement) <= 1200:
            raise ValueError('Invalid finding text')
        valid.append({'statement': statement, 'quote': quote, 'source_id': source['id'],
                      'document_id': source['document_id'], 'filename': source['filename'], 'page': source['page']})
    questions = raw.get('questions', [])
    if not isinstance(questions, list) or len(questions)>12 or any(not isinstance(q,str) or not 1<=len(q)<=1000 for q in questions):
        raise ValueError('Invalid questions')
    summary = raw.get('summary', '')
    if not isinstance(summary,str) or not 1 <= len(summary) <= 2400:
        raise ValueError('Invalid summary')
    if truncated:
        questions = ['Only selected excerpts fit the model context. Review all original documents before deciding.'] + questions
    return {'status': 'REVIEW_REQUIRED' if valid else 'REQUIRES_MORE_INFO', 'summary': summary,
            'findings': valid, 'questions': questions, 'context_truncated': truncated,
            'notice': 'AI draft. Quoted text is checked against supplied excerpts; interpretation and completeness require human verification. No payable amount or final coverage decision is authorized.'}
