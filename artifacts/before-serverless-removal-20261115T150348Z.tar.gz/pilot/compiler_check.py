"""Offline Triton C-extension build check; no GPU, model download or credentials."""
import importlib.util
import os
from pathlib import Path
import shutil
import tempfile

SOURCE=r'''
#include <Python.h>
#include <stdint.h>
static PyObject *answer(PyObject *self, PyObject *args) {
    int32_t value = 42;
    return PyLong_FromLong(value);
}
static PyMethodDef methods[] = {
    {"answer", answer, METH_NOARGS, "Synthetic compiler check"},
    {NULL, NULL, 0, NULL}
};
static struct PyModuleDef definition = {
    PyModuleDef_HEAD_INIT, "_policypilot_compiler_probe", NULL, -1, methods
};
PyMODINIT_FUNC PyInit__policypilot_compiler_probe(void) {
    return PyModule_Create(&definition);
}
'''


def check_compiler():
    chosen=os.environ.get('CC')
    if chosen is None:chosen=shutil.which('gcc') or shutil.which('clang')
    if not chosen or not shutil.which(chosen):
        raise RuntimeError('C compiler unavailable; the worker image requires GCC and C headers')
    # Exercise the same build helper that emitted the captured Triton error.
    # This extension uses Python/C headers, but no CUDA headers or GPU driver.
    from triton.runtime.build import _build
    with tempfile.TemporaryDirectory(prefix='policypilot-compiler-') as directory:
        source=Path(directory)/'probe.c';source.write_text(SOURCE)
        name='_policypilot_compiler_probe'
        try:
            binary=_build(name,str(source),directory,[],[],[])
            spec=importlib.util.spec_from_file_location(name,binary)
            if spec is None or spec.loader is None:raise RuntimeError('Compiler probe extension was not loadable')
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            if module.answer()!=42:raise RuntimeError('Compiler probe returned an invalid result')
        except (OSError,ImportError) as exc:
            raise RuntimeError('Triton C-extension build/load check failed') from exc


if __name__=='__main__':
    check_compiler()
    print('PASS: Triton compiled and loaded a synthetic Python C extension; result=42. No GPU or model used.')
