"""Explicit inference transports. No fallback, redirects, tools or prompt logging."""
import json
import re


def runpod_base(endpoint_id):
    if not re.fullmatch(r'[A-Za-z0-9_-]{3,80}', endpoint_id):
        raise ValueError('Invalid Runpod endpoint ID')
    return f'https://api.runpod.ai/v2/{endpoint_id}/openai/v1'


def runpod_payload(model, system, prompt, schema):
    return {'model':model, 'stream':False, 'temperature':0, 'max_tokens':1300,
            'messages':[{'role':'system','content':system + '\nJSON schema:\n' + json.dumps(schema)},
                        {'role':'user','content':prompt}]}


def parse_chat(response):
    choices = response.get('choices')
    if not isinstance(choices, list) or len(choices) != 1:
        raise ValueError('Expected one model response')
    choice = choices[0]
    if choice.get('finish_reason') != 'stop':
        raise ValueError('Model response did not finish normally')
    message = choice.get('message', {})
    if message.get('tool_calls') or message.get('refusal'):
        raise ValueError('Model returned an unsupported response')
    content = message.get('content')
    if not isinstance(content, str) or len(content) > 50000:
        raise ValueError('Invalid model content')
    value = json.loads(content)
    if not isinstance(value, dict):
        raise ValueError('Model JSON must be an object')
    return value


def runpod_generate(endpoint, token, model, system, prompt, schema, client=None):
    url = runpod_base(endpoint) + '/chat/completions'
    if not token:
        raise ValueError('Runpod inference credential required')
    if client is None:
        import httpx
        with httpx.Client(timeout=httpx.Timeout(300,connect=10),trust_env=False,
                          follow_redirects=False) as transport:
            return runpod_generate(endpoint, token, model, system, prompt, schema, transport)
    # Intentionally no retries: a timed-out request may already have incurred work.
    response = client.post(url, headers={'Authorization':'Bearer '+token},
                           json=runpod_payload(model,system,prompt,schema))
    response.raise_for_status()
    return parse_chat(response.json())


def generate(system, prompt, schema):
    from . import config
    if config.INFERENCE_BACKEND == 'runpod':
        return runpod_generate(config.RUNPOD_ENDPOINT_ID, config.RUNPOD_INFERENCE_KEY,
                               config.MODEL, system, prompt, schema)
    import httpx
    with httpx.Client(timeout=httpx.Timeout(300,connect=10),trust_env=False,
                      follow_redirects=False) as client:
        r=client.post(config.OLLAMA_URL+'/api/generate',json={
            'model':config.MODEL,'stream':False,'format':schema,'system':system,
            'prompt':prompt,'options':{'temperature':0,'num_ctx':8192,'num_predict':1300},
            'keep_alive':'5m'})
        r.raise_for_status()
        response=r.json()
        if response.get('done_reason')=='length':
            raise ValueError('Model output truncated')
        return json.loads(response['response'])
