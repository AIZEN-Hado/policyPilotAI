# PolicyPilot live pilot

A separate, restricted live application. It leaves the legacy `app/` and Streamlit
prototype untouched. No prepared model results are used in this interface.

Start with the [NixOS setup](../docs/NIXOS_DEVELOPMENT.md) and
[phased Render plan](../docs/RENDER_RELEASE_PLAN.md). Render adaptation is in progress;
the existing [Hostinger runbook](../deploy/HOSTINGER_RUNBOOK.md) describes the older
VPS deployment, which is currently set aside. See [verification record](VERIFICATION.md)
for what has and has not run in the authoring environment.

## Implemented

The black/graphite/mint interface, 2D orb, operator model controls and case chat
source are now implemented. The [GPU worker handoff](../deploy/GPU_WORKER.md)
describes the disabled-by-default controls, remote job contract, free demo topology
and remaining live checks. This build has not been deployed or GPU-tested.

Browser session login and a Render Blueprint are now prepared. See
[Render release instructions](../deploy/RENDER_RUNBOOK.md) for configuration,
the failed local release gate, and the remaining inference/deployment blockers.
This is not yet a verified live release.

Private local/S3 document adapters and durable object cleanup are now implemented.
See [storage configuration and limitations](STORAGE.md) before changing backends.

- Responsive dashboard, case creation, typed PDF upload, processing status, extracted
  text inspection, source-page navigation, original download, review acknowledgement
  and active-case deletion.
- PostgreSQL records, document hashes, case-scoped evidence and persistent processing
  states. A single worker recovers interrupted processing after restart.
- Native PDF extraction and local OCR fallback with bounded subprocess resources.
- Private Ollama structured-output request, exact source-quote checks, explicit partial
  context and human-review notices. No payout calculation or final coverage decision.
- HTTPS proxy authentication, same-origin mutation checks, no public DB/model port,
  internal runtime network, separate model-provisioning network and secret generator.

This is a shared single-organization pilot, not a completed multi-tenant production
platform. Use synthetic data until deployment/security/domain gates are met. The shared
login is not enterprise identity; the app's event table is not a tamper-proof audit store.

## Development checks

```sh
python -m unittest discover -s pilot/tests -v
node --check pilot/static/app.js
python scripts/dev/check.py --require-docker
```

API-boundary tests skip explicitly if required API packages are absent. They run in the
built image during `deploy/start.sh`. PostgreSQL integration, actual OCR/model inference,
restart recovery and browser behavior require the target environment and live smoke test.
