import hashlib
import hmac
import json
import os
import uuid
import tempfile
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from . import config
from .core import KINDS
from .db import connect
from .storage import get_storage, materialize
from . import auth
from . import model_service
from .runpod_control import ProviderError
from .storage_cleanup import cleanup_pending,cleanup_tick

app = FastAPI(title='PolicyPilot private pilot', docs_url=None, redoc_url=None, openapi_url=None)
STATIC = Path(__file__).parent/'static'

class TemporaryFileResponse(FileResponse):
    def __init__(self, document, path, **kwargs):
        super().__init__(path, **kwargs)
        self.document = document

    async def __call__(self, scope, receive, send):
        try:
            await super().__call__(scope, receive, send)
        finally:
            self.document.__exit__(None,None,None)

@app.middleware('http')
async def boundary(request: Request, call_next):
    try:
        response=await authorize(request,call_next)
    except Exception:
        # No request bodies, filenames, model output or exception strings in logs.
        response=JSONResponse({'detail':'Service unavailable. Retry or contact the operator.'},status_code=503)
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Strict-Transport-Security']='max-age=31536000'
    response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-src 'self'; frame-ancestors 'self'; base-uri 'none'; form-action 'self'"
    return response

async def authorize(request,call_next):
    if request.method not in {'GET','HEAD','OPTIONS'} and request.headers.get('origin') != config.APP_ORIGIN:
        return JSONResponse({'detail':'Origin rejected'},status_code=403)
    if config.AUTH_MODE == 'session':
        public_get = request.method in {'GET','HEAD'} and request.url.path in {
            '/login','/login.js','/login.css','/style.css','/theme.css','/healthz'}
        public_login = request.method == 'POST' and request.url.path == '/api/auth/login'
        if not public_get and not public_login:
            user=await run_in_threadpool(auth.current_user,request.cookies.get(auth.COOKIE,''),
                                        connect,config.PILOT_USER,config.PILOT_PASSWORD_HASH)
            if not user:
                if request.method in {'GET','HEAD'} and request.url.path == '/':
                    return RedirectResponse('/login',status_code=303)
                return JSONResponse({'detail':'Authentication required'},status_code=401)
            request.state.reviewer=user
    else:
        token=request.headers.get('x-proxy-token','')
        if not hmac.compare_digest(token.encode(),config.PROXY_TOKEN.encode()):
            return JSONResponse({'detail':'Authentication required'},status_code=401)
    return await call_next(request)

def actor(request):
    if config.AUTH_MODE == 'session':
        return request.state.reviewer
    return request.headers.get('x-reviewer','pilot-reviewer')[:80]

@app.get('/healthz')
def healthz():
    with connect() as conn: conn.execute('SELECT 1')
    return {'status':'ok'}

@app.get('/login')
def login_page():
    if config.AUTH_MODE != 'session': raise HTTPException(404)
    return FileResponse(STATIC/'login.html')

@app.post('/api/auth/login')
async def login(request:Request):
    if config.AUTH_MODE != 'session': raise HTTPException(404)
    if request.headers.get('content-type','').split(';')[0] != 'application/json':
        raise HTTPException(415,'JSON required')
    body=bytearray()
    async for chunk in request.stream():
        if len(body)+len(chunk)>8192: raise HTTPException(413,'Login request too large')
        body.extend(chunk)
    try:
        values=json.loads(body)
        username,password=values['username'],values['password']
        if not isinstance(username,str) or not isinstance(password,str) or len(username)>80 or len(password)>1024:
            raise ValueError()
        username.encode('utf-8'); password.encode('utf-8')
    except (ValueError,TypeError,KeyError):
        raise HTTPException(422,'Username and password required')
    token,error=await run_in_threadpool(auth.login,username,password,connect,
                                      config.PILOT_USER,config.PILOT_PASSWORD_HASH)
    if error:
        return JSONResponse({'detail':'Too many attempts. Try again in 15 minutes.' if error=='throttled'
                             else 'Invalid username or password'},
                            status_code=429 if error=='throttled' else 401)
    response=JSONResponse({'status':'signed_in'})
    response.set_cookie(auth.COOKIE,token,max_age=auth.SESSION_SECONDS,
                        secure=True,httponly=True,samesite='strict',path='/')
    return response

@app.post('/api/auth/logout',status_code=204)
def logout(request:Request):
    if config.AUTH_MODE != 'session': raise HTTPException(404)
    auth.logout(request.cookies.get(auth.COOKIE,''),connect)
    response=Response(status_code=204)
    response.delete_cookie(auth.COOKIE,secure=True,httponly=True,samesite='strict',path='/')
    return response

@app.get('/api/auth/me')
def me(request:Request):
    return {'username':actor(request),'auth_mode':config.AUTH_MODE,'model_operator':is_operator(request)}

def is_operator(request):
    # Session-only controls: never grant paid resource access from spoofable headers.
    return (config.AUTH_MODE=='session' and bool(os.environ.get('MODEL_OPERATOR'))
            and actor(request)==os.environ['MODEL_OPERATOR'])

def require_operator(request):
    if not is_operator(request): raise HTTPException(403,'Model operator access required')

@app.get('/api/model/status')
def model_status(request:Request,background:BackgroundTasks):
    if os.environ.get('PROCESSING_BACKEND')=='runpod': background.add_task(cleanup_tick)
    try: result=model_service.status(connect)
    except ProviderError:
        return JSONResponse({'configured':model_service.configured(),'state':'unavailable',
                             'detail':'Provider status unavailable. Shutdown or readiness has not been confirmed.'},status_code=503)
    result['operator']=is_operator(request)
    return result

@app.get('/api/storage/cleanup')
def cleanup_status(request:Request):
    require_operator(request)
    with connect() as conn:
        return conn.execute('SELECT count(*) AS pending, '
                            'count(*) FILTER (WHERE eligible_at<=now()) AS eligible FROM storage_cleanup').fetchone()

@app.post('/api/storage/cleanup')
def cleanup_retry(request:Request):
    require_operator(request)
    # One bounded pass. Failed objects retain their retry timestamp and intent.
    return cleanup_pending(batch_size=1)

@app.post('/api/model/start',status_code=202)
def model_start(request:Request):
    require_operator(request)
    try: model_service.start(connect)
    except ProviderError as exc: raise HTTPException(409,str(exc))
    return {'state':'loading'}

@app.post('/api/model/stop',status_code=202)
def model_stop(request:Request):
    require_operator(request)
    try: model_service.stop(connect)
    except ProviderError as exc: raise HTTPException(503,str(exc))
    return {'state':'stopping','detail':'Refresh status to confirm workers have stopped'}

class ChatQuestion(BaseModel):
    question: str = Field(min_length=8,max_length=1200)

@app.get('/api/cases/{cid}/messages')
def messages(cid:uuid.UUID):
    with connect() as conn:
        get_case(conn,cid)
        docs=conn.execute('SELECT id,sha256 FROM documents WHERE case_id=%s',(cid,)).fetchall()
        snap=model_service.snapshot(docs)
        rows=conn.execute('SELECT id,question,response,state,snapshot,created_at FROM case_messages '
                          'WHERE case_id=%s ORDER BY id LIMIT 100',(cid,)).fetchall()
        for row in rows:
            row['stale']=row.pop('snapshot')!=snap
        return rows

@app.post('/api/cases/{cid}/messages',status_code=202)
def ask_case(cid:uuid.UUID,body:ChatQuestion,request:Request):
    require_operator(request)
    with connect() as conn:
        get_case(conn,cid)
        if conn.execute('SELECT count(*) AS n FROM case_messages WHERE case_id=%s',(cid,)).fetchone()['n']>=100:
            raise HTTPException(409,'Conversation limit reached')
    if len(body.question.strip())<8: raise HTTPException(422,'Ask a longer question')
    try: return model_service.chat(connect,cid,body.question.strip())
    except ProviderError as exc: raise HTTPException(409,str(exc))
def get_case(conn,cid,lock=False):
    row=conn.execute('SELECT * FROM cases WHERE id=%s'+(' FOR UPDATE' if lock else ''),(cid,)).fetchone()
    if not row: raise HTTPException(404,'Case not found')
    return row

def event(conn,cid,action,user):
    conn.execute('INSERT INTO events(case_id,action,actor) VALUES(%s,%s,%s)',(cid,action,user))

class NewCase(BaseModel):
    title: str = Field(min_length=3,max_length=120)
    description: str = Field(min_length=20,max_length=3000)

@app.get('/api/health')
def health():
    with connect() as conn: conn.execute('SELECT 1')
    return {'status':'ok','mode':'single-workspace pilot'}

@app.get('/api/readiness')
def readiness():
    with connect() as conn: conn.execute('SELECT 1')
    if os.environ.get('PROCESSING_BACKEND')=='runpod':
        try:
            state=model_service.status(connect)
            return {'database':'ready','inference':state['state'],'model':state.get('model')}
        except ProviderError:
            return JSONResponse({'database':'ready','inference':'unavailable'},status_code=503)
    if config.INFERENCE_BACKEND == 'runpod':
        from .inference import runpod_base
        try:
            with httpx.Client(timeout=10,trust_env=False,follow_redirects=False) as client:
                r=client.get(runpod_base(config.RUNPOD_ENDPOINT_ID)+'/models',
                             headers={'Authorization':'Bearer '+config.RUNPOD_INFERENCE_KEY})
                r.raise_for_status()
                models=[m['id'] for m in r.json().get('data',[])]
                return JSONResponse({'database':'ready','model':config.MODEL,
                    'inference':'model_registered_not_generation_tested' if config.MODEL in models else 'model_missing'},
                    status_code=200 if config.MODEL in models else 503)
        except Exception:
            return JSONResponse({'database':'ready','inference':'unavailable'},status_code=503)
    try:
        r=httpx.get(config.OLLAMA_URL+'/api/tags',timeout=5); r.raise_for_status()
        models=[m['name'] for m in r.json().get('models',[])]
        ready=config.MODEL in models or config.MODEL+':latest' in models
        return {'database':'ready','model':config.MODEL,'inference':'ready' if ready else 'model_missing'}
    except Exception:
        return JSONResponse({'database':'ready','inference':'unavailable'},status_code=503)

@app.post('/api/cases',status_code=201)
def create_case(body:NewCase,request:Request):
    cid=uuid.uuid4()
    with connect() as conn:
        if conn.execute('SELECT count(*) AS n FROM cases').fetchone()['n']>=100:
            raise HTTPException(409,'Pilot case limit reached; delete unused cases first')
        conn.execute('INSERT INTO cases(id,title,description) VALUES(%s,%s,%s)',(cid,body.title.strip(),body.description.strip()))
        event(conn,cid,'case_created',actor(request))
    return {'id':str(cid)}

@app.get('/api/cases')
def cases(background:BackgroundTasks):
    if os.environ.get('PROCESSING_BACKEND')=='runpod': background.add_task(cleanup_tick)
    with connect() as conn:
        return conn.execute('SELECT id,title,state,created_at,updated_at FROM cases ORDER BY created_at DESC LIMIT 100').fetchall()

@app.get('/api/cases/{cid}')
def detail(cid:uuid.UUID):
    with connect() as conn:
        row=get_case(conn,cid)
        row['documents']=conn.execute('SELECT id,filename,kind,bytes,pages FROM documents WHERE case_id=%s ORDER BY filename',(cid,)).fetchall()
        row['events']=conn.execute('SELECT action,actor,created_at FROM events WHERE case_id=%s ORDER BY id DESC LIMIT 30',(cid,)).fetchall()
        return row

@app.put('/api/cases/{cid}/documents',status_code=201)
async def upload(cid:uuid.UUID,request:Request,kind:str,filename:str):
    if kind not in KINDS: raise HTTPException(422,'Choose a supported document type')
    filename=Path(filename.replace('\\','/')).name[:120]
    if not filename.lower().endswith('.pdf'): raise HTTPException(415,'Upload a PDF, including scanned PDFs')
    if request.headers.get('content-type','').split(';')[0]!='application/pdf': raise HTTPException(415,'PDF content type required')
    did=uuid.uuid4(); staging=tempfile.TemporaryDirectory(prefix='claim-upload-')
    path=Path(staging.name)/'upload.pdf'; size=0; digest=hashlib.sha256(); head=b''
    try:
        with path.open('xb') as output:
            os.chmod(path,0o600)
            async for chunk in request.stream():
                size+=len(chunk)
                if size>config.MAX_FILE: raise HTTPException(413,'Maximum PDF size is 10 MB')
                head=(head+chunk)[:8]; digest.update(chunk); output.write(chunk)
        if not head.startswith(b'%PDF-') or size<20: raise HTTPException(415,'Invalid PDF signature')
        # Persist cleanup intent before touching object storage. A killed process or
        # uncertain DB commit cannot leave an untracked object indefinitely.
        with connect() as conn:
            conn.execute('INSERT INTO storage_cleanup(document_id) VALUES(%s)',(did,))
        with connect() as conn:
            conn.execute('SELECT document_id FROM storage_cleanup WHERE document_id=%s FOR UPDATE',(did,))
            row=get_case(conn,cid,True)
            if row['state'] in {'queued','processing'}: raise HTTPException(409,'Wait for processing to finish')
            docs=conn.execute('SELECT sha256 FROM documents WHERE case_id=%s',(cid,)).fetchall()
            if len(docs)>=config.MAX_DOCS: raise HTTPException(409,'Maximum 12 PDFs per case')
            if any(d['sha256']==digest.hexdigest() for d in docs): raise HTTPException(409,'This PDF is already attached')
            get_storage().put(did,path)
            conn.execute('INSERT INTO documents(id,case_id,filename,kind,sha256,bytes) VALUES(%s,%s,%s,%s,%s,%s)',(did,cid,filename,kind,digest.hexdigest(),size))
            conn.execute("UPDATE cases SET state='draft',result=NULL,error=NULL,updated_at=now() WHERE id=%s",(cid,))
            event(conn,cid,'document_uploaded',actor(request))
            conn.execute('DELETE FROM storage_cleanup WHERE document_id=%s',(did,))
    finally:
        staging.cleanup()
    return {'id':str(did)}

@app.get('/api/cases/{cid}/documents/{did}')
def original(cid:uuid.UUID,did:uuid.UUID):
    with connect() as conn:
        row=conn.execute('SELECT filename,bytes,sha256 FROM documents WHERE id=%s AND case_id=%s',(did,cid)).fetchone()
        if not row: raise HTTPException(404,'Document not found')
    document=materialize(get_storage(),did,row['bytes'],row['sha256'],config.MAX_FILE)
    path=document.__enter__()
    try:
        return TemporaryFileResponse(document,path,media_type='application/pdf',filename=row['filename'],
                                     content_disposition_type='attachment')
    except BaseException:
        document.__exit__(None,None,None)
        raise

@app.post('/api/cases/{cid}/assess',status_code=202)
def assess(cid:uuid.UUID,request:Request):
    if os.environ.get('PROCESSING_BACKEND')=='runpod':
        require_operator(request)
        with connect() as conn: description=get_case(conn,cid)['description']
        try: model_service.assess(connect,cid,description)
        except ProviderError as exc: raise HTTPException(409,str(exc))
        return {'state':'processing'}
    with connect() as conn:
        row=get_case(conn,cid,True)
        if row['state'] in {'queued','processing'}: return {'state':row['state']}
        kinds={d['kind'] for d in conn.execute('SELECT kind FROM documents WHERE case_id=%s',(cid,)).fetchall()}
        if not {'policy','schedule'}.issubset(kinds) or not (kinds & {'bill','discharge'}):
            raise HTTPException(422,'Attach policy wording, schedule and at least a bill or discharge summary')
        conn.execute("UPDATE cases SET state='queued',result=NULL,error=NULL,updated_at=now() WHERE id=%s",(cid,))
        event(conn,cid,'assessment_queued',actor(request))
    return {'state':'queued'}

@app.post('/api/cases/{cid}/review')
def review(cid:uuid.UUID,request:Request):
    with connect() as conn:
        row=get_case(conn,cid,True)
        if row['state']!='ready': raise HTTPException(409,'Wait for a completed assessment')
        event(conn,cid,'draft_review_acknowledged_not_coverage_authorization',actor(request))
    return {'status':'recorded'}

@app.delete('/api/cases/{cid}',status_code=204)
def delete_case(cid:uuid.UUID,background:BackgroundTasks):
    with connect() as conn:
        row=get_case(conn,cid,True)
        if row['state'] in {'queued','processing'}: raise HTTPException(409,'Wait for processing before deleting')
        docs=conn.execute('SELECT id FROM documents WHERE case_id=%s',(cid,)).fetchall()
        # Revoke application access now; retry physical removal in the worker.
        # Backups and bucket versions have separately configured retention.
        for d in docs:
            conn.execute('INSERT INTO storage_cleanup(document_id,eligible_at) VALUES(%s,now()) '
                         'ON CONFLICT(document_id) DO UPDATE SET eligible_at=now()', (d['id'],))
        conn.execute('DELETE FROM cases WHERE id=%s',(cid,))
    if os.environ.get('PROCESSING_BACKEND')=='runpod': background.add_task(cleanup_tick)

app.mount('/',StaticFiles(directory=STATIC,html=True),name='web')
