"""Durable admission control. All mutation paths use the same session advisory lock."""
from contextlib import contextmanager
import hashlib
import json
import os
import uuid

from .runpod_control import Runpod,ProviderError,EndpointPaused,confirmed_idle
from . import usage

ACTIVE=('pending','submitted','IN_QUEUE','IN_PROGRESS','uncertain')


def configured():
    return (os.environ.get('ENABLE_MODEL_CONTROL')=='1'
            and bool(os.environ.get('RUNPOD_CONTROL_KEY'))
            and bool(os.environ.get('RUNPOD_ENDPOINT_ID'))
            and bool(os.environ.get('RUNPOD_INFERENCE_KEY'))
            and bool(os.environ.get('RUNPOD_ARTIFACT_REVISION')))


def provider():
    if not configured(): raise ProviderError('Model controls are not configured and budget-enabled')
    return Runpod(os.environ['RUNPOD_ENDPOINT_ID'],os.environ['RUNPOD_CONTROL_KEY'],os.environ['RUNPOD_INFERENCE_KEY'])


@contextmanager
def locked(connect):
    with connect() as conn:
        # Session-level lock survives the deliberate intent commits before network calls.
        conn.execute('SELECT pg_advisory_lock(519826)')
        try: yield conn
        finally: conn.execute('SELECT pg_advisory_unlock(519826)')


def snapshot(documents):
    values=sorted((str(d['id']),d['sha256']) for d in documents)
    return hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest()


def submit(conn,client,kind,payload,generation,cid=None,snap=None,message_id=None,prepare=None):
    from psycopg.types.json import Jsonb
    session=conn.execute('SELECT started_at,ended_at FROM model_control WHERE id=1').fetchone()
    startup_seconds=180 if prepare is not None else 0
    try: usage.admit(session['started_at'],session['ended_at'],startup_seconds=startup_seconds)
    except usage.BudgetError as exc:raise ProviderError(str(exc)) from None
    try: reserved=usage.reserve(conn,startup_seconds=startup_seconds)
    except usage.BudgetError as exc:raise ProviderError(str(exc)) from None
    jid=uuid.uuid4()
    payload={**payload,'request_id':str(jid),'artifact_revision':os.environ['RUNPOD_ARTIFACT_REVISION']}
    conn.execute('INSERT INTO model_jobs(id,generation,kind,case_id,snapshot,payload,reserved_compute_usd) VALUES(%s,%s,%s,%s,%s,%s,%s)',
                 (jid,generation,kind,cid,snap,Jsonb(payload),reserved))
    if message_id is not None:
        conn.execute('UPDATE case_messages SET job_id=%s WHERE id=%s',(jid,message_id))
    conn.commit()  # An interrupted/uncertain submission must remain visible, never auto-resubmitted.
    submission_attempted=False
    try:
        if prepare is not None:prepare()
        submission_attempted=True
        pid=client.submit(payload,resume_paused=kind=='warmup' and prepare is None)
    except EndpointPaused:
        # The provider explicitly refused work; retain the reservation but do
        # not manufacture an unresolved provider job that requires DB recovery.
        conn.execute("UPDATE model_jobs SET state='REJECTED_PAUSED' WHERE id=%s",(jid,))
        conn.execute("UPDATE case_messages SET state='failed' WHERE job_id=%s AND state='pending'",(jid,))
        if cid is not None:
            conn.execute("UPDATE cases SET state='failed',error='Runpod endpoint is paused',updated_at=now() WHERE id=%s",(cid,))
        conn.execute("UPDATE model_control SET enabled=false,phase='error',updated_at=now() WHERE id=1")
        conn.commit()
        raise
    except ProviderError:
        if submission_attempted:
            conn.execute("UPDATE model_jobs SET state='uncertain' WHERE id=%s",(jid,))
        else:
            conn.execute("UPDATE model_jobs SET state='STARTUP_FAILED' WHERE id=%s",(jid,))
        conn.execute("UPDATE model_control SET enabled=false,phase='error',updated_at=now() WHERE id=1")
        conn.commit()
        raise
    conn.execute("UPDATE model_jobs SET provider_id=%s,state='submitted' WHERE id=%s",(pid,jid))
    conn.commit()
    return jid,pid


def start(connect):
    if os.environ.get('RUNPOD_INFERENCE_BUDGET_APPROVED')!='1':
        raise ProviderError('Operator must configure an inference allowance before starting compute')
    try: usage.admit(None)
    except usage.BudgetError as exc:raise ProviderError(str(exc)) from None
    client=provider()
    with locked(connect) as conn:
        row=conn.execute('SELECT * FROM model_control WHERE id=1').fetchone()
        if row['enabled']: return
        if conn.execute('SELECT 1 FROM model_jobs WHERE state=ANY(%s)',(list(ACTIVE),)).fetchone():
            raise ProviderError('Resolve the outstanding job before starting another session')
        # Fail closed on a control-plane failure. A read is mandatory before a write.
        client.settings()
        conn.execute("UPDATE model_control SET phase='starting',generation=generation+1,updated_at=now() WHERE id=1")
        conn.commit()
        try:
            generation=row['generation']+1
            conn.execute("UPDATE model_control SET enabled=true,phase='loading',started_at=now(),ended_at=NULL, "
                         "warmup_job=NULL,model_revision=NULL WHERE id=1")
            jid,pid=submit(conn,client,'warmup',{'task':'warmup'},generation,prepare=client.activate_worker)
            conn.execute('UPDATE model_control SET warmup_job=%s WHERE id=1',(pid,))
            conn.commit()  # Preserve the accepted ID before releasing the active-worker minimum.
            client.scale(True)  # min=0, max=1: idle scale-down resumes after acceptance.
        except ProviderError:
            conn.execute("UPDATE model_control SET enabled=false,phase='stopping',updated_at=now() WHERE id=1")
            conn.commit()
            try:
                client.scale(False)
                idle=confirmed_idle(client.health())
                outstanding=conn.execute('SELECT 1 FROM model_jobs WHERE state=ANY(%s)',(list(ACTIVE),)).fetchone()
                if idle and not outstanding:
                    conn.execute("UPDATE model_control SET phase='off',ended_at=COALESCE(ended_at,now()),updated_at=now() WHERE id=1")
                    conn.commit()
            except ProviderError:
                pass  # Keep stopping; never mask the original error or claim off.
            raise


def stop(connect):
    client=provider()
    with locked(connect) as conn:
        conn.execute("UPDATE model_control SET enabled=false,phase='stopping',generation=generation+1,updated_at=now() WHERE id=1")
        conn.commit()  # Admission closes even if the provider cannot be reached.
        jobs=conn.execute('SELECT * FROM model_jobs WHERE state=ANY(%s)',(list(ACTIVE),)).fetchall()
        failures=[]
        for job in jobs:
            if job['provider_id']:
                try: client.cancel(job['provider_id'])
                except ProviderError: failures.append(job['id'])
        client.settings()
        client.scale(False)
        idle=confirmed_idle(client.health())
        uncertain=any(not j['provider_id'] for j in jobs)
        if idle and not failures and not uncertain:
            conn.execute("UPDATE cases SET state='failed',error='Processing stopped by the operator',updated_at=now() "
                         "WHERE id IN (SELECT case_id FROM model_jobs WHERE state=ANY(%s)) AND state='processing'",(list(ACTIVE),))
            conn.execute("UPDATE model_jobs SET state='CANCELLED' WHERE state=ANY(%s)",(list(ACTIVE),))
            conn.execute("UPDATE case_messages SET state='cancelled' WHERE state='pending'")
            conn.execute("UPDATE model_control SET phase='off',ended_at=COALESCE(ended_at,now()),updated_at=now() WHERE id=1")


def status(connect):
    if not configured():
        return {'configured':False,'enabled':False,'state':'unavailable',
                'detail':'Configure the dedicated Runpod endpoint, artifact revision, operator and inference allowance first.'}
    client=provider()
    with locked(connect) as conn:
        row=conn.execute('SELECT * FROM model_control WHERE id=1').fetchone()
        jobs=conn.execute('SELECT * FROM model_jobs WHERE state=ANY(%s) ORDER BY created_at',(list(ACTIVE),)).fetchall()
        # Status only polls known jobs; it never allocates workers or submits generation.
        for job in jobs:
            if not job['provider_id']: continue
            result=client.status(job['provider_id'])
            state=result.get('status')
            if state not in {'IN_QUEUE','IN_PROGRESS','COMPLETED','FAILED','CANCELLED','TIMED_OUT'}:
                raise ProviderError('Unknown provider job state')
            conn.execute('UPDATE model_jobs SET state=%s WHERE id=%s',(state,job['id']))
            if state=='COMPLETED':
                try:
                    complete(conn,job,result.get('output'),row)
                except (ValueError,TypeError,KeyError,ProviderError):
                    # Invalid output is a terminal validation failure, not a
                    # reason to repeatedly poll or generate the answer again.
                    conn.execute("UPDATE model_jobs SET state='INVALID_OUTPUT' WHERE id=%s",(job['id'],))
                    conn.execute("UPDATE case_messages SET state='failed' WHERE job_id=%s",(job['id'],))
                    if job['kind']=='assessment':
                        conn.execute("UPDATE cases SET state='failed',result=NULL,error='Remote output failed independent validation. Review sources before retrying.',updated_at=now() WHERE id=%s",(job['case_id'],))
                    conn.execute("UPDATE model_control SET enabled=false,phase='error',updated_at=now() WHERE id=1")
            elif state in {'FAILED','CANCELLED','TIMED_OUT'}:
                conn.execute("UPDATE case_messages SET state='failed' WHERE job_id=%s AND state='pending'",(job['id'],))
                if job['kind']=='assessment':
                    conn.execute("UPDATE cases SET state='failed',error='Remote processing did not complete. Check model status before retrying.',updated_at=now() WHERE id=%s",(job['case_id'],))
                if job['kind']=='warmup' and row['enabled']:
                    conn.execute("UPDATE model_control SET phase='error' WHERE id=1")
        health=client.health()
        row=conn.execute('SELECT * FROM model_control WHERE id=1').fetchone()
        idle=confirmed_idle(health)
        unknown=conn.execute("SELECT 1 FROM model_jobs WHERE state IN ('pending','uncertain')").fetchone()
        if not row['enabled']:
            # A stale local 'off' record is never evidence that provider compute stopped.
            row['phase']='stopping' if not unknown and row['phase']!='error' else 'error'
        if not row['enabled'] and idle and not unknown:
            # The read-back is still required: local desired state alone is not proof.
            settings=client.settings().get('workers',{})
            if settings.get('min')==0 and settings.get('max')==0:
                stopped=conn.execute("UPDATE model_control SET phase='off',ended_at=COALESCE(ended_at,now()) WHERE id=1 RETURNING ended_at").fetchone()
                row['ended_at']=stopped['ended_at']
                row['phase']='off'
        elif row['enabled'] and row['phase']=='ready' and idle:
            row['phase']='idle'
        elif row['enabled'] and row['phase']=='ready' and health.get('jobs',{}).get('inProgress',0)>0:
            row['phase']='processing'
        try: estimated,limit=usage.estimate(row['started_at'],row.get('ended_at'))
        except usage.BudgetError:estimated,limit=None,None
        allowance=conn.execute('SELECT approved_total_usd,compute_reserved_usd,compute_reservation_limit_usd '
                               'FROM inference_allowance WHERE id=1').fetchone()
        return {'configured':True,'enabled':row['enabled'],'state':row['phase'],
                'startup_protocol':'invoke-worker-v2',
                'can_start':os.environ.get('RUNPOD_INFERENCE_BUDGET_APPROVED')=='1' and usage.configured(),
                'model':os.environ.get('RUNPOD_MODEL','Unspecified model'),'artifact_revision':row['model_revision'],
                'started_at':row['started_at'],'workers':health.get('workers',{}),
                'estimate_usd':float(estimated) if estimated is not None else None,
                'compute_allowance_usd':float(limit) if limit is not None else None,
                'demo_inference_allowance_usd':float(allowance['approved_total_usd']),
                'demo_compute_reserved_usd':float(allowance['compute_reserved_usd']),
                'detail':'Estimate uses session wall time at the configured GPU rate; excludes storage/tax and is not an invoice or hard spending cap. Stop affects the shared workspace.'}


def complete(conn,job,output,control):
    from psycopg.types.json import Jsonb
    if not isinstance(output,dict) or output.get('artifact_revision')!=os.environ['RUNPOD_ARTIFACT_REVISION']:
        raise ProviderError('Worker artifact identity did not match the configured release')
    if job['kind']!='warmup' and not job['case_id']: return
    if job['kind']=='warmup':
        if output.get('warmup_verified') is not True: raise ProviderError('Warm-up generation not verified')
        if control['enabled'] and job['generation']==control['generation']:
            conn.execute("UPDATE model_control SET phase='ready',model_revision=%s,updated_at=now() WHERE id=1",(output['artifact_revision'],))
    elif job['kind']=='chat':
        from .core import validate_output
        docs=conn.execute('SELECT id,sha256 FROM documents WHERE case_id=%s',(job['case_id'],)).fetchall()
        if snapshot(docs)!=job['snapshot']:
            conn.execute("UPDATE case_messages SET state='stale' WHERE job_id=%s",(job['id'],))
            return
        answer=validate_output(output.get('answer'),job['payload']['evidence'],job['payload']['partial_context'])
        answer['model_revision']=output['artifact_revision']
        conn.execute("UPDATE case_messages SET response=%s,state='ready' WHERE job_id=%s",(Jsonb(answer),job['id']))
    elif job['kind']=='assessment':
        from .remote_result import validate_assessment
        docs=conn.execute('SELECT * FROM documents WHERE case_id=%s',(job['case_id'],)).fetchall()
        if snapshot(docs)!=job['snapshot']: raise ProviderError('Assessment document snapshot changed')
        validated,result=validate_assessment(output,docs,job['payload']['description'])
        for doc in validated:
            conn.execute('UPDATE documents SET pages=%s WHERE id=%s',(Jsonb(doc['pages']),doc['id']))
        conn.execute("UPDATE cases SET state='ready',result=%s,error=NULL,updated_at=now() WHERE id=%s",(Jsonb(result),job['case_id']))
        conn.execute('INSERT INTO events(case_id,action,actor) VALUES(%s,%s,%s)',
                     (job['case_id'],'assessment_ready_for_review','runpod-worker'))


def chat(connect,cid,question):
    if os.environ.get('RUNPOD_INFERENCE_BUDGET_APPROVED')!='1':
        raise ProviderError('Inference allowance is not enabled')
    from .core import make_chunks,select_evidence
    client=provider()
    with locked(connect) as conn:
        control=conn.execute('SELECT * FROM model_control WHERE id=1').fetchone()
        if not control['enabled'] or control['phase'] not in {'ready','idle'}:
            raise ProviderError('Start and verify the model first')
        if conn.execute('SELECT 1 FROM model_jobs WHERE state=ANY(%s)',(list(ACTIVE),)).fetchone():
            raise ProviderError('Wait for the current model job before asking another question')
        docs=conn.execute('SELECT * FROM documents WHERE case_id=%s ORDER BY id',(cid,)).fetchall()
        if not docs or any(not d['pages'] for d in docs):
            raise ProviderError('Process the case documents before asking a question')
        evidence,partial=select_evidence(make_chunks(docs),question)
        snap=snapshot(docs)
        message=conn.execute('INSERT INTO case_messages(case_id,question,snapshot) VALUES(%s,%s,%s) RETURNING id',(cid,question,snap)).fetchone()
        submit(conn,client,'chat',{'task':'chat','question':question,'evidence':evidence,'partial_context':partial},control['generation'],cid,snap,message['id'])
        return {'id':message['id'],'state':'pending'}


def assess(connect,cid,description):
    from .storage import get_storage
    if os.environ.get('RUNPOD_INFERENCE_BUDGET_APPROVED')!='1':
        raise ProviderError('Inference allowance is not enabled')
    client=provider()
    with locked(connect) as conn:
        case=conn.execute('SELECT id,state FROM cases WHERE id=%s FOR UPDATE',(cid,)).fetchone()
        if not case: raise ProviderError('Case no longer exists')
        if case['state'] in {'queued','processing'}: raise ProviderError('This case is already processing')
        control=conn.execute('SELECT * FROM model_control WHERE id=1').fetchone()
        if not control['enabled'] or control['phase'] not in {'ready','idle'}:
            raise ProviderError('Start and verify the model first')
        if conn.execute('SELECT 1 FROM model_jobs WHERE state=ANY(%s)',(list(ACTIVE),)).fetchone():
            raise ProviderError('Wait for the current model job')
        docs=conn.execute('SELECT * FROM documents WHERE case_id=%s ORDER BY id',(cid,)).fetchall()
        if not 1<=len(docs)<=12: raise ProviderError('Invalid document count')
        kinds={d['kind'] for d in docs}
        if not {'policy','schedule'}<=kinds or not kinds&{'bill','discharge'}:
            raise ProviderError('Attach policy, schedule and claim evidence')
        storage=get_storage()
        if not hasattr(storage,'download_url'): raise ProviderError('Remote processing requires private S3 or R2 document storage')
        payload={'task':'assess','description':description,'documents':[
            {k:(str(d[k]) if k=='id' else d[k]) for k in ('id','sha256','bytes','filename','kind')}|{'url':storage.download_url(d['id'])}
            for d in docs]}
        # Only the remote processor owns this state; the local worker consumes queued.
        conn.execute("UPDATE cases SET state='processing',result=NULL,error=NULL,updated_at=now() WHERE id=%s",(cid,))
        submit(conn,client,'assessment',payload,control['generation'],cid,snapshot(docs))
        conn.execute('INSERT INTO events(case_id,action,actor) VALUES(%s,%s,%s)',(cid,'private_inference_started','runpod-worker'))
