"""Bounded local Poppler/Tesseract extraction. No model or network calls."""
import os
from pathlib import Path
import re
import resource
import subprocess
import tempfile

class ExtractionError(Exception): pass

def limits():
    resource.setrlimit(resource.RLIMIT_AS,(768*1024*1024,768*1024*1024))
    resource.setrlimit(resource.RLIMIT_FSIZE,(40*1024*1024,40*1024*1024))
    resource.setrlimit(resource.RLIMIT_CPU,(45,45))

def run(args,timeout=60):
    try:
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=timeout,check=True,preexec_fn=limits,env={**os.environ,'OMP_THREAD_LIMIT':'2'})
        return p.stdout.decode('utf-8',errors='replace')
    except (subprocess.SubprocessError,OSError):
        raise ExtractionError('Document parsing failed or exceeded processing limits') from None

def extract_pdf(path,max_pages=20):
    info=run(['pdfinfo',str(path)],15)
    match=re.search(r'^Pages:\s+(\d+)',info,re.M)
    if not match or int(match[1])>max_pages:
        raise ExtractionError('PDF exceeds the page limit or has invalid page metadata')
    count=int(match[1]); pages=[]
    with tempfile.TemporaryDirectory(prefix='claim-ocr-') as temp:
        for number in range(1,count+1):
            text=run(['pdftotext','-f',str(number),'-l',str(number),'-layout',str(path),'-'],20).strip()
            mode='native_text'
            if len(re.sub(r'\W','',text))<50:
                prefix=str(Path(temp)/'page')
                run(['pdftoppm','-f',str(number),'-l',str(number),'-scale-to','2200','-singlefile','-png',str(path),prefix],45)
                text=run(['tesseract',prefix+'.png','stdout','-l','eng+hin','--psm','3'],60).strip()
                mode='ocr'
                Path(prefix+'.png').unlink(missing_ok=True)
            if len(text)>18000: raise ExtractionError('Page text exceeds processing limit')
            pages.append({'page':number,'text':text,'method':mode,'needs_verification': mode=='ocr' or len(text)<50})
    return pages
