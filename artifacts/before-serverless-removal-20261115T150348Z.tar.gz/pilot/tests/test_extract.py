import unittest
from unittest.mock import patch
from pathlib import Path
from pilot.extract import extract_pdf,ExtractionError,run
import subprocess

class ExtractionTests(unittest.TestCase):
    @patch('pilot.extract.run')
    def test_reject_over_limit_before_render(self,mock):
        mock.return_value='Pages: 21\n'
        with self.assertRaises(ExtractionError):extract_pdf(Path('/tmp/example.pdf'))
        self.assertEqual(mock.call_count,1)
    @patch('pilot.extract.run')
    def test_native_page_does_not_call_ocr(self,mock):
        mock.side_effect=['Pages: 1\n','Policy schedule '+('verified text '*10)]
        pages=extract_pdf(Path('/tmp/example.pdf'))
        self.assertEqual(pages[0]['method'],'native_text')
        self.assertEqual(mock.call_count,2)
    @patch('pilot.extract.run')
    def test_scan_calls_renderer_then_ocr(self,mock):
        mock.side_effect=['Pages: 1\n','','','Recognized claim evidence']
        pages=extract_pdf(Path('/tmp/example.pdf'))
        self.assertEqual(pages[0]['method'],'ocr')
        self.assertTrue(pages[0]['needs_verification'])
        self.assertEqual(mock.call_args_list[2].args[0][0],'pdftoppm')
        self.assertEqual(mock.call_args_list[3].args[0][0],'tesseract')
    @patch('pilot.extract.run')
    def test_excessive_page_text_fails(self,mock):
        mock.side_effect=['Pages: 1\n','x'*18001]
        with self.assertRaises(ExtractionError):extract_pdf(Path('/tmp/example.pdf'))
    @patch('pilot.extract.subprocess.run')
    def test_timeout_becomes_safe_error(self,mock):
        mock.side_effect=subprocess.TimeoutExpired(['tool','sensitive-filename'],5)
        with self.assertRaises(ExtractionError) as error:run(['tool'])
        self.assertNotIn('sensitive',str(error.exception))

if __name__=='__main__':unittest.main()
