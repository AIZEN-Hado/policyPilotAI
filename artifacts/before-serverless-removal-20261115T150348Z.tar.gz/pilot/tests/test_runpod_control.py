import io
import json
import os
import sys
import types
import unittest
import urllib.error
from contextlib import contextmanager
from unittest.mock import Mock,patch

from pilot.runpod_control import Runpod,ProviderError,EndpointPaused,confirmed_idle
from pilot.model_service import snapshot,start,submit,stop,status


def reply(value):
    stream=io.BytesIO(json.dumps(value).encode())
    stream.__enter__=lambda:stream
    return stream


class ControlTests(unittest.TestCase):
    def setUp(self):
        self.transport=Mock()
        self.client=Runpod('endpoint1','control-secret','invoke-secret',self.transport)

    def test_url_injection_rejected(self):
        for value in ('https://evil.invalid','endpoint/../../other','x?test=1',''):
            with self.assertRaises(ValueError): Runpod(value,'key','key')

    def test_scaling_is_verified_by_a_separate_read(self):
        self.transport.open.side_effect=[reply({}),reply({'workers':{'min':0,'max':0,'idleTimeout':300}})]
        self.client.scale(False)
        calls=self.transport.open.call_args_list
        self.assertEqual(len(calls),2)
        mutation=calls[0].args[0];read=calls[1].args[0]
        self.assertEqual(mutation.method,'PATCH');self.assertEqual(read.method,'GET')
        self.assertEqual(mutation.full_url,'https://api.runpod.io/v2/serverless/endpoint1')
        self.assertEqual(mutation.get_header('Authorization'),'Bearer control-secret')
        self.assertEqual(json.loads(mutation.data)['workers']['max'],0)

    def test_wrong_readback_never_claims_success(self):
        self.transport.open.side_effect=[reply({}),reply({'workers':{'min':1,'max':1}})]
        with self.assertRaises(ProviderError): self.client.scale(False)

    def test_inference_uses_separate_credential_and_bounded_policy(self):
        self.transport.open.return_value=reply({'id':'job-1'})
        self.assertEqual(self.client.submit({'task':'warmup'}),'job-1')
        request=self.transport.open.call_args.args[0]
        self.assertEqual(request.get_header('Authorization'),'Bearer invoke-secret')
        self.assertEqual(request.full_url,'https://api.runpod.ai/v2/endpoint1/run')
        self.assertEqual(json.loads(request.data)['policy']['executionTimeout'],180000)

    def test_network_failure_is_never_retried_or_exposed(self):
        self.transport.open.side_effect=RuntimeError('private-secret')
        with self.assertRaises(ProviderError) as caught:self.client.submit({})
        self.transport.open.assert_called_once()
        self.assertNotIn('private-secret',str(caught.exception))

    def paused(self,value=None):
        if value is None:value={'status':409,'code':'ENDPOINT_PAUSED','detail':'private-secret'}
        return urllib.error.HTTPError('private-url',409,'private-secret',{},
                                      io.BytesIO(json.dumps(value).encode()))

    def test_explicit_pause_can_settle_then_accept_exactly_one_job(self):
        self.transport.open.side_effect=[self.paused(),reply({'workers':{'min':0,'max':1}}),
                                        self.paused({'message':{'status':409,'code':'ENDPOINT_PAUSED'}}),
                                        reply({'workers':{'min':0,'max':1}}),reply({'id':'accepted-job'})]
        with patch('pilot.runpod_control.time.sleep') as sleep,self.assertLogs('pilot.runpod_control') as logs:
            self.assertEqual(self.client.submit({'request_id':'same'},resume_paused=True),'accepted-job')
        self.assertEqual(sleep.call_count,2)
        requests=[c.args[0] for c in self.transport.open.call_args_list]
        self.assertEqual([r.method for r in requests],['POST','GET','POST','GET','POST'])
        self.assertEqual(requests[0].data,requests[2].data)
        self.assertEqual(requests[0].data,requests[4].data)
        self.assertNotIn('private-secret',' '.join(logs.output))

    def test_unknown_conflict_or_job_acknowledgement_never_repeated(self):
        for body in ({'code':'OTHER'},{'detail':'ENDPOINT_PAUSED'},
                     {'code':'ENDPOINT_PAUSED','id':'maybe-job'},
                     {'code':'ENDPOINT_PAUSED','data':{'id':'maybe-job'}},
                     {'code':'ENDPOINT_PAUSED','status':500}):
            self.transport.open.reset_mock();self.transport.open.side_effect=self.paused(body)
            with patch('pilot.runpod_control.time.sleep') as sleep,self.assertLogs('pilot.runpod_control'):
                with self.assertRaises(ProviderError) as caught:self.client.submit({},resume_paused=True)
            self.assertNotIsInstance(caught.exception,EndpointPaused)
            self.transport.open.assert_called_once();sleep.assert_not_called()

    def test_paused_rejection_repeats_are_bounded_and_stop_if_disabled(self):
        for max_workers in (0,1):
            self.transport.open.reset_mock()
            self.transport.open.side_effect=[self.paused(),reply({'workers':{'min':0,'max':max_workers}}),
                self.paused(),reply({'workers':{'min':0,'max':1}}),self.paused()]
            with patch('pilot.runpod_control.time.sleep'),self.assertLogs('pilot.runpod_control'):
                with self.assertRaises(EndpointPaused):self.client.submit({},resume_paused=True)
            posts=[c for c in self.transport.open.call_args_list if c.args[0].method=='POST']
            self.assertEqual(len(posts),3 if max_workers else 1)

    def test_unknown_response_after_pause_never_submits_again(self):
        self.transport.open.side_effect=[self.paused(),reply({'workers':{'min':0,'max':1}}),
                                        TimeoutError('private-secret')]
        with patch('pilot.runpod_control.time.sleep'),self.assertLogs('pilot.runpod_control'):
            with self.assertRaises(ProviderError) as caught:self.client.submit({},resume_paused=True)
        self.assertNotIsInstance(caught.exception,EndpointPaused)
        self.assertEqual(self.transport.open.call_count,3)

    def test_pause_is_not_repeated_for_regular_inference(self):
        self.transport.open.side_effect=self.paused()
        with self.assertLogs('pilot.runpod_control'):
            with self.assertRaises(EndpointPaused):self.client.submit({})
        self.transport.open.assert_called_once()

    def test_http_failure_reports_only_operation_and_status(self):
        body=io.BytesIO(b'private-secret control-secret invoke-secret')
        self.transport.open.side_effect=urllib.error.HTTPError(
            'https://private-secret.invalid',403,'private-secret',{},body)
        with self.assertLogs('pilot.runpod_control',level='WARNING') as logs:
            with self.assertRaises(ProviderError) as caught:self.client.submit({'secret':'private-secret'})
        self.assertIn('Runpod submit: HTTP 403',str(caught.exception))
        output=str(caught.exception)+' '.join(logs.output)
        for secret in ('private-secret','control-secret','invoke-secret'):
            self.assertNotIn(secret,output)
        self.assertTrue(body.closed)
        self.transport.open.assert_called_once()

    def test_transport_failures_are_distinguishable_without_raw_details(self):
        for error,category in (
            (TimeoutError('private-secret'),'timeout'),
            (urllib.error.URLError(TimeoutError('private-secret')),'timeout'),
            (urllib.error.URLError('private-secret'),'network failure'),
        ):
            with self.subTest(category=category):
                self.transport.open.reset_mock()
                self.transport.open.side_effect=error
                with self.assertLogs('pilot.runpod_control',level='WARNING') as logs:
                    with self.assertRaises(ProviderError) as caught:self.client.submit({})
                self.assertIn('Runpod submit: '+category,str(caught.exception))
                self.assertNotIn('private-secret',str(caught.exception)+' '.join(logs.output))
                self.transport.open.assert_called_once()

    def test_invalid_response_and_job_status_do_not_expose_body_or_job_id(self):
        self.transport.open.return_value=io.BytesIO(b'private-secret')
        with self.assertLogs('pilot.runpod_control',level='WARNING') as logs:
            with self.assertRaises(ProviderError) as caught:self.client.status('private-job-id')
        self.assertIn('Runpod job_status: invalid response',str(caught.exception))
        for value in ('private-secret','private-job-id'):
            self.assertNotIn(value,str(caught.exception)+' '.join(logs.output))

    def test_control_http_failure_is_labeled_separately(self):
        self.transport.open.side_effect=urllib.error.HTTPError('private-url',401,'private-message',{},io.BytesIO())
        with self.assertLogs('pilot.runpod_control',level='WARNING'):
            with self.assertRaises(ProviderError) as caught:self.client.scale(False)
        self.assertIn('Runpod control_update: HTTP 401',str(caught.exception))
        self.transport.open.assert_called_once()

    def test_bad_job_id_never_reaches_provider(self):
        with self.assertRaises(ProviderError):self.client.cancel('abc/../other')
        self.transport.open.assert_not_called()

    def test_activation_waits_for_invoke_observation_without_submitting(self):
        seconds=[0]
        idle={'workers':{'running':0,'ready':0,'initializing':0,'unhealthy':0},'jobs':{'inQueue':0,'inProgress':0}}
        active=json.loads(json.dumps(idle));active['workers']['running']=1
        self.transport.open.side_effect=[reply({}),reply({'workers':{'min':1,'max':1}}),reply(idle),reply(active)]
        self.client.activate_worker(clock=lambda:seconds[0],sleep=lambda n:seconds.__setitem__(0,seconds[0]+n))
        calls=[c.args[0] for c in self.transport.open.call_args_list]
        self.assertEqual([c.method for c in calls],['PATCH','GET','GET','GET'])
        self.assertEqual(json.loads(calls[0].data)['workers'],{'min':1,'max':1,'idleTimeout':180})
        self.assertTrue(all(not c.full_url.endswith('/run') for c in calls))
        self.assertEqual(seconds[0],5)

    def test_activation_timeout_or_bad_runtime_health_cannot_submit(self):
        for broken in (False,True):
            seconds=[0];self.transport.open.reset_mock()
            health={} if broken else {'workers':{'running':0,'ready':0,'initializing':0,'unhealthy':0},'jobs':{'inQueue':0,'inProgress':0}}
            count=[0]
            def response(request,timeout):
                count[0]+=1
                return reply({} if count[0]==1 else {'workers':{'min':1,'max':1}} if count[0]==2 else health)
            self.transport.open.side_effect=response
            with self.assertRaises(ProviderError):
                self.client.activate_worker(clock=lambda:seconds[0],sleep=lambda n:seconds.__setitem__(0,seconds[0]+n))
            self.assertTrue(all(c.args[0].method!='POST' for c in self.transport.open.call_args_list))
            self.assertLessEqual(seconds[0],180)

    def test_slow_worker_can_activate_after_the_old_sixty_second_cutoff(self):
        seconds=[0]
        def response(request,timeout):
            if request.method=='PATCH':return reply({})
            if request.full_url.endswith('/health'):
                return reply({'workers':{'running':int(seconds[0]>=120),'ready':0,'initializing':0,'unhealthy':0},
                              'jobs':{'inQueue':0,'inProgress':0}})
            return reply({'workers':{'min':1,'max':1}})
        self.transport.open.side_effect=response
        self.client.activate_worker(clock=lambda:seconds[0],sleep=lambda n:seconds.__setitem__(0,seconds[0]+n))
        self.assertEqual(seconds[0],120)
        self.assertTrue(all(call.args[0].method!='POST' for call in self.transport.open.call_args_list))

    def test_idle_hold_shortens_after_acceptance_without_leaving_a_minimum(self):
        self.transport.open.side_effect=[reply({}),reply({'workers':{'min':0,'max':1,'idleTimeout':180}})]
        self.client.scale(True)
        request=self.transport.open.call_args_list[0].args[0]
        self.assertEqual(json.loads(request.data)['workers'],{'min':0,'max':1,'idleTimeout':180})

    def test_stop_requires_complete_zero_activity_evidence(self):
        health={'workers':{'running':0,'ready':0,'initializing':0,'unhealthy':0},'jobs':{'inProgress':0,'inQueue':0}}
        self.assertTrue(confirmed_idle(health))
        for group,key in (('workers','running'),('jobs','inProgress')):
            altered=json.loads(json.dumps(health));altered[group][key]=1
            self.assertFalse(confirmed_idle(altered))
            del altered[group][key]
            self.assertFalse(confirmed_idle(altered))
        self.assertFalse(confirmed_idle({}))

    def test_start_without_budget_cannot_make_provider_call(self):
        with patch.dict(os.environ,{'RUNPOD_INFERENCE_BUDGET_APPROVED':'0'}),patch('pilot.model_service.provider') as provider:
            with self.assertRaises(ProviderError): start(Mock())
            provider.assert_not_called()

    def test_snapshot_is_order_independent_but_detects_replacement(self):
        docs=[{'id':'a','sha256':'111'},{'id':'b','sha256':'222'}]
        self.assertEqual(snapshot(docs),snapshot(list(reversed(docs))))
        self.assertNotEqual(snapshot(docs),snapshot([{'id':'a','sha256':'333'},docs[1]]))

    def test_uncertain_submission_preserves_intent_and_closes_admission(self):
        conn=Mock();client=Mock()
        conn.execute.return_value.fetchone.return_value={'started_at':None,'ended_at':None}
        def fail(payload,**kwargs):
            self.assertGreaterEqual(conn.commit.call_count,1)
            raise ProviderError('Response lost')
        client.submit.side_effect=fail
        module=types.ModuleType('psycopg.types.json');module.Jsonb=lambda value:value
        with patch.dict(sys.modules,{'psycopg.types.json':module}),patch.dict(os.environ,{'RUNPOD_ARTIFACT_REVISION':'revision','RUNPOD_VERIFIED_HOURLY_RATE_USD':'1','RUNPOD_SESSION_COMPUTE_LIMIT_USD':'2'}):
            with self.assertRaises(ProviderError):submit(conn,client,'warmup',{},1)
        sql=' '.join(c.args[0] for c in conn.execute.call_args_list)
        self.assertIn("state='uncertain'",sql)
        self.assertIn('enabled=false',sql)
        client.submit.assert_called_once()


class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.conn=Mock();self.client=Mock()
        self.conn.execute.return_value.fetchall.return_value=[{'id':'local-job','provider_id':'provider-job'}]
        @contextmanager
        def connect():yield self.conn
        self.connect=connect

    def test_rejected_start_preserves_reservation_and_shuts_down_without_uncertain_job(self):
        self.exercise_failed_start(EndpointPaused('confirmed rejection'),False,True)

    def test_lost_start_response_keeps_uncertain_job_after_zero_workers(self):
        self.exercise_failed_start(ProviderError('response lost'),True,True)

    def test_rejected_start_cannot_claim_off_without_idle_health(self):
        self.exercise_failed_start(EndpointPaused('confirmed rejection'),False,False)

    def test_activation_failure_records_no_submission_and_cleans_up(self):
        self.client.activate_worker.side_effect=ProviderError('activation not observed')
        statements=self.exercise_failed_start(ProviderError('unused'),False,True,activation_failed=True)
        self.client.submit.assert_not_called()
        self.assertTrue(any("state='STARTUP_FAILED'" in s for s in statements))

    def test_success_reserves_before_activation_and_saves_id_before_idle_scaling(self):
        statements=[]
        def execute(sql,params=None):
            statements.append(sql);result=Mock();result.fetchone.return_value=None
            if sql.startswith('SELECT * FROM model_control'):result.fetchone.return_value={'enabled':False,'generation':3}
            if sql.startswith('SELECT started_at,ended_at'):result.fetchone.return_value={'started_at':None,'ended_at':None}
            return result
        self.conn.execute.side_effect=execute
        self.client.submit.return_value='accepted-job'
        def activate():
            self.assertTrue(any(s.startswith('INSERT INTO model_jobs') for s in statements))
            self.assertGreaterEqual(self.conn.commit.call_count,2)
            reserved.assert_called_once_with(self.conn,startup_seconds=180)
        self.client.activate_worker.side_effect=activate
        def scale(enabled):
            self.assertTrue(enabled)
            self.assertTrue(any('provider_id=%s' in s for s in statements))
            self.assertTrue(any('SET warmup_job=%s' in s for s in statements))
            self.assertGreaterEqual(self.conn.commit.call_count,4)
        self.client.scale.side_effect=scale
        module=types.ModuleType('psycopg.types.json');module.Jsonb=lambda value:value
        with patch.dict(sys.modules,{'psycopg.types.json':module}), \
             patch.dict(os.environ,{'RUNPOD_INFERENCE_BUDGET_APPROVED':'1','RUNPOD_ARTIFACT_REVISION':'revision'}), \
             patch('pilot.model_service.provider',return_value=self.client), \
             patch('pilot.model_service.usage.admit'), \
             patch('pilot.model_service.usage.reserve',return_value='.11875') as reserved:
            start(self.connect)
        self.client.activate_worker.assert_called_once()
        self.client.submit.assert_called_once()
        self.client.scale.assert_called_once_with(True)

    def exercise_failed_start(self,error,uncertain,idle,activation_failed=False):
        sql=[];submitted=False
        def execute(statement,params=None):
            nonlocal submitted
            sql.append(statement);result=Mock();result.fetchone.return_value=None
            if statement.startswith('SELECT * FROM model_control'):
                result.fetchone.return_value={'enabled':False,'generation':3}
            elif statement.startswith('SELECT started_at,ended_at'):
                result.fetchone.return_value={'started_at':None,'ended_at':None}
            elif statement.startswith('INSERT INTO model_jobs'):submitted=True
            elif statement.startswith('SELECT 1 FROM model_jobs'):
                result.fetchone.return_value={'present':1} if submitted and uncertain else None
            return result
        self.conn.execute.side_effect=execute
        self.client.submit.side_effect=error
        self.client.health.return_value={'workers':{k:0 for k in ('running','ready','initializing','unhealthy')},
                                         'jobs':{'inProgress':0,'inQueue':0}} if idle else {}
        module=types.ModuleType('psycopg.types.json');module.Jsonb=lambda value:value
        with patch.dict(sys.modules,{'psycopg.types.json':module}), \
             patch.dict(os.environ,{'RUNPOD_INFERENCE_BUDGET_APPROVED':'1','RUNPOD_ARTIFACT_REVISION':'revision'}), \
             patch('pilot.model_service.provider',return_value=self.client), \
             patch('pilot.model_service.usage.admit'), \
             patch('pilot.model_service.usage.reserve',return_value='.10625') as reserve:
            with self.assertRaises(type(error)):start(self.connect)
        reserve.assert_called_once_with(self.conn,startup_seconds=180)
        self.client.activate_worker.assert_called_once()
        if not activation_failed:
            self.client.submit.assert_called_once()
            self.assertFalse(self.client.submit.call_args.kwargs['resume_paused'])
        self.assertEqual([c.args for c in self.client.scale.call_args_list],[(False,)])
        self.assertFalse(any('UPDATE inference_allowance' in s for s in sql))
        self.assertEqual(any("state='uncertain'" in s for s in sql),uncertain)
        self.assertEqual(any("state='REJECTED_PAUSED'" in s for s in sql),not uncertain and not activation_failed)
        self.assertEqual(any("phase='off'" in s for s in sql),idle and not uncertain)
        return sql

    def test_stop_closes_admission_before_cancel_and_attempts_scale_even_if_cancel_fails(self):
        def cancel(job):
            self.assertGreater(self.conn.commit.call_count,0)
            raise ProviderError('Unavailable')
        self.client.cancel.side_effect=cancel
        self.client.health.return_value={}
        with patch('pilot.model_service.provider',return_value=self.client):stop(self.connect)
        self.client.scale.assert_called_once_with(False)
        sql=' '.join(c.args[0] for c in self.conn.execute.call_args_list)
        self.assertIn('enabled=false',sql)
        self.assertNotIn("phase='off'",sql)

    def test_stop_readback_failure_never_records_off(self):
        self.client.scale.side_effect=ProviderError('Readback failed')
        with patch('pilot.model_service.provider',return_value=self.client):
            with self.assertRaises(ProviderError):stop(self.connect)
        sql=' '.join(c.args[0] for c in self.conn.execute.call_args_list)
        self.assertNotIn("phase='off'",sql)
        self.assertGreater(self.conn.commit.call_count,0)

    def test_observed_running_worker_overrides_local_off_state(self):
        row={'enabled':False,'phase':'off','started_at':None,'ended_at':None,'model_revision':None}
        def execute(sql,params=None):
            result=Mock()
            if sql.startswith('SELECT * FROM model_control'):result.fetchone.return_value=dict(row)
            elif sql.startswith('SELECT approved_total_usd'):result.fetchone.return_value={'approved_total_usd':1,'compute_reserved_usd':0,'compute_reservation_limit_usd':.7}
            else:result.fetchone.return_value=None
            result.fetchall.return_value=[]
            return result
        self.conn.execute.side_effect=execute
        self.client.health.return_value={'workers':{'running':1},'jobs':{'inProgress':0,'inQueue':0}}
        with patch('pilot.model_service.configured',return_value=True),patch('pilot.model_service.provider',return_value=self.client):
            result=status(self.connect)
        self.assertEqual(result['state'],'stopping')
        self.client.submit.assert_not_called()
        self.client.scale.assert_not_called()
