import unittest
from deploy.preflight_live import candidates


class CatalogTests(unittest.TestCase):
    def gpu(self,**updates):
        return dict({'name':'Synthetic test GPU','manufacturer':'NVIDIA','memory':24,
                     'pool':'test-pool','price':{'serverless':1.2},'availability':'NONE'},**updates)

    def test_pod_price_is_not_used_when_serverless_quote_is_missing(self):
        self.assertEqual(candidates({'gpus':[self.gpu(price={'secure':.01,'community':.01})]}),[])

    def test_only_matching_hardware_with_finite_serverless_rates(self):
        rows=[self.gpu(),self.gpu(memory=8),self.gpu(manufacturer='AMD'),
              self.gpu(pool=None),self.gpu(price={'serverless':float('nan')}),
              self.gpu(price={'serverless':True})]
        result=candidates({'gpus':rows})
        self.assertEqual(len(result),1)
        self.assertEqual(result[0]['stock'],'NONE')

    def test_unknown_stock_is_not_reported_as_available(self):
        row=self.gpu();del row['availability']
        self.assertEqual(candidates({'gpus':[row]})[0]['stock'],'UNKNOWN')

    def test_unexpected_response_shape_is_rejected(self):
        for response in ([],{}, {'gpus':None}):
            with self.assertRaises(ValueError):candidates(response)
