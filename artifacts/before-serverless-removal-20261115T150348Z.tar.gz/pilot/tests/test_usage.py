from datetime import datetime,timedelta,timezone
from decimal import Decimal
import os
import unittest
from unittest.mock import patch,Mock
from pilot import usage


class UsageTests(unittest.TestCase):
    def setUp(self):
        # Synthetic test rate, not a live GPU quote.
        env=patch.dict(os.environ,{'RUNPOD_VERIFIED_HOURLY_RATE_USD':'1.20',
                                   'RUNPOD_SESSION_COMPUTE_LIMIT_USD':'0.50'})
        env.start();self.addCleanup(env.stop)
        self.start=datetime(2026,11,11,tzinfo=timezone.utc)

    def test_elapsed_compute_estimate_is_exact_decimal(self):
        cost,limit=usage.estimate(self.start,now=self.start+timedelta(minutes=10))
        self.assertEqual(cost,Decimal('0.20'))
        self.assertEqual(limit,Decimal('0.50'))

    def test_verified_stop_freezes_the_estimate(self):
        end=self.start+timedelta(minutes=5)
        cost,_=usage.estimate(self.start,end,now=self.start+timedelta(hours=5))
        self.assertEqual(cost,Decimal('0.10'))

    def test_admission_reserves_time_for_task_and_idle(self):
        with self.assertRaises(usage.BudgetError):
            usage.admit(self.start,now=self.start+timedelta(minutes=20))
        usage.admit(self.start,now=self.start+timedelta(minutes=5))

    def test_nonfinite_negative_or_missing_rate_blocks_admission(self):
        for value in ('NaN','Infinity','0','-1','bad',''):
            with self.subTest(value=value),patch.dict(os.environ,{'RUNPOD_VERIFIED_HOURLY_RATE_USD':value}):
                self.assertFalse(usage.configured())
                with self.assertRaises(usage.BudgetError):usage.admit(None)

    def test_insufficient_allowance_blocks_even_first_job(self):
        with patch.dict(os.environ,{'RUNPOD_SESSION_COMPUTE_LIMIT_USD':'0.01'}):
            with self.assertRaises(usage.BudgetError):usage.admit(None)

    def test_cumulative_allowance_exhaustion_blocks_reservation(self):
        conn=Mock();conn.execute.return_value.fetchone.return_value=None
        with self.assertRaises(usage.BudgetError):usage.reserve(conn)
        self.assertIn('compute_reserved_usd+%s<=compute_reservation_limit_usd',conn.execute.call_args.args[0])

    def test_reservation_uses_verified_rate_and_is_not_a_session_reset(self):
        conn=Mock();conn.execute.return_value.fetchone.return_value={'compute_reserved_usd':'0.17'}
        self.assertEqual(usage.reserve(conn),Decimal('0.17'))
        self.assertNotIn('=0',conn.execute.call_args.args[0])

    def test_warmup_includes_startup_margin_and_blocks_invalid_margin(self):
        conn=Mock();conn.execute.return_value.fetchone.return_value={'compute_reserved_usd':'.19'}
        self.assertEqual(usage.reserve(conn,startup_seconds=60),Decimal('.19'))
        self.assertEqual(usage.reserve(conn,startup_seconds=180),Decimal('.19'))
        for seconds in (-1,61,True,'60'):
            conn.reset_mock()
            with self.assertRaises(usage.BudgetError):usage.reserve(conn,startup_seconds=seconds)
            conn.execute.assert_not_called()
