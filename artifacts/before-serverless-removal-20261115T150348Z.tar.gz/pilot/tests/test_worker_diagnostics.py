from contextlib import redirect_stdout
import errno
import io
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from urllib.error import HTTPError

from pilot import gpu_handler
from pilot import worker_diagnostics as diagnostics


class WorkerDiagnosticTests(unittest.TestCase):
    def test_cpu_only_native_backend_is_rejected_before_probe_allocations(self):
        fake_bnb=SimpleNamespace()
        fake_extension=SimpleNamespace(lib=SimpleNamespace(compiled_with_cuda=False))
        with patch.dict('sys.modules',{'bitsandbytes':fake_bnb,'bitsandbytes.cextension':fake_extension}),\
                patch.object(gpu_handler,'check_compiler'),\
                redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError,'CUDA-enabled native library'):
                gpu_handler.check_quantizer(None)

    def test_loader_runtime_reason_redacts_environment_urls_and_credentials(self):
        message=('CUDA error: no kernel image is available; actual-secret '
                 'https://signed.invalid/file?signature=private-query hf_privateToken '
                 'Bearer opaque-bearer token=opaque-token /tmp/private-model/weights.safetensors')
        with patch.dict('os.environ',{'RUNPOD_API_KEY':'actual-secret'}),redirect_stdout(io.StringIO()) as output:
            diagnostics.stage('load_model');result=diagnostics.failure(RuntimeError(message))
            reread=diagnostics.safe_record(output.getvalue().splitlines()[-1])
        self.assertIn('no kernel image',result['model_loader_reason'])
        self.assertEqual(reread,result)
        for secret in ('actual-secret','signed.invalid','private-query','hf_privateToken',
                       'opaque-bearer','opaque-token','private-model'):
            self.assertNotIn(secret,output.getvalue()+json.dumps(result))

    def test_loader_reason_is_bounded_and_never_emitted_for_document_or_prompt_errors(self):
        with redirect_stdout(io.StringIO()):
            diagnostics.stage('load_model');result=diagnostics.failure(RuntimeError('x'*2000))
        self.assertEqual(len(result['model_loader_reason']),1600)
        for name in ('download_document','extract_document','prepare_prompt','generate','parse_output'):
            with redirect_stdout(io.StringIO()) as output:
                diagnostics.stage(name);result=diagnostics.failure(RuntimeError('private-claim-text'))
            self.assertNotIn('model_loader_reason',result)
            self.assertNotIn('private-claim-text',output.getvalue())

    def test_only_library_locations_are_kept_without_source_or_locals(self):
        scope={'RuntimeError':RuntimeError}
        try:
            exec(compile("raise RuntimeError('public loader failure')",'/usr/local/lib/python3.12/site-packages/transformers/modeling_utils.py','exec'),scope)
        except RuntimeError as error:
            with redirect_stdout(io.StringIO()):
                diagnostics.stage('load_model');result=diagnostics.failure(error)
        self.assertEqual(result['library_frames'],[{'file':'transformers/modeling_utils.py','line':1}])
        result['library_frames'].append({'file':'../../private-secret','line':1,'locals':'private-secret'})
        with patch.dict('os.environ',{'HF_TOKEN':'public loader failure'}):
            reread=diagnostics.safe_record(diagnostics.PREFIX+json.dumps(result))
        self.assertNotIn('private-secret',json.dumps(reread))
        self.assertNotIn('public loader failure',json.dumps(reread))

    def test_failure_logs_stage_class_and_http_code_without_message(self):
        with redirect_stdout(io.StringIO()) as output:
            diagnostics.stage('download_model')
            result=diagnostics.failure(HTTPError('https://private-secret.invalid',403,'private-secret',{},None))
        self.assertEqual(result['stage'],'download_model')
        self.assertEqual(result['category'],'remote_http')
        self.assertEqual(result['http_status'],403)
        self.assertNotIn('private-secret',output.getvalue()+json.dumps(result))
        self.assertEqual(diagnostics.safe_record(output.getvalue().splitlines()[-1]),result)

    def test_known_failures_use_fixed_categories_without_raw_text(self):
        for error,category in ((ModuleNotFoundError('private-secret'),'missing_dependency'),
                              (OSError(errno.ENOSPC,'private-secret'),'disk_full'),
                              (TimeoutError('private-secret'),'network_timeout'),
                              (MemoryError('private-secret'),'host_memory')):
            with redirect_stdout(io.StringIO()) as output:
                diagnostics.stage('load_model');result=diagnostics.failure(error)
            self.assertEqual(result['category'],category)
            self.assertNotIn('private-secret',output.getvalue())

    def test_handler_preserves_safe_context_but_never_exposes_inputs_or_cause(self):
        def fail(job):
            diagnostics.stage('load_tokenizer')
            raise ValueError('private-secret '+job['input']['token'])
        with patch.object(gpu_handler,'process_job',side_effect=fail),redirect_stdout(io.StringIO()) as output:
            with self.assertRaises(RuntimeError) as caught:gpu_handler.handler({'input':{'token':'private-token'}})
        self.assertIn('load_tokenizer',str(caught.exception))
        for value in ('private-secret','private-token'):
            self.assertNotIn(value,str(caught.exception)+output.getvalue())
        self.assertTrue(caught.exception.__suppress_context__)

    def test_log_record_rejects_bad_values_and_discards_extra_keys(self):
        value={'event':'failure','stage':'load_model','category':'processing_failure',
               'exception_type':'private-secret','url':'private-secret','peak_rss_bytes':12345}
        result=diagnostics.safe_record(diagnostics.PREFIX+json.dumps(value))
        self.assertNotIn('private-secret',json.dumps(result))
        self.assertEqual(result['peak_rss_bytes'],12345)
        for stage in ('private-secret',{},None):
            value['stage']=stage
            self.assertIsNone(diagnostics.safe_record(diagnostics.PREFIX+json.dumps(value)))
