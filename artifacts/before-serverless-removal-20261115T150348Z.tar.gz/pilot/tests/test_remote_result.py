import copy
import unittest
from pilot.core import make_chunks,select_evidence
from pilot.remote_result import validate_assessment


class RemoteResultTests(unittest.TestCase):
    def setUp(self):
        text='This synthetic policy excludes registration fees. Verify original policy wording.'
        self.expected=[{'id':'a','sha256':'hasha','kind':'policy','filename':'wording.pdf'},
                       {'id':'b','sha256':'hashb','kind':'schedule','filename':'schedule.pdf'}]
        self.docs=[{**d,'pages':[{'page':1,'text':text,'method':'native_text','needs_verification':False}]} for d in self.expected]
        evidence,_=select_evidence(make_chunks(self.docs),'registration')
        self.output={'artifact_revision':'revision','documents':self.docs,'answer':{'summary':'Review the exclusion.',
            'findings':[{'source_id':evidence[0]['id'],'quote':'excludes registration fees','statement':'Registration fees are excluded in this excerpt.'}],'questions':[]}}

    def test_rebuilds_sources_instead_of_trusting_worker_citations(self):
        docs,answer=validate_assessment(self.output,self.expected,'registration')
        self.assertEqual(answer['total_pages'],2)
        self.assertEqual(answer['findings'][0]['document_id'],'a')

    def test_unknown_and_duplicate_documents_rejected(self):
        for identity in ('unknown','b'):
            altered=copy.deepcopy(self.output);altered['documents'][0]['id']=identity
            with self.assertRaises(ValueError):validate_assessment(altered,self.expected,'registration')

    def test_invented_quote_rejected(self):
        self.output['answer']['findings'][0]['quote']='All expenses are covered in full.'
        with self.assertRaises(ValueError):validate_assessment(self.output,self.expected,'registration')

    def test_invalid_page_number_and_excessive_text_rejected(self):
        for key,value in (('page',99),('text','x'*18001),('method','unverified')):
            altered=copy.deepcopy(self.output);altered['documents'][0]['pages'][0][key]=value
            with self.assertRaises(ValueError):validate_assessment(altered,self.expected,'registration')
