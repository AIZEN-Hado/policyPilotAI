import unittest
from pilot.core import make_chunks,select_evidence,validate_output

class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.e=[{'id':'a:p1:c0','document_id':'a','filename':'wording.pdf','kind':'policy','page':1,'text':'The daily room limit is INR 4,000.00 for this policy.'}]
        self.good={'summary':'Check room benefit.','findings':[{'statement':'The excerpt states a daily room limit.','quote':'daily room limit is INR 4,000.00','source_id':'a:p1:c0'}],'questions':[]}
    def test_valid_citation_has_source(self):
        result=validate_output(self.good,self.e)
        self.assertEqual(result['findings'][0]['document_id'],'a')
        self.assertEqual(result['status'],'REVIEW_REQUIRED')
    def test_unknown_source_rejected(self):
        self.good['findings'][0]['source_id']='other-claim'
        with self.assertRaises(ValueError):validate_output(self.good,self.e)
    def test_invented_quote_rejected(self):
        self.good['findings'][0]['quote']='The daily limit is INR 9,000.00'
        with self.assertRaises(ValueError):validate_output(self.good,self.e)
    def test_missing_evidence_abstains(self):
        self.good['findings']=[]
        self.assertEqual(validate_output(self.good,[])['status'],'REQUIRES_MORE_INFO')
    def test_truncated_context_warns(self):
        self.assertTrue(validate_output(self.good,self.e,True)['questions'])
    def test_non_object_rejected(self):
        with self.assertRaises(ValueError):validate_output([],self.e)
    def test_bad_questions_rejected(self):
        self.good['questions']=['ok',42]
        with self.assertRaises(ValueError):validate_output(self.good,self.e)
    def test_selection_preserves_document_coverage(self):
        chunks=self.e+[dict(self.e[0],id='b:p1:c0',document_id='b',text='A receipt without search terms.')]
        selected,truncated=select_evidence(chunks,'daily room',limit=1000)
        self.assertEqual({x['document_id'] for x in selected},{'a','b'})
        self.assertFalse(truncated)
    def test_budget_signals_partial_context(self):
        selected,truncated=select_evidence(self.e,'room',limit=5)
        self.assertEqual(selected,[]);self.assertTrue(truncated)
    def test_chunk_page_provenance(self):
        chunks=make_chunks([{'id':'a','filename':'bill.pdf','kind':'bill','pages':[{'page':2,'text':'x'*2400}]}])
        self.assertEqual(len(chunks),3);self.assertTrue(all(c['page']==2 for c in chunks))

if __name__=='__main__':unittest.main()
