"""Worker diagnostics with bounded, redacted model-loader reasons and no inputs."""
from contextvars import ContextVar
import errno
import json
import os
import re
import ssl
import sys

PREFIX='POLICYPILOT_DIAGNOSTIC '
STAGES=frozenset(('validate_input','import_torch','import_libraries','validate_config','cuda_check',
    'check_quantizer','download_model','load_tokenizer','load_model','prepare_prompt','generate','parse_output',
    'download_document','extract_document','select_evidence'))
CATEGORIES=frozenset(('missing_dependency','dependency_import','gpu_memory','host_memory',
    'cuda_unavailable','disk_full','permission_denied','remote_http','network_timeout',
    'tls_failure','configuration_or_input','invalid_json','processing_failure'))
TYPES=frozenset(('ModuleNotFoundError','ImportError','OutOfMemoryError','MemoryError','RuntimeError',
    'OSError','PermissionError','TimeoutError','ReadTimeout','ConnectTimeout','HTTPError',
    'HfHubHTTPError','SSLError','KeyError','ValueError','JSONDecodeError'))
_stage=ContextVar('policypilot_worker_stage',default='validate_input')
REASON_STAGES=frozenset(('load_model','check_quantizer'))


def model_reason(exc):
    """Only for RuntimeError in artifact loading or a synthetic quantizer probe.

    Never use this for document, prompt, generation or output exceptions. Model
    loading consumes the pinned artifact and environment, not claim contents.
    """
    try:text=str(exc)
    except Exception:return 'Model loader reason unavailable'
    for key,value in os.environ.items():
        if value and re.search(r'secret|token|password|credential|api.?key|access.?key|authorization|database.?url|dsn|signature',key,re.I):
            text=text.replace(value,'[redacted]')
    text=re.sub(r'https?://[^\s\x22\x27<>]+','[URL]',text,flags=re.I)
    text=re.sub(r'(?i)\b(?:Bearer|Basic)\s+[^\s,;]+','[authorization]',text)
    text=re.sub(r'\b(?:hf_|ghp_|github_pat_|rpa_|rps_|sk-)[A-Za-z0-9_-]+','[token]',text)
    text=re.sub(r'(?i)\b(?:api[_-]?key|access[_-]?token|token|password|secret|authorization)\s*[:=]\s*[\x22\x27]?[^\s,;\x22\x27]+',
                '[credential]',text)
    text=re.sub(r'(?<!\w)/(?:tmp|home|srv|root|run|var)/[^\s\x22\x27(),;]+','[path]',text)
    text=re.sub(r'[\x00-\x1f\x7f]+',' ',text)
    return text[:1600]


def library_frames(exc):
    """Library code locations only: no locals, source lines or arbitrary paths."""
    frames=[];tb=exc.__traceback__
    while tb is not None:
        filename=tb.tb_frame.f_code.co_filename.replace('\\','/')
        relative=filename.split('/site-packages/',1)[-1] if '/site-packages/' in filename else ''
        if re.fullmatch(r'(?:torch|transformers|accelerate|bitsandbytes|safetensors)/[A-Za-z0-9_./-]{1,220}\.py',relative) and '..' not in relative:
            frames.append({'file':relative,'line':tb.tb_lineno})
        tb=tb.tb_next
    return frames[-8:]


def stage(value):
    if value not in STAGES:raise ValueError('Unknown diagnostic stage')
    _stage.set(value)
    print(PREFIX+json.dumps({'event':'stage','stage':value}),flush=True)


def failure(exc):
    name=type(exc).__name__
    category='processing_failure'
    status=getattr(getattr(exc,'response',None),'status_code',None)
    if status is None:status=getattr(exc,'code',None)
    if name=='OutOfMemoryError':category='gpu_memory'
    elif isinstance(exc,MemoryError):category='host_memory'
    elif isinstance(exc,ModuleNotFoundError):category='missing_dependency'
    elif isinstance(exc,ImportError):category='dependency_import'
    elif isinstance(exc,PermissionError):category='permission_denied'
    elif isinstance(exc,OSError) and exc.errno==errno.ENOSPC:category='disk_full'
    elif isinstance(exc,ssl.SSLError):category='tls_failure'
    elif isinstance(exc,TimeoutError) or name in ('ReadTimeout','ConnectTimeout'):category='network_timeout'
    elif type(status) is int and 100<=status<=599:category='remote_http'
    elif name=='JSONDecodeError':category='invalid_json'
    elif isinstance(exc,(KeyError,ValueError)):category='configuration_or_input'
    elif _stage.get()=='cuda_check':category='cuda_unavailable'
    result={'event':'failure','stage':_stage.get(),'category':category,
            'exception_type':name if name in TYPES else 'Exception'}
    # The previous stage/category alone hid useful loader RuntimeError reasons.
    # Restrict error text to this stage/type; no document/prompt errors qualify.
    if _stage.get() in REASON_STAGES and isinstance(exc,RuntimeError):
        result['model_loader_reason']=model_reason(exc)
        frames=library_frames(exc)
        if frames:result['library_frames']=frames
    if type(status) is int and 100<=status<=599:result['http_status']=status
    if sys.platform.startswith('linux'):
        try:
            import resource
            result['peak_rss_bytes']=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)*1024
        except (ImportError,OSError,ValueError):pass
    print(PREFIX+json.dumps(result),flush=True)
    return result


def safe_record(line):
    if not isinstance(line,str) or not line.startswith(PREFIX):return None
    try:value=json.loads(line[len(PREFIX):])
    except ValueError:return None
    if (not isinstance(value,dict) or not isinstance(value.get('stage'),str)
            or value['stage'] not in STAGES or value.get('event') not in ('stage','failure')):
        return None
    result={'event':value['event'],'stage':value['stage']}
    if value['event']=='failure':
        if not isinstance(value.get('category'),str) or value['category'] not in CATEGORIES:return None
        result['category']=value['category']
        if isinstance(value.get('exception_type'),str) and value['exception_type'] in TYPES|{'Exception'}:
            result['exception_type']=value['exception_type']
        code=value.get('http_status')
        if type(code) is int and 100<=code<=599:result['http_status']=code
        rss=value.get('peak_rss_bytes')
        if type(rss) is int and 0<=rss<10**15:result['peak_rss_bytes']=rss
        if (value['stage'] in REASON_STAGES and result.get('exception_type')=='RuntimeError'
                and isinstance(value.get('model_loader_reason'),str)):
            result['model_loader_reason']=model_reason(RuntimeError(value['model_loader_reason']))
            frames=value.get('library_frames')
            if isinstance(frames,list):
                selected=[]
                for frame in frames[:8]:
                    if (isinstance(frame,dict) and isinstance(frame.get('file'),str)
                            and re.fullmatch(r'(?:torch|transformers|accelerate|bitsandbytes|safetensors)/[A-Za-z0-9_./-]{1,220}\.py',frame['file'])
                            and '..' not in frame['file'] and type(frame.get('line')) is int
                            and 0<frame['line']<10000000):
                        selected.append({'file':frame['file'],'line':frame['line']})
                if selected:result['library_frames']=selected
    return result
