"""Conservative session admission estimates, never a provider invoice or hard cap."""
from datetime import datetime,timezone
from decimal import Decimal,InvalidOperation
import os


class BudgetError(ValueError): pass


def reservation_seconds(startup_seconds):
    # Normal jobs retain the conservative 510-second reserve. The previous
    # warm-up policy used startup=60/idle=300; the new one uses startup=180/
    # idle=180. Both total 570 seconds with task=180 and control margin=30.
    if type(startup_seconds) is not int or startup_seconds not in (0,60,180):
        raise BudgetError('Invalid worker startup reservation')
    return {0:510,60:570,180:570}[startup_seconds]


def settings():
    try:
        rate=Decimal(os.environ['RUNPOD_VERIFIED_HOURLY_RATE_USD'])
        limit=Decimal(os.environ['RUNPOD_SESSION_COMPUTE_LIMIT_USD'])
        if not rate.is_finite() or not limit.is_finite() or rate<=0 or limit<=0:
            raise ValueError()
    except (KeyError,ValueError,InvalidOperation):
        raise BudgetError('Configure a verified GPU rate and explicit session compute allowance') from None
    return rate,limit


def estimate(started_at,ended_at=None,now=None):
    rate,limit=settings()
    seconds=Decimal(0)
    if started_at:
        seconds=Decimal(str(max(0,((ended_at or now or datetime.now(timezone.utc))-started_at).total_seconds())))
    return seconds*rate/Decimal(3600),limit


def admit(started_at,ended_at=None,now=None,startup_seconds=0):
    used,limit=estimate(started_at,ended_at,now)
    rate,_=settings()
    # Reserve one 180-second task, 300 seconds idle and 30 seconds control margin.
    # Startup/termination delays and provider retries can exceed this assumption:
    # this blocks admission conservatively but cannot enforce a financial ceiling.
    reserve=rate*Decimal(reservation_seconds(startup_seconds))/Decimal(3600)
    if used+reserve>limit:
        raise BudgetError('Session compute allowance cannot cover another bounded job; stop the model before starting a new session')
    return used


def reserve(conn,startup_seconds=0):
    rate,_=settings()
    amount=rate*Decimal(reservation_seconds(startup_seconds))/Decimal(3600)
    # The model-service advisory lock also serializes this update. Reserve before
    # submitting, commit with job intent, and never auto-refund an uncertain job.
    row=conn.execute('UPDATE inference_allowance SET compute_reserved_usd=compute_reserved_usd+%s '
                     'WHERE id=1 AND compute_reserved_usd+%s<=compute_reservation_limit_usd '
                     'RETURNING compute_reserved_usd',(amount,amount)).fetchone()
    if not row:raise BudgetError('Demo inference reservation allowance exhausted; stop the model and review provider billing')
    return amount


def configured():
    try: settings();return True
    except BudgetError:return False
