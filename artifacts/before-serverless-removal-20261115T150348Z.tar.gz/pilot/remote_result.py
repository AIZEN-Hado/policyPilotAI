"""Rebuild evidence and verify remote output before it becomes a case record."""
from .core import make_chunks,select_evidence,validate_output


def validate_assessment(output,expected,description):
    documents=output.get('documents')
    if not isinstance(documents,list) or len(documents)!=len(expected): raise ValueError('Invalid document response')
    by_id={str(d['id']):d for d in expected};seen=set();validated=[];count=0
    for doc in documents:
        if not isinstance(doc,dict): raise ValueError('Invalid document')
        did=doc.get('id')
        if did not in by_id or did in seen: raise ValueError('Unrecognized or duplicate document')
        seen.add(did);source=by_id[did];pages=doc.get('pages')
        if not isinstance(pages,list) or not 1<=len(pages)<=20: raise ValueError('Invalid pages')
        for number,page in enumerate(pages,1):
            if (not isinstance(page,dict) or type(page.get('page')) is not int or page.get('page')!=number
                    or not isinstance(page.get('text'),str) or len(page['text'])>18000
                    or page.get('method') not in {'native_text','ocr'}
                    or type(page.get('needs_verification')) is not bool): raise ValueError('Invalid extracted page')
        count+=len(pages)
        if count>60: raise ValueError('Case page limit exceeded')
        validated.append({**source,'id':did,'pages':pages})
    selected,partial=select_evidence(make_chunks(validated),description)
    if not {'policy','schedule'}<={e['kind'] for e in selected}: raise ValueError('Required policy context missing')
    answer=validate_output(output.get('answer'),selected,partial)
    answer.update(model=output['artifact_revision'],total_pages=count,
                  ocr_pages=sum(p['method']=='ocr' for d in validated for p in d['pages']),
                  evidence_ids=[e['id'] for e in selected],retrieval='case-scoped lexical selection')
    return validated,answer
