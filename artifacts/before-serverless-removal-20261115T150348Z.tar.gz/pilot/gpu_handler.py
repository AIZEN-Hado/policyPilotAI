"""Runpod queue worker: bounded PDFs, evidence and a revision-pinned GPU model.

Importing this module does not download a model or start a worker.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import urllib.parse
import urllib.request

from .core import make_chunks,select_evidence
from .extract import extract_pdf,ExtractionError
from .review_prompt import SYSTEM,SCHEMA
from .worker_diagnostics import stage,failure
from .compiler_check import check_compiler

_runtime=None


def download_document(doc,path):
    host=os.environ.get('DOCUMENT_DOWNLOAD_HOST','')
    url=urllib.parse.urlsplit(doc['url'])
    if (not host or url.scheme!='https' or url.hostname!=host or url.port not in (None,443)
            or url.username or url.password or url.fragment):
        raise ValueError('Document host not permitted')
    size=doc['bytes'];digest=doc['sha256']
    if type(size) is not int or not 20<=size<=10*1024*1024 or not re.fullmatch('[0-9a-f]{64}',digest):
        raise ValueError('Invalid document metadata')
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs): return None
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    hashed=hashlib.sha256();read=0
    with opener.open(doc['url'],timeout=30) as response,path.open('xb') as target:
        os.chmod(path,0o600)
        while chunk:=response.read(65536):
            read+=len(chunk)
            if read>size: raise ValueError('Document exceeds declared size')
            hashed.update(chunk);target.write(chunk)
    if read!=size or hashed.hexdigest()!=digest: raise ValueError('Document integrity failed')


def check_quantizer(torch):
    """Exercise the actual NF4 CUDA path with tiny synthetic weights first."""
    stage('check_quantizer')
    check_compiler()
    import bitsandbytes as bnb
    from bitsandbytes.cextension import lib
    if lib is None or getattr(lib,'compiled_with_cuda',False) is not True:
        raise RuntimeError('bitsandbytes did not load a CUDA-enabled native library')
    with torch.inference_mode():
        layer=bnb.nn.Linear4bit(64,64,bias=False,compute_dtype=torch.float16,
            compress_statistics=True,quant_type='nf4').to(dtype=torch.float16).to('cuda')
        sample=torch.ones((1,64),device='cuda',dtype=torch.float16)
        output=layer(sample)
        torch.cuda.synchronize()
        if tuple(output.shape)!=(1,64) or not torch.isfinite(output).all().item():
            raise RuntimeError('Synthetic NF4 GPU probe returned invalid values')


def runtime():
    global _runtime
    if _runtime is None:
        stage('import_torch')
        import torch
        stage('import_libraries')
        from huggingface_hub import snapshot_download
        from transformers import AutoModelForCausalLM,AutoTokenizer,BitsAndBytesConfig
        stage('validate_config')
        revision=os.environ['MODEL_REVISION']
        if not re.fullmatch('[a-f0-9]{40}',revision): raise ValueError('Pin the model to a full repository commit')
        stage('cuda_check')
        if not torch.cuda.is_available(): raise RuntimeError('CUDA GPU required')
        check_quantizer(torch)
        # A merged fine-tuned release is supported through the same pinned repo.
        # Never assert that a base model has been fine-tuned.
        stage('download_model')
        path=snapshot_download(os.environ['MODEL_REPOSITORY'],revision=revision,
            allow_patterns=['*.json','*.safetensors','*.model','*.txt','*.jinja'],token=os.environ.get('HF_TOKEN'))
        stage('load_tokenizer')
        tokenizer=AutoTokenizer.from_pretrained(path,trust_remote_code=False)
        stage('load_model')
        model=AutoModelForCausalLM.from_pretrained(path,trust_remote_code=False,use_safetensors=True,
            device_map={'':0},torch_dtype=torch.float16,
            quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',
                bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16))
        model.eval();tokenizer.pad_token=tokenizer.eos_token
        _runtime=(model,tokenizer,revision)
    return _runtime


def generate(prompt,warmup=False):
    model,tokenizer,revision=runtime()
    import torch
    stage('prepare_prompt')
    messages=[{'role':'system','content':SYSTEM+'\nSchema: '+json.dumps(SCHEMA)},
              {'role':'user','content':prompt}]
    data=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,
                                      return_tensors='pt',return_dict=True)
    length=data['input_ids'].shape[-1]
    if length+512>8192: raise ValueError('Required evidence exceeds the model token budget')
    data={key:value.to(model.device) for key,value in data.items()}
    stage('generate')
    with torch.inference_mode():
        result=model.generate(**data,max_new_tokens=64 if warmup else 512,do_sample=False,
                              pad_token_id=tokenizer.pad_token_id)
    tokens=result[0,length:]
    if tokens.numel()==0: raise ValueError('Empty generation')
    text=tokenizer.decode(tokens,skip_special_tokens=True)
    if warmup: return {'warmup_verified':bool(text.strip()),'artifact_revision':revision}
    if len(tokens)>=512 and tokens[-1].item()!=tokenizer.eos_token_id:
        raise ValueError('Model output was truncated')
    stage('parse_output')
    return {'answer':json.loads(text),'artifact_revision':revision}


def process_job(job):
    stage('validate_input')
    payload=job.get('input',{})
    if not isinstance(payload,dict): raise ValueError('Invalid job payload')
    if payload.get('artifact_revision')!=os.environ.get('MODEL_REVISION'):
        raise ValueError('Requested model artifact does not match worker release')
    task=payload.get('task')
    if task=='warmup': return generate('Return a short neutral JSON summary saying this is a synthetic warm-up, with empty findings and questions.',True)
    if task=='chat':
        question=payload['question'];evidence=payload['evidence']
        if not isinstance(question,str) or not 8<=len(question)<=1200: raise ValueError('Invalid question')
        if not isinstance(evidence,list) or len(json.dumps(evidence))>80000: raise ValueError('Invalid evidence')
        return generate(json.dumps({'question':question,'excerpts':evidence,'partial_context':payload['partial_context']}))
    if task!='assess': raise ValueError('Unknown job task')
    documents=payload.get('documents');description=payload.get('description')
    if not isinstance(documents,list) or not 1<=len(documents)<=12: raise ValueError('Document limit exceeded')
    if not isinstance(description,str) or not 20<=len(description)<=3000: raise ValueError('Invalid claim context')
    pages=0;processed=[];ids=set()
    with tempfile.TemporaryDirectory(prefix='remote-claim-') as directory:
        for index,doc in enumerate(documents):
            if doc['id'] in ids: raise ValueError('Duplicate document')
            ids.add(doc['id']);path=Path(directory)/f'{index}.pdf'
            stage('download_document')
            download_document(doc,path)
            stage('extract_document')
            extracted=extract_pdf(path,20);path.unlink()
            pages+=len(extracted)
            if pages>60: raise ExtractionError('Case exceeds 60 pages')
            processed.append({key:doc[key] for key in ('id','kind','filename')}|{'pages':extracted})
        stage('select_evidence')
        evidence,partial=select_evidence(make_chunks(processed),description)
        if not {'policy','schedule'}<={e['kind'] for e in evidence}: raise ValueError('Required policy context missing')
        result=generate(json.dumps({'claim_description':description,'excerpts':evidence,'partial_context':partial}))
    result['documents']=processed
    return result


def handler(job):
    try: return process_job(job)
    except Exception as exc:
        # Provider SDK captures exceptions; never include signed document URLs,
        # credentials, source text or raw model output in its error records.
        diagnostic=failure(exc)
        raise RuntimeError('PolicyPilot worker failure: '+json.dumps(diagnostic)) from None


if __name__=='__main__':
    import runpod
    # Deliberately one job per worker. Provider retry policy must also be verified.
    runpod.serverless.start({'handler':handler})
