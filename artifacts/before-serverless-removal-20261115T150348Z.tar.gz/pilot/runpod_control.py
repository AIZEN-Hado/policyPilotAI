"""Fixed-endpoint control; repeat only confirmed paused warm-up rejections."""
import json
import logging
import re
import time
import urllib.error
import urllib.request

logger=logging.getLogger(__name__)


class ProviderError(Exception):
    pass


class EndpointPaused(ProviderError):
    """Explicit HTTP 409/ENDPOINT_PAUSED without a job acknowledgement."""


def paused_rejection(raw):
    try:
        value=json.loads(raw)
    except (ValueError,UnicodeError): return False
    if not isinstance(value,dict) or 'id' in value or 'jobId' in value: return False
    fields={'status','code','detail','title','type','instance'}
    if not set(value)<=fields|{'message'}: return False
    error=value.get('message',value)
    return (isinstance(error,dict) and error.get('code')=='ENDPOINT_PAUSED'
            and set(error)<=fields and type(error.get('status',409)) is int
            and error.get('status',409)==409)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None


class Runpod:
    def __init__(self,endpoint,management_key,inference_key,transport=None):
        if not re.fullmatch(r'[A-Za-z0-9_-]{3,80}',endpoint):
            raise ValueError('Invalid endpoint ID')
        self.endpoint=endpoint
        self.management_key=management_key
        self.inference_key=inference_key
        self.transport=transport or urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())

    def call(self,path,method='GET',body=None,control=False):
        key=self.management_key if control else self.inference_key
        if not key: raise ProviderError('Provider credential missing')
        root='https://api.runpod.io/v2/serverless/' if control else 'https://api.runpod.ai/v2/'
        request=urllib.request.Request(root+self.endpoint+path,method=method,
            data=None if body is None else json.dumps(body).encode(),
            headers={'Authorization':'Bearer '+key,'Accept':'application/json','Content-Type':'application/json'})
        # Never put URLs, job IDs, credentials, request data or provider bodies
        # in diagnostics. These static operation labels remain safe for logs/UI.
        if control:
            operation='control_update' if method=='PATCH' else 'control_read'
        else:
            operation={'/run':'submit','/health':'health'}.get(path,'inference_read')
            if path.startswith('/status/'): operation='job_status'
            elif path.startswith('/cancel/'): operation='job_cancel'
        failure=None
        paused=False
        try:
            with self.transport.open(request,timeout=20) as response:
                content=response.read(4*1024*1024+1)
                if len(content)>4*1024*1024: raise ValueError()
                data=json.loads(content)
                if not isinstance(data,dict): raise ValueError()
                return data
        except urllib.error.HTTPError as exc:
            code=exc.code if type(exc.code) is int and 100<=exc.code<=599 else 'unknown'
            failure=f'HTTP {code}'
            try:
                if code==409:
                    raw=exc.read(16385)
                    paused=len(raw)<=16384 and paused_rejection(raw)
            except OSError: pass
            finally: exc.close()
            if paused: failure+=' (ENDPOINT_PAUSED)'
        except TimeoutError:
            failure='timeout'
        except urllib.error.URLError as exc:
            failure='timeout' if isinstance(exc.reason,TimeoutError) else 'network failure'
        except (ValueError,UnicodeError):
            failure='invalid response'
        except Exception:
            failure='transport failure'
        message=f'Runpod {operation}: {failure}; reconcile before retrying paid work'
        logger.warning('%s',message)
        raise (EndpointPaused if paused else ProviderError)(message) from None

    def settings(self): return self.call('',control=True)

    def scale(self,enabled):
        idle=180 if enabled else 300
        self.call('',method='PATCH',control=True,body={'workers':{'min':0,'max':1 if enabled else 0,'idleTimeout':idle}})
        settings=self.settings()
        workers=settings.get('workers',{})
        if (workers.get('min')!=0 or workers.get('max')!=(1 if enabled else 0)
                or workers.get('idleTimeout')!=idle):
            raise ProviderError('Scaling settings were not confirmed')
        return settings

    def health(self): return self.call('/health')

    def activate_worker(self,clock=time.monotonic,sleep=time.sleep):
        """Request a temporary worker and observe it through the invoke API.

        This observes allocation, not a loaded model or a hot handler. A real
        generation job must still prove readiness. Caller must restore min=0.
        """
        end=clock()+180
        self.call('',method='PATCH',control=True,body={'workers':{'min':1,'max':1,'idleTimeout':180}})
        workers=self.settings().get('workers',{})
        if not isinstance(workers,dict) or any(type(workers.get(k)) is not int or workers[k]!=1 for k in ('min','max')):
            raise ProviderError('Temporary worker settings were not confirmed')
        while True:
            health=self.health();workers=health.get('workers',{})
            jobs=health.get('jobs',{})
            if (not isinstance(workers,dict) or not isinstance(jobs,dict)
                    or any(type(workers.get(k)) is not int or workers[k]<0 for k in ('running','ready','initializing','unhealthy'))
                    or any(type(jobs.get(k)) is not int or jobs[k]!=0 for k in ('inProgress','inQueue'))
                    or workers['unhealthy']!=0):
                raise ProviderError('Runtime jobs or worker health are not clear for warm-up')
            if clock()>=end:
                raise ProviderError('Invoke API did not observe worker activation within 180 seconds; no job submitted')
            if any(type(workers.get(k)) is int and workers[k]>0 for k in ('running','ready')):
                return
            sleep(min(5,max(0,end-clock())))

    def submit(self,payload,resume_paused=False):
        body={'input':payload,'policy':{'executionTimeout':180000,'ttl':600000}}
        for attempt in range(3 if resume_paused else 1):
            try:
                result=self.call('/run',method='POST',body=body)
                return self.job_id(result.get('id'))
            except EndpointPaused as exc:
                # An unknown conflict, timeout, lost acknowledgement or invalid
                # success response is NEVER repeated. Only this explicit refusal
                # means no job was accepted. Use the same request/reservation.
                if not resume_paused or attempt==2: raise
                time.sleep(5)
                try:
                    workers=self.settings().get('workers',{})
                except ProviderError:
                    raise exc
                if (type(workers.get('max')) is not int or workers['max']!=1
                        or type(workers.get('min')) is not int or workers['min']!=0):
                    raise exc

    @staticmethod
    def job_id(value):
        if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{3,160}',value):
            raise ProviderError('Provider job identifier not confirmed')
        return value

    def status(self,job): return self.call('/status/'+self.job_id(job))
    def cancel(self,job): return self.call('/cancel/'+self.job_id(job),method='POST')


def confirmed_idle(health):
    """Missing/malformed provider fields must never become an 'off' indication."""
    groups={'workers':('running','ready','initializing','unhealthy'),
            'jobs':('inProgress','inQueue')}
    for group,keys in groups.items():
        values=health.get(group,{})
        for key in keys:
            value=values.get(key)
            if type(value) is not int or value!=0: return False
    return True
