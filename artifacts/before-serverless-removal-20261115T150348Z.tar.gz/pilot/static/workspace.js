'use strict';
(()=>{
 const byId=id=>document.getElementById(id);
 let model={configured:false,enabled:false,state:'unavailable'},caseId=null,canAsk=false,busy=false,timer=null;
 const states={off:'Model off',starting:'Starting worker',loading:'Loading and verifying model',ready:'Ready for questions',idle:'Worker scaled down · starts on next question',processing:'Processing',stopping:'Stopping · waiting for confirmation',error:'Model needs attention',unavailable:'Connection unavailable'};
 async function request(path,options={}){
  const r=await fetch('/api'+path,{credentials:'same-origin',...options});
  if(r.status===401){location.replace('/login');throw Error('Please sign in.');}
  const body=await r.json();if(!r.ok)throw Object.assign(Error(typeof body.detail==='string'?body.detail:'Service unavailable.'),{body});return body;
 }
 function update(){
  byId('model-status').textContent=states[model.state]||'Status unavailable';
  byId('model-name').textContent=model.model||'Private model · not connected';
  byId('model-note').textContent=model.detail||'Source documents remain available with the model off. Stop affects all users in this workspace.';
  byId('start-model').disabled=busy||!model.configured||!model.operator||!model.can_start||model.enabled||model.state==='stopping';
  byId('stop-model').disabled=busy||!model.configured||!model.operator||model.state==='off';
  const estimate=Number.isFinite(model.estimate_usd)?'Wall-time estimate $'+model.estimate_usd.toFixed(3):'Cost estimate unavailable';
  byId('model-cost').textContent=estimate;
  byId('model-cost').title=Number.isFinite(model.demo_compute_reserved_usd)?'Demo compute reserved: $'+model.demo_compute_reserved_usd.toFixed(3)+' · approved total $'+model.demo_inference_allowance_usd.toFixed(2)+' includes overhead. Reservations are not an invoice.':estimate;
  byId('model-time').textContent=model.started_at&&model.state!=='off'?'Session opened '+new Date(model.started_at).toLocaleTimeString('en-IN'):'No active session verified';
  window.PolicyOrb?.set(model.state);
  const allowed=caseId&&canAsk&&model.operator&&model.enabled&&['ready','idle'].includes(model.state)&&!busy;
  byId('chat-question').disabled=!allowed;byId('chat-send').disabled=!allowed;
  byId('chat-hint').textContent=!canAsk?'Process documents before asking a question.':!model.configured?'Connect the model to enable conversation.':!model.enabled?'Start the model to ask about this case.':'Answers use this case’s extracted evidence.';
 }
 async function refreshModel(){
  try{model=await request('/model/status');}
  catch(e){model={...model,state:'unavailable',detail:e.message};if(e.body)model={...model,...e.body};}
  update();clearTimeout(timer);timer=setTimeout(refreshModel,model.configured?5000:20000);
 }
 async function control(action){
  busy=true;update();
  try{await request('/model/'+action,{method:'POST'});await refreshModel();}
  catch(e){byId('message').textContent=e.message;byId('message').className='error';}
  finally{busy=false;update();}
 }
 async function refreshCleanup(){if(!model.operator)return;try{const counts=await request('/storage/cleanup');byId('cleanup-status').textContent=counts.pending+' cleanup tasks pending · '+counts.eligible+' eligible now';}catch(e){byId('cleanup-status').textContent=e.message;}}
 byId('about').addEventListener('click',refreshCleanup);
 byId('cleanup-retry').onclick=async()=>{const button=byId('cleanup-retry');button.disabled=true;try{await request('/storage/cleanup',{method:'POST'});await refreshCleanup();}catch(e){byId('cleanup-status').textContent=e.message;}finally{button.disabled=false;}};
 byId('start-model').onclick=()=>control('start');byId('stop-model').onclick=()=>control('stop');
 function node(tag,text,cls){const el=document.createElement(tag);el.textContent=text;if(cls)el.className=cls;return el;}
 async function conversation(){
  if(!caseId)return;const requested=caseId;
  try{
   const rows=await request('/cases/'+requested+'/messages');if(caseId!==requested)return;
   const thread=byId('chat-thread');thread.replaceChildren();let pending=false;
   for(const row of rows){
    const q=node('article','','chat-message user');q.append(node('div','YOU','message-author'),node('p',row.question));thread.append(q);
    const answer=node('article','','chat-message assistant');answer.append(node('div','POLICYPILOT','message-author'));
    if(row.response){
     if(row.stale)answer.append(node('p','Documents changed. Recheck these earlier sources.','ocr-tag'));
     answer.append(node('p',row.response.summary));
     for(const finding of row.response.findings){answer.append(node('p',finding.statement));const citation=node('button',finding.filename+' · page '+finding.page+' — “'+finding.quote+'”','textbutton chat-citation');citation.type='button';citation.onclick=()=>document.dispatchEvent(new CustomEvent('policy:evidence',{detail:{documentId:finding.document_id,page:finding.page}}));answer.append(citation);}
     for(const question of row.response.questions)answer.append(node('p',question,'small'));
    }else if(row.state==='pending'){pending=true;answer.append(node('p','Waiting for the model response.','small'));}
    else answer.append(node('p',row.state==='stale'?'The documents changed before this answer completed.':'This question did not complete. Check model status before retrying.','small'));
    thread.append(answer);
   }
   byId('chat-wait').hidden=!pending;canAsk=canAsk&&!pending;update();window.PolicyOrb?.refresh();
  }catch(e){byId('chat-hint').textContent=e.message;}
 }
 document.addEventListener('policy:case',e=>{caseId=e.detail?.id||null;canAsk=Boolean(e.detail?.processed);update();conversation();});
 byId('chat-form').onsubmit=async e=>{
  e.preventDefault();if(!caseId||busy)return;busy=true;update();
  try{await request('/cases/'+caseId+'/messages',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:byId('chat-question').value})});byId('chat-question').value='';await conversation();}
  catch(error){byId('message').textContent=error.message;byId('message').className='error';}
  finally{busy=false;update();}
 };
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){refreshModel();conversation();}});
 setInterval(()=>{if(model.started_at&&model.state!=='off'&&!document.hidden){const seconds=Math.max(0,Math.floor((Date.now()-new Date(model.started_at))/1000));byId('model-time').textContent=Math.floor(seconds/60)+'m '+String(seconds%60).padStart(2,'0')+'s session wall time';}},1000);
 request('/auth/me').then(user=>{model.operator=Boolean(user.model_operator);byId('cleanup-tools').hidden=!model.operator;update();}).catch(()=>{});
 refreshModel();
})();
