/* Depth illusion through Canvas 2D projection and shading; no WebGL context. */
'use strict';
(()=>{
 const canvases=new Map(),motion=matchMedia('(prefers-reduced-motion: reduce)');
 let frame=null,last=0;
 const activeStates=new Set(['starting','loading','processing','queued','stopping']);
 function paint(canvas,time){
  const ctx=canvas.getContext('2d');if(!ctx)return;
  const rect=canvas.getBoundingClientRect();if(!rect.width||!rect.height)return;
  const dpr=Math.min(devicePixelRatio||1,1.5),w=rect.width,h=rect.height;
  if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
  const state=canvas.dataset.state||'off',busy=activeStates.has(state),still=motion.matches||!busy;
  const t=still?0:time*.00032,r=Math.min(w,h)*.29,cx=w/2,cy=h/2;
  const dim=state==='off'||state==='unavailable',a=dim?.35:1;
  ctx.globalAlpha=a;
  const halo=ctx.createRadialGradient(cx,cy,0,cx,cy,r*1.7);halo.addColorStop(0,'#a5f9c42e');halo.addColorStop(1,'#a5f9c400');
  ctx.fillStyle=halo;ctx.fillRect(0,0,w,h);
  const points=[];
  for(let band=0;band<6;band++){
   const lat=(band-2.5)*.30;
   for(let i=0;i<96;i++){
    const angle=i/96*Math.PI*2+t*(band%2?-1:1),wave=Math.sin(angle*3+band+t)*.075;
    let x=Math.cos(angle)*Math.cos(lat+wave),y=Math.sin(lat+wave),z=Math.sin(angle)*Math.cos(lat+wave);
    const ty=y*.80-z*.60,tz=y*.60+z*.80;
    points.push({x:cx+x*r*(1+tz*.11),y:cy+ty*r*(1+tz*.11),z:tz,band,i});
   }
  }
  points.sort((p,q)=>p.z-q.z);
  // Far ribbons sit behind the opaque core; near ribbons are drawn afterward.
  const draw=p=>{ctx.globalAlpha=a*(.15+(p.z+1)*.37);ctx.fillStyle=p.z>.25?'#caffdc':'#71ab84';ctx.beginPath();ctx.arc(p.x,p.y,(w<80?.6:.95)+(p.z+1)*.45,0,Math.PI*2);ctx.fill();};
  points.filter(p=>p.z<0).forEach(draw);
  ctx.globalAlpha=a;const core=ctx.createRadialGradient(cx-r*.24,cy-r*.3,r*.05,cx,cy,r*.83);
  core.addColorStop(0,'#ecfff0');core.addColorStop(.18,'#b7e3c3');core.addColorStop(.48,'#527860');core.addColorStop(.79,'#1d3827');core.addColorStop(1,'#0c1c12');
  ctx.fillStyle=core;ctx.beginPath();ctx.arc(cx,cy,r*.76,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#baffd433';ctx.lineWidth=1;ctx.stroke();points.filter(p=>p.z>=0).forEach(draw);ctx.globalAlpha=1;
 }
 function visible(c){const b=c.getBoundingClientRect();return b.width&&b.height&&b.bottom>0&&b.top<innerHeight;}
 function loop(time){frame=null;if(document.hidden)return;
  let animate=false;
  for(const [c,s] of canvases){if(!c.isConnected){canvases.delete(c);continue;}if(!visible(c))continue;
   const state=c.dataset.state||'off';const moving=activeStates.has(state)&&!motion.matches;
   if(s.dirty||moving&&time-last>32){paint(c,time);s.dirty=false;}animate=animate||moving;
  }
  if(time-last>32)last=time;if(animate)frame=requestAnimationFrame(loop);
 }
 function wake(){for(const s of canvases.values())s.dirty=true;if(frame===null)frame=requestAnimationFrame(loop);}
 window.PolicyOrb={refresh(){document.querySelectorAll('canvas[data-orb]').forEach(c=>{if(!canvases.has(c))canvases.set(c,{dirty:true});});wake();},set(state){document.querySelectorAll('canvas[data-orb="model"]').forEach(c=>c.dataset.state=state);wake();}};
 new MutationObserver(()=>PolicyOrb.refresh()).observe(document.body,{childList:true,subtree:true});
 document.addEventListener('visibilitychange',wake);addEventListener('resize',wake);addEventListener('scroll',wake,{passive:true});motion.addEventListener('change',wake);PolicyOrb.refresh();
})();
