import json
import time
import httpx
import psycopg
from psycopg.types.json import Jsonb
from . import config
from .db import connect
from .storage import get_storage, materialize
from .storage_cleanup import cleanup_pending
from .inference import generate
from .core import make_chunks, select_evidence, validate_output
from .extract import extract_pdf, ExtractionError

from .review_prompt import SCHEMA, SYSTEM

def process(case):
    cid=case['id']
    with connect() as conn:
        docs=conn.execute('SELECT * FROM documents WHERE case_id=%s ORDER BY id',(cid,)).fetchall()
    page_count=0
    for doc in docs:
        doc['id']=str(doc['id'])
        with materialize(get_storage(),doc['id'],doc['bytes'],doc['sha256'],config.MAX_FILE) as path:
            pages=extract_pdf(path,config.MAX_PAGES)
        page_count+=len(pages)
        if page_count>60: raise ExtractionError('Case exceeds the 60-page processing limit')
        doc['pages']=pages
        if doc['kind'] in {'policy','schedule'} and not any(len(p['text'].strip()) >= 50 for p in pages):
            raise ExtractionError('Policy or schedule text is unreadable; provide a clearer PDF')
        with connect() as conn:
            conn.execute('UPDATE documents SET pages=%s WHERE id=%s',(Jsonb(pages),doc['id']))
            conn.execute('INSERT INTO events(case_id,action,actor) VALUES(%s,%s,%s)',(cid,'document_text_extracted','local-worker'))
    chunks=make_chunks(docs)
    if not chunks: raise ExtractionError('No readable text found; supply clearer documents')
    selected,truncated=select_evidence(chunks,case['description'])
    if not {'policy','schedule'}.issubset({e['kind'] for e in selected}):
        raise ExtractionError('Policy and schedule evidence did not fit the review context; reduce the case size')
    with connect() as conn:
        conn.execute('INSERT INTO events(case_id,action,actor) VALUES(%s,%s,%s)',(cid,'private_inference_started','local-worker'))
    response=generate(SYSTEM,json.dumps({'claim_description':case['description'],'excerpts':selected,'partial_context':truncated},ensure_ascii=False),SCHEMA)
    result=validate_output(response,selected,truncated)
    result['model']=config.MODEL
    result['retrieval']='case-scoped lexical selection (pilot baseline)'
    result['ocr_pages']=sum(p['method']=='ocr' for d in docs for p in d['pages'])
    result['total_pages']=page_count
    result['evidence_ids']=[e['id'] for e in selected]
    if result['ocr_pages']:
        result['questions'].insert(0,'Verify text extracted from scanned pages against the originals before relying on it.')
    with connect() as conn:
        conn.execute("UPDATE cases SET state='ready',result=%s,error=NULL,updated_at=now() WHERE id=%s",(Jsonb(result),cid))
        conn.execute('INSERT INTO events(case_id,action,actor) VALUES(%s,%s,%s)',(cid,'assessment_ready_for_review','local-worker'))

def main():
    # One worker per deployment; lock lasts as long as this dedicated connection.
    # Restart recovers interrupted work rather than losing in-process background tasks.
    with psycopg.connect(config.DATABASE_URL,autocommit=True) as lock:
        lock.execute('SELECT pg_advisory_lock(519825)')
        with connect() as conn:
            conn.execute("UPDATE cases SET state='queued',error=NULL WHERE state='processing'")
        while True:
            lock.execute('SELECT 1')
            cleanup_pending()
            with connect() as conn:
                case=conn.execute("SELECT * FROM cases WHERE state='queued' ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1").fetchone()
                if case:
                    conn.execute("UPDATE cases SET state='processing',updated_at=now() WHERE id=%s",(case['id'],))
                    conn.execute('INSERT INTO events(case_id,action,actor) VALUES(%s,%s,%s)',(case['id'],'processing_started','local-worker'))
            if not case:
                time.sleep(2); continue
            try: process(case)
            except Exception as exc:
                if isinstance(exc,ExtractionError): message=str(exc)
                elif isinstance(exc,(ValueError,KeyError)): message='Model response could not be verified. Review documents or retry.'
                else: message='Private processing unavailable. Check model readiness and retry.'
                with connect() as conn:
                    conn.execute("UPDATE cases SET state='failed',error=%s,result=NULL,updated_at=now() WHERE id=%s",(message,case['id']))
                    conn.execute('INSERT INTO events(case_id,action,actor) VALUES(%s,%s,%s)',(case['id'],'processing_failed','local-worker'))

if __name__=='__main__': main()
