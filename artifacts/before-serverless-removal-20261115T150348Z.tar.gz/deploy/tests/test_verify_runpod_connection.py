from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('verify_connection', Path(__file__).resolve().parents[1] / 'verify_runpod_connection.py')
connection = importlib.util.module_from_spec(spec)
spec.loader.exec_module(connection)


class ConnectionTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.expected = connection.payload(
            {'model': {'repository': 'Qwen/Qwen2.5-7B-Instruct', 'revision': 'a'*40},
             'image': 'ghcr.io/aizen-hado/policypilot-gpu@sha256:' + 'b'*64,
             'gpu': {'pool': 'AMPERE_24'}}, 'c'*32, 'registry-test', 'endpoint-test')
        self.actual = {**deepcopy(self.expected), 'id': 'endpoint-test'}
        self.health_data = {'workers': {k: 0 for k in ('running', 'ready', 'initializing', 'unhealthy')},
                            'jobs': {'inProgress': 0, 'inQueue': 0}}
        self.reject_patch = False
        self.corrupt_after_patch = False

    def call(self, path, method='GET', body=None):
        self.calls.append((path, method, body))
        if method == 'PATCH':
            if self.reject_patch: raise connection.ProviderHTTPError('synthetic-secret', 403)
            if self.corrupt_after_patch: self.actual['workers']['max'] = 1
            return {}
        if path.endswith('/workers'):
            return {'workers': [], 'summary': {k: 0 for k in ('running','idle','initializing','throttled','unhealthy','total')}}
        return self.actual

    def health(self):
        self.calls.append(('/health', 'GET', None))
        return self.health_data

    def run_check(self, path, write=True):
        return connection.verify(self, self, 'endpoint-test', self.expected, path, write)

    def test_disabled_patch_verified_with_no_job_or_enable_call(self):
        with tempfile.TemporaryDirectory() as folder:
            report = self.run_check(Path(folder)/'report.json')
        self.assertEqual(report['result'], 'PASS')
        self.assertTrue(report['control_write_verified'])
        self.assertFalse(report['inference_submission_permission_verified'])
        writes = [c for c in self.calls if c[1] != 'GET']
        self.assertEqual(writes, [('/v2/serverless/endpoint-test', 'PATCH',
                                  {'workers': {'min': 0, 'max': 0, 'idleTimeout': 300}})])
        self.assertEqual(sum(c[0].endswith('/workers') for c in self.calls), 2)

    def test_read_only_default_performs_no_writes(self):
        with tempfile.TemporaryDirectory() as folder:
            report = self.run_check(Path(folder)/'report.json', False)
        self.assertFalse(report['control_write_attempted'])
        self.assertTrue(all(c[1] == 'GET' for c in self.calls))

    def test_active_or_unknown_health_blocks_patch(self):
        for value in ({}, {'workers': None, 'jobs': {}},
                      {**self.health_data, 'jobs': {'inProgress': 0, 'inQueue': 1}}):
            self.calls.clear(); self.health_data = value
            with tempfile.TemporaryDirectory() as folder, self.assertRaises(connection.SetupError):
                self.run_check(Path(folder)/'report.json')
            self.assertTrue(all(c[1] == 'GET' for c in self.calls))

    def test_enabled_endpoint_blocks_patch(self):
        self.actual['workers']['max'] = 1
        with tempfile.TemporaryDirectory() as folder, self.assertRaises(connection.SetupError):
            self.run_check(Path(folder)/'report.json')
        self.assertTrue(all(c[1] == 'GET' for c in self.calls))

    def test_permission_failure_reports_stage_and_code_without_secrets(self):
        self.reject_patch = True
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'report.json'
            with self.assertRaises(connection.SetupError) as error: self.run_check(path)
            saved = path.read_text()
        self.assertNotIn('synthetic-secret', saved + str(error.exception))
        self.assertEqual(json.loads(saved)['http_status'], 403)
        self.assertEqual(json.loads(saved)['result'], 'CHECK')
        self.assertFalse(json.loads(saved)['control_write_verified'])

    def test_post_write_readback_mismatch_is_not_success(self):
        self.corrupt_after_patch = True
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'report.json'
            with self.assertRaises(connection.SetupError): self.run_check(path)
            self.assertEqual(json.loads(path.read_text())['result'], 'CHECK')
