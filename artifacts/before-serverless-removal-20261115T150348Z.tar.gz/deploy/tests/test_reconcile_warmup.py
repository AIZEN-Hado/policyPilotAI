from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import Mock

spec=importlib.util.spec_from_file_location('recovery',Path(__file__).resolve().parents[1]/'reconcile_warmup.py')
recovery=importlib.util.module_from_spec(spec);spec.loader.exec_module(recovery)


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        began=datetime(2026,11,11,12,35,7,tzinfo=timezone.utc)
        created=began+timedelta(seconds=4)
        self.expected={'env':{'MODEL_REPOSITORY':'Qwen/Qwen2.5-7B-Instruct','MODEL_REVISION':'a'*40}}
        self.app={'configured':True,'operator':True,'enabled':False,'can_start':False,'state':'error',
                  'model':'Qwen/Qwen2.5-7B-Instruct','started_at':created.isoformat(),'demo_compute_reserved_usd':.10625}
        self.control={'enabled':False,'phase':'stopping','model_revision':None,'warmup_job':None,
                      'db_now':created+timedelta(hours=2),'started_at':created,'generation':2}
        jid='11111111-2222-3333-4444-555555555555'
        self.job={'id':jid,'provider_id':None,'generation':1,'kind':'warmup','case_id':None,'state':'uncertain',
                  'created_at':created,'reserved_compute_usd':Decimal('.10625'),'request_id':jid,'task':'warmup','artifact_revision':'a'*40}
        self.ledger={'compute_reserved_usd':Decimal('.10625'),'approved_total_usd':Decimal('1'),
                     'compute_reservation_limit_usd':Decimal('.70')}
        self.attempt={'recorded_at':began.isoformat(),'elapsed_seconds':193.62,'provider_shutdown_verified':True}
        self.sql=[]

    def validate(self):
        return recovery.validate_candidate(self.app,self.control,[self.job],self.ledger,self.attempt,self.expected)

    def conn(self):
        def execute(sql,params=None):
            self.sql.append((sql,params)); result=Mock()
            if 'pg_try_advisory_xact_lock' in sql: result.fetchone.return_value={'acquired':True}
            elif 'FROM model_control' in sql: result.fetchone.return_value=deepcopy(self.control)
            elif 'FROM model_jobs' in sql: result.fetchall.return_value=[deepcopy(self.job)]
            elif 'FROM inference_allowance' in sql: result.fetchone.return_value=deepcopy(self.ledger)
            elif sql.startswith('UPDATE model_jobs'): result.fetchone.return_value={'id':self.job['id']}
            return result
        conn=Mock(); conn.execute.side_effect=execute
        return conn

    def test_expired_candidate_matches_same_live_app_and_reserved_attempt(self):
        job,reserved,stop_bound=self.validate()
        self.assertEqual(job['id'],self.job['id'])
        self.assertEqual(reserved,Decimal('.10625'))
        self.assertLess(stop_bound,self.control['db_now'])

    def test_missing_or_unverified_shutdown_evidence_blocks_recovery(self):
        for field,value in (('provider_shutdown_verified',False),('elapsed_seconds',None),('elapsed_seconds',4000)):
            original=deepcopy(self.attempt); self.attempt[field]=value
            with self.assertRaises(recovery.SetupError): self.validate()
            self.attempt=original

    def test_enabled_budget_or_different_live_session_blocks_recovery(self):
        for field,value in (('can_start',True),('enabled',True),('operator',False),
                            ('started_at','2026-11-10T12:35:11+00:00'),('demo_compute_reserved_usd',0)):
            original=deepcopy(self.app); self.app[field]=value
            with self.assertRaises(recovery.SetupError): self.validate()
            self.app=original

    def test_young_job_or_unrelated_rehearsal_timestamp_blocks_recovery(self):
        self.control['db_now']=self.job['created_at']+timedelta(minutes=14)
        with self.assertRaises(recovery.SetupError): self.validate()
        self.control['db_now']=self.job['created_at']+timedelta(hours=2)
        self.attempt['recorded_at']='2026-11-10T12:35:07+00:00'
        with self.assertRaises(recovery.SetupError): self.validate()

    def test_nonwarmup_known_provider_job_or_completed_job_never_reconciled(self):
        for field,value in (('kind','assess'),('provider_id','provider-known'),('case_id','case-id'),
                            ('state','COMPLETED'),('task','chat'),('artifact_revision','b'*40),('request_id','different')):
            original=deepcopy(self.job); self.job[field]=value
            with self.assertRaises(recovery.SetupError): self.validate()
            self.job=original

    def test_more_than_one_job_or_ledger_mismatch_blocks_recovery(self):
        with self.assertRaises(recovery.SetupError):
            recovery.validate_candidate(self.app,self.control,[self.job,self.job],self.ledger,self.attempt,self.expected)
        self.ledger['compute_reserved_usd']=Decimal('.2125')
        with self.assertRaises(recovery.SetupError): self.validate()

    def test_preview_runs_fresh_idle_check_but_no_data_mutations(self):
        idle=Mock(); report={}
        recovery.reconcile(self.conn(),self.app,self.attempt,self.expected,idle,report)
        idle.assert_called_once()
        self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in self.sql))
        self.assertTrue(report['candidate_verified'])
        self.assertNotIn('database_update_prepared',report)

    def test_apply_targets_only_matching_job_and_preserves_ledger(self):
        idle=Mock(); report={}
        recovery.reconcile(self.conn(),self.app,self.attempt,self.expected,idle,report,True)
        writes=[(s,p) for s,p in self.sql if not s.startswith('SELECT ')]
        self.assertEqual(len(writes),3)
        self.assertIn("state='RECONCILED_EXPIRED'",writes[0][0])
        self.assertEqual(writes[0][1],(self.job['id'],'uncertain'))
        self.assertTrue(all('UPDATE inference_allowance' not in sql for sql,_ in writes))
        self.assertEqual(report['refund_usd'],'0')
        self.assertFalse(report['outcome_verified'])
        self.assertTrue(report['database_update_prepared'])

    def test_unknown_provider_state_blocks_all_database_writes(self):
        idle=Mock(side_effect=recovery.SetupError('Provider unavailable'))
        with self.assertRaises(recovery.SetupError):
            recovery.reconcile(self.conn(),self.app,self.attempt,self.expected,idle,{},True)
        self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in self.sql))

    def test_concurrent_app_operation_blocks_all_recovery_work(self):
        conn=Mock(); conn.execute.return_value.fetchone.return_value={'acquired':False}; idle=Mock()
        with self.assertRaises(recovery.SetupError):
            recovery.reconcile(conn,self.app,self.attempt,self.expected,idle,{},True)
        conn.execute.assert_called_once(); idle.assert_not_called()

    def followup(self):
        old=deepcopy(self.job)
        old.update(id='00000000-2222-3333-4444-555555555555',state='RECONCILED_EXPIRED')
        self.app['demo_compute_reserved_usd']=.2125
        self.ledger['compute_reserved_usd']=Decimal('.2125')
        self.attempt['prior_compute_reserved_usd']='.10625'
        prior={'job_id':old['id'],'result':'PASS','database_committed':True,'reserved_compute_usd':'.10625'}
        return old,prior

    def test_followup_preserves_prior_job_and_entire_ledger(self):
        old,prior=self.followup()
        conn=self.conn(); original=conn.execute.side_effect
        def execute(sql,params=None):
            result=original(sql,params)
            if 'FROM model_jobs' in sql: result.fetchall.return_value=[old,deepcopy(self.job)]
            return result
        conn.execute.side_effect=execute
        report={};idle=Mock()
        recovery.reconcile(conn,self.app,self.attempt,self.expected,idle,report,True,prior)
        self.assertEqual(Decimal(report['reserved_compute_usd']),Decimal('.2125'))
        writes=[(s,p) for s,p in self.sql if s.startswith('UPDATE model_jobs')]
        self.assertEqual(writes[0][1],(self.job['id'],'uncertain'))
        self.assertFalse(any('UPDATE inference_allowance' in s for s,_ in self.sql))
        self.assertEqual(old['state'],'RECONCILED_EXPIRED')
        idle.assert_called_once()

    def test_followup_rejects_unrelated_jobs_and_reservation_drift(self):
        old,prior=self.followup()
        for key,value in (('id','unrelated'),('state','uncertain'),('reserved_compute_usd',Decimal('0'))):
            changed=deepcopy(old);changed[key]=value
            with self.assertRaises(recovery.SetupError):
                recovery.validate_candidate(self.app,self.control,[changed,self.job],self.ledger,
                                            self.attempt,self.expected,prior)
        with self.assertRaises(recovery.SetupError):
            recovery.validate_candidate(self.app,self.control,[old,self.job,self.job],self.ledger,
                                        self.attempt,self.expected,prior)
        self.ledger['compute_reserved_usd']=Decimal('.10625')
        with self.assertRaises(recovery.SetupError):
            recovery.validate_candidate(self.app,self.control,[old,self.job],self.ledger,
                                        self.attempt,self.expected,prior)
