import contextlib
from copy import deepcopy
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch,Mock

spec=importlib.util.spec_from_file_location('disabled',Path(__file__).resolve().parents[1]/'create_runpod_disabled.py')
disabled=importlib.util.module_from_spec(spec);spec.loader.exec_module(disabled)


class FakeAPI:
    def __init__(self,unsafe=False,uncertain=False,bill=0,omit_ports=False):
        self.calls=[];self.endpoint=None;self.registry=None
        self.templates=[]
        self.unsafe=unsafe;self.uncertain=uncertain;self.bill=bill
        self.omit_ports=omit_ports

    def call(self,path,method='GET',body=None,missing_ok=False):
        self.calls.append((path,method,deepcopy(body)))
        if path=='/v2/templates' and method=='GET':return {'templates':deepcopy(self.templates)}
        if path=='/v2/registries':
            if method=='GET':return {'registries':[] if self.registry is None else [self.registry]}
            self.registry={'id':'registry-owned','name':body['name']}
            return self.registry
        if path=='/v2/serverless':
            if method=='GET':return {'endpoints':[] if self.endpoint is None else [self.endpoint]}
            if any(row['name']==body['name'] for row in self.templates):
                raise disabled.ProviderHTTPError('endpoint template names must be unique',400)
            self.templates.append({'id':'template-'+str(len(self.templates)+1),'name':body['name']})
            self.endpoint={**deepcopy(body),'id':'endpoint-owned','networkVolumes':[]}
            if self.omit_ports:self.endpoint.pop('ports')
            if self.unsafe:self.endpoint['workers']['max']=1
            if self.uncertain:raise disabled.SetupError('Provider POST response uncertain')
            return self.endpoint
        if path.startswith('/v2/registries/'):return self.registry
        if path.startswith('/v2/billing?'):
            fields=('podGpuAmount','podCpuAmount','podDiskAmount','serverlessGpuAmount','serverlessCpuAmount',
                    'serverlessDiskAmount','serverlessFeeAmount','storageStandardAmount','storageHighPerformanceAmount',
                    'endpointAmount','clusterGpuAmount','clusterDiskAmount','clusterNetworkingAmount')
            totals={key:0 for key in fields}
            totals.update(totalAmount=self.bill,podGpuAmount=self.bill)
            return {'metadata':{'totals':totals}}
        if path.startswith('/v2/billing/pods?'):
            return {'records':[{'podId':'historical-pod','totalAmount':self.bill,'startTime':'2026-11-01T00:00:00Z'}]}
        if path.startswith('/v2/catalog/gpus'):
            return {'gpus':[{'manufacturer':'NVIDIA','memory':24,'pool':'AMPERE_24','name':'Synthetic GPU',
                            'price':{'serverless':.75},'availability':'HIGH'}]}
        if path.endswith('/workers'):
            return {'workers':[],'summary':{k:0 for k in ('total','running','idle','initializing','throttled','unhealthy')}}
        if path=='/v2/serverless/endpoint-owned':
            if method=='DELETE':self.endpoint=None
            return self.endpoint
        raise AssertionError('Unexpected path/method')


class DisabledSetupTests(unittest.TestCase):
    def test_extra_dollar_policy_is_explicit_and_keeps_highest_account_spend(self):
        state={'budget_authorization':disabled.EXTRA_DOLLAR_AUTHORIZATION,'conservative_prior_spend_usd':'.62'}
        self.assertTrue(disabled.account_for_history(disabled.Decimal('.61'),state))
        self.assertEqual(state['conservative_prior_spend_usd'],'0.62')
        self.assertEqual(state['experiment_planning_ceiling_usd'],'2.99')
        self.assertEqual(state['inference_allowance_usd'],'2.00')
        self.assertFalse(disabled.account_for_history(disabled.Decimal('1.00'),state))
        self.assertEqual(disabled.budget_policy({})[0],disabled.Decimal('1.99'))

    def test_unknown_budget_authorization_cannot_expand_a_limit(self):
        with self.assertRaises(disabled.SetupError):disabled.budget_policy({'budget_authorization':'arbitrary'})

    def image_fixture(self):
        class ImageAPI(FakeAPI):
            def call(self,path,method='GET',body=None,missing_ok=False):
                if path=='/v2/serverless/endpoint-owned' and method=='PATCH':
                    self.calls.append((path,method,deepcopy(body)))
                    self.endpoint.update(body)
                    return deepcopy(self.endpoint)
                return super().call(path,method,body,missing_ok)
        plan=self.plan();api=ImageAPI()
        expected=disabled.payload(plan,'c'*32,'registry-owned','demo-owned')
        api.endpoint={**deepcopy(expected),'id':'endpoint-owned','networkVolumes':[]}
        state={'phase':'disabled_verified','endpoint_id':'endpoint-owned','registry_id':'registry-owned',
               'endpoint_name':'demo-owned','image':plan['image'],'model_revision':plan['model']['revision'],
               'conservative_prior_spend_usd':'.6084335183986695'}
        return api,state,plan,'ghcr.io/aizen-hado/policypilot-gpu@sha256:'+'d'*64

    def invoke_image_update(self,api,state,plan,image,folder,apply=True):
        return disabled.update_image(api,state,plan,'c'*32,image,Path(folder)/'journal.json',
                                     Path(folder)/'plan.json',Path(folder)/'update.json',apply)

    def test_image_update_is_sparse_zero_worker_and_preserves_budget_receipts(self):
        api,state,plan,image=self.image_fixture()
        with tempfile.TemporaryDirectory() as folder:
            report=self.invoke_image_update(api,state,plan,image,folder)
            self.assertEqual(json.loads((Path(folder)/'journal.json').read_text()),state)
            self.assertEqual(json.loads((Path(folder)/'plan.json').read_text()),plan)
        self.assertEqual([call for call in api.calls if call[1]!='GET'],
                         [('/v2/serverless/endpoint-owned','PATCH',{'image':image})])
        patch_index=next(i for i,call in enumerate(api.calls) if call[1]=='PATCH')
        self.assertEqual(api.calls[patch_index+1][:2],('/v2/serverless/endpoint-owned','GET'))
        self.assertTrue(report['provider_verified']);self.assertTrue(report['local_receipts_verified'])
        self.assertFalse(report['reservations_changed'])
        self.assertEqual(state['conservative_prior_spend_usd'],'.6084335183986695')
        self.assertEqual(api.endpoint['workers'],{'min':0,'max':0,'idleTimeout':300})
        self.assertEqual(state['image'],image);self.assertEqual(plan['image'],image)

    def test_image_preview_changes_no_provider_or_local_receipts(self):
        api,state,plan,image=self.image_fixture();old=plan['image']
        with tempfile.TemporaryDirectory() as folder:
            report=self.invoke_image_update(api,state,plan,image,folder,False)
            self.assertFalse((Path(folder)/'journal.json').exists())
        self.assertTrue(all(method=='GET' for _,method,_ in api.calls))
        self.assertFalse(report['provider_verified']);self.assertEqual(plan['image'],old)

    def test_image_update_blocks_active_or_unrelated_drift(self):
        for kind in ('worker_limit','allocated','timeout','identity','image','local_image','model','unchanged'):
            api,state,plan,image=self.image_fixture()
            if kind=='worker_limit':api.endpoint['workers']['max']=1
            elif kind=='allocated':
                original=api.call
                api.call=lambda path,*args,**kwargs: ({'workers':[{'id':'worker-test'}],'summary':{}}
                    if path.endswith('/workers') else original(path,*args,**kwargs))
            elif kind=='timeout':api.endpoint['timeout']=600000
            elif kind=='identity':api.endpoint['id']='another-endpoint'
            elif kind=='image':api.endpoint['image']='private-secret'
            elif kind=='local_image':state['image']='private-secret'
            elif kind=='model':state['model_revision']='f'*40
            elif kind=='unchanged':image=plan['image']
            with tempfile.TemporaryDirectory() as folder,self.assertRaises(disabled.SetupError):
                self.invoke_image_update(api,state,plan,image,folder)
            self.assertTrue(all(method=='GET' for _,method,_ in api.calls),kind)

    def test_image_update_recovers_accepted_patch_without_second_write(self):
        api,state,plan,image=self.image_fixture();original=api.call
        def uncertain(path,method='GET',body=None,**kwargs):
            result=original(path,method,body,**kwargs)
            if method=='PATCH':raise disabled.SetupError('uncertain response')
            return result
        api.call=uncertain
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(disabled.SetupError):
                self.invoke_image_update(api,state,plan,image,folder)
            api.call=original
            # Also covers interruption after one of the two local receipt writes.
            state['image']=image
            report=self.invoke_image_update(api,state,plan,image,folder)
        self.assertEqual(len([call for call in api.calls if call[1]!='GET']),1)
        self.assertTrue(report['provider_verified']);self.assertTrue(report['local_receipts_verified'])

    def test_image_update_requires_fresh_readback_not_patch_response(self):
        api,state,plan,image=self.image_fixture();original=api.call;old=plan['image']
        def ignored(path,method='GET',body=None,**kwargs):
            if method=='PATCH':
                api.calls.append((path,method,deepcopy(body)))
                return {**api.endpoint,'image':image}
            return original(path,method,body,**kwargs)
        api.call=ignored
        with tempfile.TemporaryDirectory() as folder,self.assertRaises(disabled.SetupError):
            self.invoke_image_update(api,state,plan,image,folder)
        self.assertEqual(state['image'],old);self.assertEqual(plan['image'],old)

    def timeout_fixture(self):
        class TimeoutAPI(FakeAPI):
            def call(self,path,method='GET',body=None,missing_ok=False):
                if path=='/v2/serverless/endpoint-owned' and method=='PATCH':
                    self.calls.append((path,method,deepcopy(body)))
                    self.endpoint['timeout']=body['timeout']
                    self.endpoint['workers'].update(body['workers'])
                    return deepcopy(self.endpoint)
                return super().call(path,method,body,missing_ok)
        expected=disabled.payload(self.plan(),'c'*32,'registry-owned','demo-owned')
        api=TimeoutAPI();api.endpoint={**deepcopy(expected),'id':'endpoint-owned','networkVolumes':[]}
        api.endpoint['timeout']=600000;api.endpoint['workers']['idleTimeout']=5
        return api,{'phase':'disabled_verified','endpoint_id':'endpoint-owned'},expected

    def test_timeout_repair_changes_only_named_fields_and_verifies_zero_workers(self):
        api,state,expected=self.timeout_fixture()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'repair.json'
            report=disabled.restore_timeouts(api,state,expected,path,True)
            self.assertEqual(json.loads(path.read_text()),report)
        writes=[call for call in api.calls if call[1]!='GET']
        self.assertEqual(writes,[('/v2/serverless/endpoint-owned','PATCH',{'timeout':180000,'workers':{'idleTimeout':300}})])
        self.assertEqual(report['before'],{'execution_timeout_ms':600000,'idle_timeout_seconds':5})
        self.assertTrue(report['verified'])
        self.assertEqual(api.endpoint['workers'],{'min':0,'max':0,'idleTimeout':300})

    def test_timeout_preview_never_writes_or_claims_repair(self):
        api,state,expected=self.timeout_fixture()
        with tempfile.TemporaryDirectory() as folder:
            report=disabled.restore_timeouts(api,state,expected,Path(folder)/'repair.json')
        self.assertFalse(report['write_attempted']);self.assertFalse(report['verified'])
        self.assertTrue(all(method=='GET' for _,method,_ in api.calls))

    def test_active_workers_or_unrelated_config_drift_blocks_timeout_repair(self):
        for kind in ('active','image','identity'):
            api,state,expected=self.timeout_fixture()
            if kind=='active':api.endpoint['workers']['max']=1
            elif kind=='image':api.endpoint['image']='private-secret'
            else:api.endpoint['id']='another-endpoint'
            with tempfile.TemporaryDirectory() as folder,self.assertRaises(disabled.SetupError):
                disabled.restore_timeouts(api,state,expected,Path(folder)/'repair.json',True)
            self.assertTrue(all(method=='GET' for _,method,_ in api.calls))

    def test_correct_timeouts_are_rechecked_without_a_write(self):
        api,state,expected=self.timeout_fixture()
        api.endpoint['timeout']=180000;api.endpoint['workers']['idleTimeout']=300
        with tempfile.TemporaryDirectory() as folder:
            report=disabled.restore_timeouts(api,state,expected,Path(folder)/'repair.json',True)
        self.assertTrue(report['verified']);self.assertFalse(report['write_attempted'])

    def plan(self):
        return {'model':{'repository':disabled.MODEL,'revision':'a'*40},
                'image':'ghcr.io/aizen-hado/policypilot-gpu@sha256:'+'b'*64,
                'gpu':{'pool':'AMPERE_24','conservative_serverless_usd_per_hour':.75}}

    def invoke(self,api,path):
        with patch.object(disabled,'github',side_effect=[{'login':'AIZEN-Hado'},{'visibility':'private'}]),\
             contextlib.redirect_stdout(io.StringIO()) as output:
            result=disabled.provision(api,self.plan(),'c'*32,path,token_prompt=lambda _: 'synthetic-private-token')
        self.assertNotIn('synthetic-private-token',output.getvalue())
        return result

    def test_create_zero_worker_endpoint_and_read_back_without_job(self):
        api=FakeAPI()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            state=self.invoke(api,path)
            saved=path.read_text()
        self.assertEqual(state['phase'],'disabled_verified')
        self.assertNotIn('synthetic-private-token',saved)
        posts=[call for call in api.calls if call[1]=='POST']
        self.assertEqual([call[0] for call in posts],['/v2/registries','/v2/serverless'])
        self.assertEqual(posts[1][2]['workers'],{'min':0,'max':0,'idleTimeout':300})
        self.assertEqual(posts[1][2]['scaling']['type'],'QUEUE_DELAY')
        self.assertEqual(posts[1][2]['mounts'],{'network':[],'global':[]})
        self.assertFalse(any('/run' in call[0] for call in api.calls))

    def test_observed_omitted_ports_queue_response_keeps_verified_disabled_endpoint(self):
        api=FakeAPI(omit_ports=True)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            state=self.invoke(api,path)
            report=json.loads(path.with_name('runpod-disabled-verification.json').read_text())
        self.assertEqual(state['phase'],'disabled_verified')
        self.assertFalse(report['fields']['ports']['present'])
        self.assertTrue(report['fields']['ports']['matches'])
        self.assertTrue(all(method!='DELETE' for _,method,_ in api.calls))

    def test_exposed_null_or_malformed_ports_remain_rejected(self):
        body=disabled.payload(self.plan(),'c'*32,'registry-owned','test')
        for ports in (['8000/http'],['22/tcp'],None,'',0):
            actual={**deepcopy(body),'networkVolumes':[],'ports':ports}
            with self.assertRaises(disabled.SetupError):disabled.verify_disabled(actual,body)

    def test_canonical_empty_mounts_can_omit_deprecated_alias_without_hiding_storage(self):
        body=disabled.payload(self.plan(),'c'*32,'registry-owned','test')
        disabled.verify_disabled(deepcopy(body),body)
        for update in ({'networkVolumes':['volume-present']},{'mounts':{'network':[{'volumeId':'volume-present'}],'global':[]}},
                       {'mounts':None}):
            with self.assertRaises(disabled.SetupError):disabled.verify_disabled({**deepcopy(body),**update},body)

    def test_verified_resume_never_creates_duplicate_or_requests_token(self):
        api=FakeAPI()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            self.invoke(api,path)
            api.calls.clear()
            with contextlib.redirect_stdout(io.StringIO()):
                disabled.provision(api,self.plan(),'c'*32,path,token_prompt=lambda _:self.fail('Unexpected credential request'))
            self.assertFalse(any(method!='GET' for _,method,_ in api.calls))

    def test_resume_does_not_delete_or_stop_endpoint_enabled_later(self):
        api=FakeAPI()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            self.invoke(api,path)
            api.endpoint['workers']['max']=1
            api.calls.clear()
            with self.assertRaises(disabled.SetupError):self.invoke(api,path)
        self.assertEqual(api.endpoint['workers']['max'],1)
        self.assertTrue(all(method=='GET' for _,method,_ in api.calls))

    def test_unsafe_readback_removes_only_just_created_endpoint_and_confirms_absence(self):
        api=FakeAPI(unsafe=True)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            with self.assertRaises(disabled.SetupError):self.invoke(api,path)
            state=json.loads(path.read_text())
        self.assertEqual(state['phase'],'unsafe_endpoint_removed')
        self.assertIsNone(api.endpoint)
        self.assertEqual([c[0] for c in api.calls if c[1]=='DELETE'],['/v2/serverless/endpoint-owned'])
        self.assertEqual(api.calls[-1][:2],('/v2/serverless/endpoint-owned','GET'))

    def test_failure_keeps_specific_reason_and_safe_diagnostic(self):
        api=FakeAPI(unsafe=True)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            with self.assertRaises(disabled.SetupError) as error:self.invoke(api,path)
            self.assertIn('workers.max',str(error.exception))
            report=json.loads(path.with_name('runpod-disabled-verification.json').read_text())
            self.assertEqual(report['stage'],'verify endpoint configuration')
            self.assertEqual(report['fields']['workers.max']['observed_integer'],1)
            self.assertFalse(report['fields']['workers.max']['matches'])

    def test_removed_endpoint_is_rechecked_and_registry_reused_on_explicit_retry(self):
        api=FakeAPI(unsafe=True)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            with self.assertRaises(disabled.SetupError):self.invoke(api,path)
            old_name=json.loads(path.read_text())['endpoint_name']
            retained=deepcopy(api.templates)
            api.unsafe=False;api.calls.clear()
            state=self.invoke(api,path)
        self.assertEqual(api.calls[0][:2],('/v2/serverless/endpoint-owned','GET'))
        self.assertEqual(state['removed_endpoint_ids'],['endpoint-owned'])
        self.assertFalse(any(p=='/v2/registries' and m=='POST' for p,m,_ in api.calls))
        self.assertEqual(state['phase'],'disabled_verified')
        self.assertNotEqual(state['endpoint_name'],old_name)
        self.assertEqual(api.templates[:len(retained)],retained)
        self.assertEqual(state['endpoint_name_history'][0]['matching_template_ids'],['template-1'])
        self.assertFalse(any(p.startswith('/v2/templates') and m!='GET' for p,m,_ in api.calls))

    def test_recorded_duplicate_rejection_rotates_once_even_if_template_not_listed(self):
        api=FakeAPI()
        original=api.call
        def rejected(path,method='GET',body=None,missing_ok=False):
            if path=='/v2/serverless' and method=='POST':
                raise disabled.ProviderHTTPError('endpoint template names must be unique',400)
            return original(path,method,body,missing_ok)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            with patch.object(api,'call',side_effect=rejected),self.assertRaises(disabled.SetupError):
                self.invoke(api,path)
            old_name=json.loads(path.read_text())['endpoint_name']
            api.calls.clear()
            state=self.invoke(api,path)
            self.assertNotEqual(state['endpoint_name'],old_name)
            self.assertEqual(state['endpoint_name_history'][0]['reason'],'duplicate_template_rejection')
            self.assertNotIn('request_error',state)
            self.assertFalse(any(p=='/v2/registries' and m=='POST' for p,m,_ in api.calls))
            api.calls.clear()
            again=self.invoke(api,path)
            self.assertEqual(again['endpoint_name'],state['endpoint_name'])
            self.assertTrue(all(m=='GET' for _,m,_ in api.calls))

    def test_template_inventory_failure_prevents_all_writes(self):
        api=FakeAPI();original=api.call
        def unavailable(path,method='GET',body=None,missing_ok=False):
            if path=='/v2/templates':raise disabled.SetupError('Template inventory unavailable')
            return original(path,method,body,missing_ok)
        with tempfile.TemporaryDirectory() as folder,patch.object(api,'call',side_effect=unavailable):
            with self.assertRaises(disabled.SetupError):self.invoke(api,Path(folder)/'journal.json')
        self.assertTrue(all(m=='GET' for _,m,_ in api.calls))

    def test_name_collision_never_renames_past_unowned_endpoint(self):
        api=FakeAPI()
        original=api.call
        def rejected(path,method='GET',body=None,missing_ok=False):
            if path=='/v2/serverless' and method=='POST':
                raise disabled.ProviderHTTPError('endpoint template names must be unique',400)
            return original(path,method,body,missing_ok)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            with patch.object(api,'call',side_effect=rejected),self.assertRaises(disabled.SetupError):
                self.invoke(api,path)
            state=json.loads(path.read_text())
            api.endpoint={'id':'unowned-endpoint','name':state['endpoint_name']}
            api.calls.clear()
            with self.assertRaises(disabled.SetupError):self.invoke(api,path)
            self.assertEqual(json.loads(path.read_text())['endpoint_name'],state['endpoint_name'])
        self.assertTrue(all(m=='GET' for _,m,_ in api.calls))

    def test_uncertain_create_is_journaled_and_not_blindly_repeated(self):
        api=FakeAPI(uncertain=True)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            with self.assertRaises(disabled.SetupError):self.invoke(api,path)
            self.assertEqual(json.loads(path.read_text())['phase'],'endpoint_create_pending')
            api.calls.clear()
            with self.assertRaises(disabled.SetupError):self.invoke(api,path)
            self.assertEqual(api.calls,[])

    def test_definite_endpoint_rejection_can_be_fixed_without_duplicate_registry(self):
        api=FakeAPI()
        original=api.call
        def rejected(path,method='GET',body=None,missing_ok=False):
            if path=='/v2/serverless' and method=='POST':
                raise disabled.ProviderHTTPError('HTTP 422; body withheld',422)
            return original(path,method,body,missing_ok)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            with patch.object(api,'call',side_effect=rejected),self.assertRaises(disabled.SetupError):
                self.invoke(api,path)
            self.assertEqual(json.loads(path.read_text())['phase'],'registry_verified')
            api.calls.clear()
            self.invoke(api,path)
            self.assertFalse(any(p=='/v2/registries' and m=='POST' for p,m,_ in api.calls))

    def test_history_that_cannot_cover_inference_reserve_blocks_all_writes(self):
        api=FakeAPI(bill=1.01)
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(disabled.SetupError):self.invoke(api,Path(folder)/'journal.json')
        self.assertTrue(all(method=='GET' for _,method,_ in api.calls))

    def test_prior_spend_is_counted_without_increasing_total_or_inference_allowance(self):
        api=FakeAPI(bill=.5064673366287025)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'journal.json'
            state=self.invoke(api,path)
            audit=json.loads(path.with_name('runpod-billing-audit.json').read_text())
        self.assertEqual(state['conservative_prior_spend_usd'],'0.5064673366287025')
        self.assertEqual(state['remaining_total_allowance_usd'],'1.4835326633712975')
        self.assertEqual(state['remaining_training_and_other_allowance_usd'],'0.4835326633712975')
        self.assertEqual(state['experiment_planning_ceiling_usd'],'1.99')
        self.assertEqual(state['inference_allowance_usd'],'1.00')
        self.assertEqual(audit['resources'][0]['resource_id'],'historical-pod')
        self.assertFalse(audit['resources_changed'])

    def test_rolling_window_never_resets_counted_prior_spend(self):
        state={'conservative_prior_spend_usd':'0.50'}
        self.assertTrue(disabled.account_for_history(disabled.Decimal('0'),state))
        self.assertEqual(state['conservative_prior_spend_usd'],'0.50')
        self.assertEqual(state['remaining_training_and_other_allowance_usd'],'0.49')
        self.assertFalse(disabled.account_for_history(disabled.Decimal('1'),state))
        self.assertEqual(state['conservative_prior_spend_usd'],'1')

    def test_incomplete_billing_is_not_treated_as_zero(self):
        api=FakeAPI()
        with self.assertRaises(disabled.SetupError):
            disabled.audit_billing(api,{'metadata':{'totals':{'totalAmount':0}}})

    def test_readback_never_treats_missing_or_boolean_workers_as_zero(self):
        body=disabled.payload(self.plan(),'c'*32,'registry-owned','test')
        actual={**deepcopy(body),'networkVolumes':[]}
        disabled.verify_disabled(actual,body)
        for values in ({},{'min':False,'max':False,'idleTimeout':300},{'min':0,'max':1,'idleTimeout':300}):
            with self.assertRaises(disabled.SetupError):disabled.verify_disabled({**actual,'workers':values},body)
        with self.assertRaises(disabled.SetupError):disabled.verify_no_workers({'workers':[]})
        with self.assertRaises(disabled.SetupError):disabled.verify_no_workers({'workers':[],'summary':None})
        with self.assertRaises(disabled.SetupError):disabled.verify_disabled({**actual,'workers':None},body)

    def test_documented_missing_empty_exclusions_are_equivalent_to_full_pool(self):
        body=disabled.payload(self.plan(),'c'*32,'registry-owned','test')
        actual={**deepcopy(body),'networkVolumes':[]}
        del actual['gpu']['excludedTypes']
        disabled.verify_disabled(actual,body)
        actual['gpu']['pools']=['ADA_24']
        with self.assertRaises(disabled.SetupError):disabled.verify_disabled(actual,body)

    def test_documented_command_encoding_is_checked_without_executing_it(self):
        body=disabled.payload(self.plan(),'c'*32,'registry-owned','test')
        for encoded in ('python -m pilot.gpu_handler',json.dumps({'cmd':body['cmd'],'entrypoint':[]})):
            actual={**deepcopy(body),'networkVolumes':[],'args':encoded}
            del actual['cmd']
            disabled.verify_disabled(actual,body)
        for encoded in ('python -m other_handler',json.dumps({'cmd':body['cmd'],'entrypoint':['sh','-c']})):
            actual={**deepcopy(body),'networkVolumes':[],'args':encoded}
            del actual['cmd']
            with self.assertRaises(disabled.SetupError):disabled.verify_disabled(actual,body)

    def test_diagnostic_never_saves_arbitrary_provider_environment_or_values(self):
        body=disabled.payload(self.plan(),'c'*32,'registry-owned','test')
        actual={**deepcopy(body),'networkVolumes':[],'image':'private-provider-secret'}
        actual['env']['UNKNOWN_SECRET']='private-provider-secret'
        report=json.dumps(disabled.verification_report(actual,body))
        self.assertNotIn('private-provider-secret',report)
        self.assertNotIn('UNKNOWN_SECRET',report)
        self.assertIn('"matches": false',report)

    def test_http_error_shows_validation_reason_but_redacts_all_supplied_secrets(self):
        api=disabled.API('private-runpod-key')
        body={'password':'private-ghcr-token','username':'private-registry-user','env':{'HF_TOKEN':'private-hf-token'}}
        raw=json.dumps({'title':'Bad Request','detail':'workers.max must be zero or positive',
                        'errors':['private-runpod-key private-ghcr-token private-registry-user private-hf-token',
                                  'Bearer unknown-token https://example.invalid/?secret=value'],
                        'debug':'arbitrary-private-debug'}).encode()
        error=disabled.urllib.error.HTTPError(disabled.BASE+'/v2/serverless',400,'Bad Request',{},io.BytesIO(raw))
        api.opener=Mock();api.opener.open.side_effect=error
        with self.assertRaises(disabled.ProviderHTTPError) as caught:api.call('/v2/serverless','POST',body)
        message=str(caught.exception)
        self.assertEqual(caught.exception.status,400)
        self.assertIn('workers.max must be zero or positive',message)
        for value in ('private-runpod-key','private-ghcr-token','private-registry-user','private-hf-token',
                      'unknown-token','https://example.invalid','arbitrary-private-debug'):
            self.assertNotIn(value,message)

    def test_unknown_or_oversized_error_body_is_not_printed(self):
        for raw in (b'<html>private-debug</html>',b'x'*20000,b'{"debug":"private-debug"}'):
            self.assertNotIn('private-debug',disabled.validation_detail(raw,[]))

    def test_no_provider_key_or_cloud_credentials_in_worker_payload(self):
        body=disabled.payload(self.plan(),'c'*32,'registry-owned','test')
        self.assertEqual(set(body['env']),{'MODEL_REPOSITORY','MODEL_REVISION','DOCUMENT_DOWNLOAD_HOST','HF_HOME','RUNPOD_INIT_TIMEOUT'})
        self.assertEqual(body['timeout'],180000)
        self.assertEqual(body['gpu']['minCudaVersion'],'12.8')
