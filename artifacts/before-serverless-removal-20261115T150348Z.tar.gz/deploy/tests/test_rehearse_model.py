from copy import deepcopy
from decimal import Decimal
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
import urllib.error
import ssl
from unittest.mock import Mock,patch
from contextlib import redirect_stdout

spec = importlib.util.spec_from_file_location('rehearsal', Path(__file__).resolve().parents[1]/'rehearse_model.py')
rehearsal = importlib.util.module_from_spec(spec); spec.loader.exec_module(rehearsal)


class Timer:
    def __init__(self, seconds, callback): self.seconds=seconds; self.callback=callback
    def start(self): pass
    def cancel(self): pass
    def is_alive(self): return False


class RehearsalTests(unittest.TestCase):
    def test_expanded_allowance_accepts_generation_above_old_cap_and_still_stops(self):
        self.state['budget_authorization']=rehearsal.EXTRA_DOLLAR_AUTHORIZATION
        original=self.call
        def call(path,method='GET',body=None):
            result=original(path,method,body)
            if path=='/api/model/status' and result.get('state')=='ready':result['demo_compute_reserved_usd']=.797085
            return result
        api=Mock();api.call.side_effect=call
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            report=rehearsal.rehearse(api,api,self.state,self.expected,Path(folder)/'attempt.json',
                self.billing,Decimal('.75'),self.clock,self.sleep,Timer,prior_reserved=Decimal('.678335'))
        self.assertTrue(report['generation_verified']);self.assertEqual(report['compute_reserved_usd'],'0.797085')
        self.assertTrue(report['provider_shutdown_verified']);self.assertTrue(report['app_shutdown_verified'])
        self.assertEqual(report['result'],'PASS')
        self.assertEqual(len([call for call in self.calls if call[0]=='/api/model/start']),1)

    def test_compiler_ready_matches_failure_and_reviewed_image_before_any_paid_work(self):
        import settle_closed_warmups as policy
        proposal={'reserved_after_usd':'.559585'}
        prior={'endpoint_id':'endpoint-test','result':'PASS','database_committed':True,'proposal':proposal,
               'audit_action':policy.audit_action(proposal),'observed_reserved_usd':'.559585'}
        attempt={'endpoint_id':'endpoint-test','start_attempted':True,'model_revision':'a'*40,
            'generation_verified':False,'provider_shutdown_verified':True,'app_shutdown_verified':True,
            'prior_compute_reserved_usd':'.559585','shutdown_app_status':{'demo_compute_reserved_usd':'.678335'},
            'worker_image':'old-image','worker_failure_diagnostics':[{'stage':'check_quantizer','exception_type':'RuntimeError',
                'model_loader_reason':'Failed to find C compiler. Please specify via CC environment variable.'}]}
        image={'endpoint_id':'endpoint-test','provider_verified':True,'local_receipts_verified':True,
               'desired_image':rehearsal.COMPILER_FIXED_IMAGE,'before_image':'old-image'}
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'artifacts').mkdir()
            for name,value in [('runpod-paused-hold-settlement.json',prior),('runpod-warmup-loader-diagnostic.json',attempt),
                               ('runpod-image-update.json',image)]:
                (root/'artifacts'/name).write_text(json.dumps(value))
            expected={**self.expected,'image':rehearsal.COMPILER_FIXED_IMAGE}
            with patch.object(policy,'paused_bounds',return_value=proposal):
                self.assertEqual(rehearsal.compiler_ready(root,self.state,expected)[0],Decimal('.678335'))
                with self.assertRaises(rehearsal.SetupError):rehearsal.compiler_ready(root,self.state,self.expected)
                attempt['worker_failure_diagnostics']=[]
                (root/'artifacts/runpod-warmup-loader-diagnostic.json').write_text(json.dumps(attempt))
                with self.assertRaises(rehearsal.SetupError):rehearsal.compiler_ready(root,self.state,expected)

    def test_expanded_allowance_preflight_retains_all_prior_reservations(self):
        self.state['budget_authorization']=rehearsal.EXTRA_DOLLAR_AUTHORIZATION
        self.app.update(compute_allowance_usd=1.7,demo_inference_allowance_usd=2,demo_compute_reserved_usd=.678335)
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            rehearsal.preflight(self,self,self.state,self.expected,Path(folder)/'journal.json',Decimal('.678335'))
        self.assertEqual(self.state['experiment_planning_ceiling_usd'],'2.99')
        self.assertEqual(self.state['inference_allowance_usd'],'2.00')
        self.assertTrue(all(method=='GET' for _,method,_ in self.calls))

    def test_compiler_fix_cli_preview_submits_nothing(self):
        with patch('sys.argv',['rehearse_model.py','https://policypilot-demo.onrender.com','--compiler-fix']),\
             redirect_stdout(io.StringIO()) as output:
            rehearsal.main()
        self.assertIn('Preview:',output.getvalue())

    def test_compiler_mode_requires_explicit_committed_extension_receipt(self):
        reserved=Decimal('.678335')
        receipt={'authorization':rehearsal.EXTRA_DOLLAR_AUTHORIZATION,'endpoint_id':'endpoint-test',
                 'result':'PASS','database_committed':True,'reserved_compute_usd':str(reserved),
                 'compiler_image':rehearsal.COMPILER_FIXED_IMAGE}
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'artifacts').mkdir()
            path=root/'artifacts/runpod-extra-dollar-authorization.json';path.write_text(json.dumps(receipt))
            with patch.object(rehearsal,'compiler_ready',return_value=(reserved,'prior-action')):
                with self.assertRaises(rehearsal.SetupError):rehearsal.compiler_reservation(root,self.state,self.expected)
                self.state['budget_authorization']=rehearsal.EXTRA_DOLLAR_AUTHORIZATION
                self.assertEqual(rehearsal.compiler_reservation(root,self.state,self.expected),reserved)
                receipt['database_committed']=False;path.write_text(json.dumps(receipt))
                with self.assertRaises(rehearsal.SetupError):rehearsal.compiler_reservation(root,self.state,self.expected)

    def test_collected_loader_failure_is_saved_and_printed_with_secrets_removed(self):
        self.mode='error'
        diagnostic={'event':'failure','stage':'load_model','category':'processing_failure',
                    'exception_type':'RuntimeError','model_loader_reason':'CUDA error https://private.invalid?token=secret-value',
                    'arbitrary':'private-secret'}
        with tempfile.TemporaryDirectory() as folder:
            observer=Mock();observer.capture.return_value=['worker-test'];observer.destination=Path(folder)/'workers.json'
            observer.report={'log_sources':[{'events':[{'worker_diagnostic':diagnostic}]}]}
            with redirect_stdout(io.StringIO()) as output:
                result=rehearsal.rehearse(self,self,self.state,self.expected,Path(folder)/'attempt.json',
                    self.billing,Decimal('.75'),self.clock,self.sleep,Timer,observer=observer)
            self.assertTrue(result['provider_shutdown_verified']);self.assertTrue(result['app_shutdown_verified'])
            self.assertIn('Worker diagnostic:',output.getvalue())
            self.assertEqual(result['worker_image'],self.expected['image'])
            for secret in ('private.invalid','secret-value','private-secret'):
                self.assertNotIn(secret,json.dumps(result)+output.getvalue())
            self.assertEqual(len([call for call in self.calls if call[0]=='/api/model/start']),1)

    def test_loader_mode_requires_reviewed_digest_and_committed_paused_settlement(self):
        import settle_closed_warmups as policy
        proposal={'reserved_after_usd':'.559585','source_sha256':{'receipt':'a'*64}}
        receipt={'endpoint_id':'endpoint-test','result':'PASS','database_committed':True,
                 'proposal':proposal,'observed_reserved_usd':'.559585'}
        reviewed='ghcr.io/aizen-hado/policypilot-gpu@sha256:5c4c20537587ab0317ac7515b7fcf94f9d5e1cd0abfa983c52783ed10f7e733e'
        image={'endpoint_id':'endpoint-test','provider_verified':True,'local_receipts_verified':True,
               'desired_image':reviewed,'before_image':'old-image'}
        expected={**self.expected,'image':reviewed}
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'artifacts').mkdir()
            destination=root/'artifacts/runpod-paused-hold-settlement.json';destination.write_text(json.dumps(receipt))
            (root/'artifacts/runpod-image-update.json').write_text(json.dumps(image))
            with patch.object(policy,'paused_bounds',return_value=proposal):
                self.assertEqual(rehearsal.loader_reservation(root,self.state,expected),Decimal('.559585'))
                with self.assertRaises(rehearsal.SetupError):rehearsal.loader_reservation(root,self.state,self.expected)
                receipt['database_committed']=False;destination.write_text(json.dumps(receipt))
                with self.assertRaises(rehearsal.SetupError):rehearsal.loader_reservation(root,self.state,expected)

    def test_loader_flag_preview_has_no_provider_or_app_requests(self):
        with patch('sys.argv',['rehearse_model.py','https://policypilot-demo.onrender.com','--loader-diagnostic']),\
             redirect_stdout(io.StringIO()) as output:
            rehearsal.main()
        self.assertIn('Preview:',output.getvalue())

    def test_diagnostic_mode_requires_committed_matching_settlement_and_new_image(self):
        import settle_closed_warmups as policy
        proposal={'reserved_after_usd':'0.529376','source_sha256':{'receipt':'a'*64}}
        receipt={'endpoint_id':'endpoint-test','result':'PASS','database_committed':True,
                 'proposal':proposal,'observed_reserved_usd':'0.529376'}
        image={'endpoint_id':'endpoint-test','provider_verified':True,'local_receipts_verified':True,
               'desired_image':self.expected['image'],'before_image':'old-image'}
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'artifacts').mkdir()
            (root/'artifacts/runpod-image-update.json').write_text(json.dumps(image))
            destination=root/'artifacts/runpod-closed-warmup-settlement.json'
            destination.write_text(json.dumps(receipt))
            with patch.object(policy,'bounds',return_value=proposal):
                self.assertEqual(rehearsal.diagnostic_reservation(root,self.state,self.expected),Decimal('.529376'))
                for key,value in [('database_committed',False),('observed_reserved_usd','.70'),('proposal',{})]:
                    changed={**receipt,key:value};destination.write_text(json.dumps(changed))
                    with self.assertRaises(rehearsal.SetupError):
                        rehearsal.diagnostic_reservation(root,self.state,self.expected)
                destination.write_text(json.dumps(receipt));image['desired_image']='unrelated-image'
                (root/'artifacts/runpod-image-update.json').write_text(json.dumps(image))
                with self.assertRaises(rehearsal.SetupError):
                    rehearsal.diagnostic_reservation(root,self.state,self.expected)

    def test_diagnostic_flag_is_parsed_before_preview_without_submitting_work(self):
        with patch('sys.argv',['rehearse_model.py','https://policypilot-demo.onrender.com','--diagnostic-worker']),\
             redirect_stdout(io.StringIO()) as output:
            rehearsal.main()
        self.assertIn('Preview:',output.getvalue())

    def setUp(self):
        self.calls=[]; self.seconds=0; self.stopped=False
        self.mode='ready'; self.stop_fails=False; self.billing=Decimal('0.5064673366287025')
        self.expected=rehearsal.payload(
            {'model':{'repository':'Qwen/Qwen2.5-7B-Instruct','revision':'a'*40},
             'image':'ghcr.io/aizen-hado/policypilot-gpu@sha256:'+'b'*64,'gpu':{'pool':'AMPERE_24'}},
            'c'*32,'registry-test','endpoint-test')
        self.actual=deepcopy(self.expected)
        self.state={'endpoint_id':'endpoint-test','conservative_serverless_usd_per_hour':'0.75'}
        self.app={'configured':True,'operator':True,'enabled':False,'state':'off','can_start':True,
                  'model':'Qwen/Qwen2.5-7B-Instruct','demo_inference_allowance_usd':1,
                  'compute_allowance_usd':.70,'demo_compute_reserved_usd':0}
        self.rate=.75

    def clock(self): return self.seconds
    def sleep(self, seconds): self.seconds+=seconds

    def call(self, path, method='GET', body=None):
        self.calls.append((path,method,body))
        if path==rehearsal.BILLING:
            return {'metadata':{'totals':{'totalAmount':str(self.billing)}}}
        if path.startswith('/v2/catalog/'):
            return {'gpus':[{'manufacturer':'NVIDIA','memory':24,'pool':'AMPERE_24',
                            'price':{'serverless':self.rate},'availability':'HIGH','name':'synthetic'}]}
        if path.endswith('/workers'):
            return {'workers':[], 'summary':{k:0 for k in ('running','idle','initializing','throttled','unhealthy','total')}}
        if path.startswith('/v2/serverless/'):
            if method=='PATCH':
                self.assertEqual(body,{'workers':{'min':0,'max':0,'idleTimeout':300}})
            return self.actual
        if path=='/api/model/start':
            if self.mode=='lost_start': raise rehearsal.SetupError('synthetic-secret')
            if self.mode=='rejected_start':
                raise rehearsal.AppRequestError(409,'Runpod submit: HTTP 403; reconcile before retrying paid work')
            return {'state':'loading'}
        if path=='/api/model/stop':
            if self.stop_fails: raise rehearsal.SetupError('synthetic-secret')
            self.stopped=True; return {'state':'stopping'}
        if path=='/api/model/status':
            if not any(c[0]=='/api/model/start' for c in self.calls): return self.app
            if self.stopped: return {'state':'off','enabled':False}
            return {'state':self.mode,'enabled':True,'artifact_revision':'a'*40,
                    'demo_compute_reserved_usd':.10625}
        self.fail('Unexpected request: '+path)

    def run_test(self,path):
        with redirect_stdout(io.StringIO()):
            return rehearsal.rehearse(self,self,self.state,self.expected,path,self.billing,Decimal('.75'),
                                      self.clock,self.sleep,Timer)

    def test_one_start_saved_generation_then_both_shutdown_checks(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'report.json'; result=self.run_test(path)
            self.assertEqual(json.loads(path.read_text()),result)
        self.assertEqual(result['result'],'PASS')
        self.assertTrue(result['generation_verified'])
        self.assertTrue(result['provider_shutdown_verified'])
        self.assertTrue(result['app_shutdown_verified'])
        self.assertEqual(sum(c[0]=='/api/model/start' for c in self.calls),1)
        self.assertIsNone(result['rss_bytes'])

    def test_lost_start_response_never_retried_and_still_stops(self):
        self.mode='lost_start'
        with tempfile.TemporaryDirectory() as folder:
            result=self.run_test(Path(folder)/'report.json')
        self.assertEqual(result['result'],'CHECK')
        self.assertTrue(result['provider_shutdown_verified'])
        self.assertEqual(sum(c[0]=='/api/model/start' for c in self.calls),1)
        self.assertNotIn('synthetic-secret',json.dumps(result))

    def test_deadline_stops_loading_worker(self):
        self.mode='loading'
        with tempfile.TemporaryDirectory() as folder:
            result=self.run_test(Path(folder)/'report.json')
        self.assertEqual(result['result'],'CHECK')
        self.assertGreaterEqual(self.seconds,rehearsal.DEADLINE)
        self.assertTrue(result['provider_shutdown_verified'])

    def test_start_http_failure_keeps_stage_and_code_without_response_body(self):
        self.mode='rejected_start'
        with tempfile.TemporaryDirectory() as folder:
            result=self.run_test(Path(folder)/'report.json')
        self.assertEqual(result['failure_stage'],'start_request')
        self.assertEqual(result['app_http_status'],409)
        self.assertEqual(result['provider_diagnostic'],'Runpod submit: HTTP 403; reconcile before retrying paid work')
        self.assertEqual(result['shutdown_app_status'],{'state':'off','enabled':False})
        self.assertEqual(sum(c[0]=='/api/model/start' for c in self.calls),1)

    def test_saved_app_state_excludes_raw_strings_keys_and_bad_numbers(self):
        data={'state':'error','enabled':False,'demo_compute_reserved_usd':.10625,
              'detail':'synthetic-secret','key':'synthetic-secret','compute_allowance_usd':float('nan')}
        result=rehearsal.safe_app_state(data)
        self.assertEqual(result,{'state':'error','enabled':False,'demo_compute_reserved_usd':'0.10625'})

    def test_only_fixed_provider_diagnostics_are_accepted(self):
        message='Runpod submit: HTTP 403; reconcile before retrying paid work'
        self.assertEqual(rehearsal.safe_diagnostic(message),message)
        known=message.replace('HTTP 403','HTTP 409 (ENDPOINT_PAUSED)')
        self.assertEqual(rehearsal.safe_diagnostic(known),known)
        activation='Invoke API did not observe worker activation within 60 seconds; no job submitted'
        self.assertEqual(rehearsal.safe_diagnostic(activation),activation)
        self.assertIsNone(rehearsal.safe_diagnostic(activation+' private-secret'))
        for value in ('private-secret',message+' private-secret',{'detail':message},None):
            self.assertIsNone(rehearsal.safe_diagnostic(value))

    def test_startup_fix_requires_second_committed_recovery_without_refund(self):
        from unittest.mock import patch
        followup={'endpoint_id':'endpoint-test','model_revision':'a'*40,'start_attempted':True,
                  'generation_verified':False,'provider_shutdown_verified':True,'prior_compute_reserved_usd':'.10625'}
        recovery={'endpoint_id':'endpoint-test','database_committed':True,'result':'PASS',
                  'provider_disabled_and_idle_verified':True,'new_jobs_submitted':0,'refund_usd':'0',
                  'reserved_compute_usd':'.2125','app_after':{'state':'off','can_start':False}}
        with tempfile.TemporaryDirectory() as folder,patch.object(rehearsal,'reconciled_reservation',return_value=Decimal('.10625')):
            root=Path(folder);(root/'artifacts').mkdir()
            (root/'artifacts/runpod-warmup-followup.json').write_text(json.dumps(followup))
            path=root/'artifacts/runpod-warmup-followup-reconciliation.json'
            path.write_text(json.dumps(recovery))
            self.assertEqual(rehearsal.startup_fix_reservation(root,self.state,self.expected),Decimal('.2125'))
            for key,value in (('database_committed',False),('reserved_compute_usd','0'),('refund_usd','.10625')):
                changed=deepcopy(recovery);changed[key]=value;path.write_text(json.dumps(changed))
                with self.assertRaises(rehearsal.SetupError):
                    rehearsal.startup_fix_reservation(root,self.state,self.expected)

    def test_http_error_body_is_filtered_and_closed(self):
        web=rehearsal.Web('https://example.com');web.opener=Mock()
        message='Runpod submit: timeout; reconcile before retrying paid work'
        for detail in (message,'private-secret'):
            body=io.BytesIO(json.dumps({'detail':detail,'secret':'private-secret'}).encode())
            web.opener.open.side_effect=urllib.error.HTTPError('private-url',409,'private-secret',{},body)
            with self.assertRaises(rehearsal.AppRequestError) as caught:
                web.call('/api/model/start','POST')
            self.assertEqual(caught.exception.diagnostic,message if detail==message else None)
            self.assertNotIn('private-secret',str(caught.exception))
            self.assertTrue(body.closed)
            self.assertEqual(web.opener.open.call_args.kwargs['timeout'],360)

    def test_health_wake_wait_and_secret_free_error_categories(self):
        web=rehearsal.Web('https://example.com');web.opener=Mock()
        for error,category in ((TimeoutError('private-secret'),'timeout'),
                              (urllib.error.URLError(TimeoutError('private-secret')),'timeout'),
                              (urllib.error.URLError(ssl.SSLError('private-secret')),'TLS failure'),
                              (urllib.error.URLError('private-secret'),'network failure')):
            web.opener.open.reset_mock();web.opener.open.side_effect=error
            with self.assertRaises(rehearsal.AppRequestError) as caught:web.login('reviewer','private-password')
            self.assertEqual(caught.exception.operation,'health check')
            self.assertEqual(caught.exception.category,category)
            self.assertNotIn('private-secret',str(caught.exception))
            self.assertNotIn('private-password',str(caught.exception))
            web.opener.open.assert_called_once()
            self.assertEqual(web.opener.open.call_args.kwargs['timeout'],90)
            self.assertEqual(web.opener.open.call_args.args[0].method,'GET')

    def test_login_failure_is_distinct_and_never_retried(self):
        web=rehearsal.Web('https://example.com');web.opener=Mock()
        response=io.BytesIO(b'{"status":"ok"}');response.code=200
        web.opener.open.side_effect=[response,TimeoutError('private-secret')]
        with self.assertRaises(rehearsal.AppRequestError) as caught:web.login('reviewer','private-password')
        self.assertEqual(caught.exception.operation,'login')
        self.assertEqual(caught.exception.category,'timeout')
        self.assertEqual(web.opener.open.call_count,2)
        self.assertNotIn('private-password',str(caught.exception))

    def test_followup_preflight_requires_exact_preserved_reservation(self):
        self.app['demo_compute_reserved_usd']=.10625
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            rehearsal.preflight(self,self,self.state,self.expected,Path(folder)/'journal.json',Decimal('.10625'))
            self.app['demo_compute_reserved_usd']=0
            with self.assertRaises(rehearsal.SetupError):
                rehearsal.preflight(self,self,self.state,self.expected,Path(folder)/'journal.json',Decimal('.10625'))
        self.assertTrue(all(c[1]=='GET' for c in self.calls))

    def test_activation_release_gate_blocks_old_deployment_before_start(self):
        self.app['demo_compute_reserved_usd']=.4625
        self.actual['id']='endpoint-test'
        self.actual['requestUrls']={key:'https://api.runpod.ai/v2/endpoint-test/'+suffix for key,suffix in
            {'run':'run','health':'health','status':'status/{job_id}','cancel':'cancel/{job_id}'}.items()}
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            path=Path(folder)/'journal.json'
            with self.assertRaises(rehearsal.SetupError):
                rehearsal.preflight(self,self,self.state,self.expected,path,Decimal('.4625'),'invoke-worker-v1')
            self.app['startup_protocol']='invoke-worker-v1'
            rehearsal.preflight(self,self,self.state,self.expected,path,Decimal('.4625'),'invoke-worker-v1')
        self.assertTrue(all(c[1]=='GET' for c in self.calls))

    def test_manual_worker_receipts_and_full_reservation_chain_required(self):
        from unittest.mock import patch
        attempt={'endpoint_id':'endpoint-test','model_revision':'a'*40,'prior_compute_reserved_usd':'.2125',
                 'generation_verified':False,'provider_shutdown_verified':True,'app_shutdown_verified':True,
                 'shutdown_app_status':{'demo_compute_reserved_usd':.31875}}
        manual={'endpoint_id':'endpoint-test','start_attempted':True,'reservation_committed':True,
                'provider_shutdown_recheck_verified':True,'app_off_verified':True,'requests_submitted':0,
                'prior_compute_reserved_usd':'.31875','reserved_compute_usd':'.14375','total_compute_reserved_usd':'.4625'}
        with tempfile.TemporaryDirectory() as folder,patch.object(rehearsal,'startup_fix_reservation',return_value=Decimal('.2125')):
            root=Path(folder);(root/'artifacts').mkdir()
            (root/'artifacts/runpod-warmup-startup-fix.json').write_text(json.dumps(attempt))
            path=root/'artifacts/runpod-existing-worker-start.json';path.write_text(json.dumps(manual))
            self.assertEqual(rehearsal.worker_start_reservation(root,self.state,self.expected),Decimal('.4625'))
            manual['total_compute_reserved_usd']='0';path.write_text(json.dumps(manual))
            with self.assertRaises(rehearsal.SetupError):rehearsal.worker_start_reservation(root,self.state,self.expected)

    def test_explicit_long_retry_preserves_failed_activation_and_full_ledger(self):
        from unittest.mock import patch
        attempt={'endpoint_id':'endpoint-test','model_revision':'a'*40,'prior_compute_reserved_usd':'.4625',
                 'start_attempted':True,'generation_verified':False,'provider_shutdown_verified':True,
                 'app_shutdown_verified':True,
                 'provider_diagnostic':'Invoke API did not observe worker activation within 60 seconds; no job submitted',
                 'shutdown_app_status':{'demo_compute_reserved_usd':.58125}}
        with tempfile.TemporaryDirectory() as folder,patch.object(rehearsal,'worker_start_reservation',return_value=Decimal('.4625')):
            root=Path(folder);(root/'artifacts').mkdir();path=root/'artifacts/runpod-warmup-activation.json'
            path.write_text(json.dumps(attempt))
            self.assertEqual(rehearsal.long_startup_reservation(root,self.state,self.expected),Decimal('.58125'))
            self.assertEqual(json.loads(path.read_text()),attempt)
            attempt['provider_shutdown_verified']=False;path.write_text(json.dumps(attempt))
            with self.assertRaises(rehearsal.SetupError):rehearsal.long_startup_reservation(root,self.state,self.expected)

    def test_observation_is_captured_before_paid_worker_shutdown(self):
        watch=Mock();watch.destination=Path('observations.json')
        def capture():
            self.assertTrue(any(c[0]=='/api/model/start' for c in self.calls))
            self.assertFalse(any(c[0]=='/api/model/stop' for c in self.calls))
            return ['worker-one']
        watch.capture.side_effect=capture
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            result=rehearsal.rehearse(self,self,self.state,self.expected,Path(folder)/'run.json',
                self.billing,Decimal('.75'),self.clock,self.sleep,Timer,observer=watch)
        self.assertEqual(result['observed_worker_ids'],['worker-one'])
        self.assertEqual(result['worker_observation_file'],'observations.json')
        self.assertTrue(result['provider_shutdown_verified'])

    def test_followup_cannot_pass_without_a_new_reservation(self):
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            result=rehearsal.rehearse(self,self,self.state,self.expected,Path(folder)/'report.json',
                       self.billing,Decimal('.75'),self.clock,self.sleep,Timer,prior_reserved=Decimal('.10625'))
        self.assertFalse(result['generation_verified'])
        self.assertTrue(result['provider_shutdown_verified'])

    def test_followup_accepts_new_reservation_and_cannot_repeat(self):
        original=self.call
        def call(path,method='GET',body=None):
            result=original(path,method,body)
            if path=='/api/model/status' and result.get('state')=='ready':
                result['demo_compute_reserved_usd']=.2125
            return result
        self.call=call
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            path=Path(folder)/'followup.json'
            result=rehearsal.rehearse(self,self,self.state,self.expected,path,
                       self.billing,Decimal('.75'),self.clock,self.sleep,Timer,prior_reserved=Decimal('.10625'))
            self.assertEqual(result['result'],'PASS')
            self.assertEqual(result['prior_compute_reserved_usd'],'0.10625')
            self.assertEqual(result['compute_reserved_usd'],'0.2125')
            self.calls.clear()
            with self.assertRaises(rehearsal.SetupError):
                rehearsal.rehearse(self,self,self.state,self.expected,path,
                       self.billing,Decimal('.75'),self.clock,self.sleep,Timer,prior_reserved=Decimal('.10625'))
            self.assertEqual(self.calls,[])

    def test_followup_requires_matching_committed_recovery(self):
        previous={'endpoint_id':'endpoint-test','start_attempted':True,'generation_verified':False,
                  'provider_shutdown_verified':True,'model_revision':'a'*40}
        recovery={'endpoint_id':'endpoint-test','result':'PASS','database_committed':True,
                  'provider_disabled_and_idle_verified':True,'past_submitted_ttl_and_margin':True,
                  'new_jobs_submitted':0,'refund_usd':'0','reserved_compute_usd':'.106250',
                  'app_after':{'state':'off','enabled':False,'can_start':False,'demo_compute_reserved_usd':'.10625'}}
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'artifacts').mkdir()
            (root/'artifacts/runpod-warmup-rehearsal.json').write_text(json.dumps(previous))
            path=root/'artifacts/runpod-warmup-reconciliation.json'
            path.write_text(json.dumps(recovery))
            self.assertEqual(rehearsal.reconciled_reservation(root,self.state,self.expected),Decimal('.10625'))
            for key,value in (('endpoint_id','wrong'),('database_committed',False),('refund_usd','.10625'),
                              ('reserved_compute_usd','0'),('past_submitted_ttl_and_margin',False)):
                changed=deepcopy(recovery);changed[key]=value;path.write_text(json.dumps(changed))
                with self.assertRaises(rehearsal.SetupError):
                    rehearsal.reconciled_reservation(root,self.state,self.expected)
            self.assertEqual(json.loads((root/'artifacts/runpod-warmup-rehearsal.json').read_text()),previous)

    def test_failed_app_stop_still_disables_provider_and_reports_app_unconfirmed(self):
        self.stop_fails=True
        with tempfile.TemporaryDirectory() as folder:
            result=self.run_test(Path(folder)/'report.json')
        self.assertTrue(result['provider_shutdown_verified'])
        self.assertFalse(result['app_shutdown_verified'])
        self.assertEqual(result['result'],'CHECK')
        self.assertTrue(any(c[1]=='PATCH' for c in self.calls))

    def test_repeated_paid_attempt_is_blocked_before_any_request(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'report.json'; self.run_test(path)
            self.calls.clear()
            with self.assertRaises(rehearsal.SetupError): self.run_test(path)
        self.assertEqual(self.calls,[])

    def test_active_configuration_budget_drift_or_rate_increase_prevents_start(self):
        for case in ('active','budget','rate','prior_reservation','disabled_start'):
            self.setUp()
            if case=='active': self.actual['workers']['max']=1
            if case=='budget': self.billing=Decimal('1.01')
            if case=='rate': self.rate=1.34
            if case=='prior_reservation': self.app['demo_compute_reserved_usd']=.10625
            if case=='disabled_start': self.app['can_start']=False
            with tempfile.TemporaryDirectory() as folder, self.assertRaises(rehearsal.SetupError):
                rehearsal.preflight(self,self,self.state,self.expected,Path(folder)/'journal.json')
            self.assertTrue(all(c[1]=='GET' for c in self.calls))

    def test_watchdog_can_disable_provider_without_web_app(self):
        timers=[]
        class CapturedTimer(Timer):
            def __init__(self,seconds,callback):
                super().__init__(seconds,callback); timers.append(self)
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            rehearsal.rehearse(self,self,self.state,self.expected,Path(folder)/'report.json',
                               self.billing,Decimal('.75'),self.clock,self.sleep,CapturedTimer)
            self.calls.clear(); timers[0].callback()
        self.assertEqual(len(self.calls),1)
        self.assertEqual(self.calls[0][1],'PATCH')
        self.assertEqual(self.calls[0][2]['workers']['max'],0)

    def test_model_revision_mismatch_does_not_pass_generation(self):
        self.expected['env']['MODEL_REVISION']='d'*40
        self.actual=deepcopy(self.expected)
        with tempfile.TemporaryDirectory() as folder:
            result=self.run_test(Path(folder)/'report.json')
        self.assertFalse(result['generation_verified'])
        self.assertTrue(result['provider_shutdown_verified'])

    def test_unverified_or_excess_billing_cannot_report_overall_pass(self):
        for broken in (True, False):
            self.setUp()
            original=RehearsalTests.call.__get__(self)
            def billed(path,method='GET',body=None):
                if path==rehearsal.BILLING:
                    if broken: raise rehearsal.SetupError('Billing unavailable')
                    return {'metadata':{'totals':{'totalAmount':'2'}}}
                return original(path,method,body)
            self.call=billed
            with tempfile.TemporaryDirectory() as folder:
                result=self.run_test(Path(folder)/'report.json')
            self.assertEqual(result['result'],'CHECK')
            self.assertTrue(result['provider_shutdown_verified'])
