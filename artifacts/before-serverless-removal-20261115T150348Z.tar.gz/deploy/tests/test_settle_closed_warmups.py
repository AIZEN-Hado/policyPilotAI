from copy import deepcopy
from datetime import datetime,timedelta,timezone
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch

spec=importlib.util.spec_from_file_location('settlement',Path(__file__).resolve().parents[1]/'settle_closed_warmups.py')
settlement=importlib.util.module_from_spec(spec);spec.loader.exec_module(settlement)


class SettlementTests(unittest.TestCase):
    def paused_proposal(self,folder):
        original=self.proposal(folder);root=Path(folder)
        previous={'result':'PASS','database_committed':True,'endpoint_id':'endpoint-test',
                  'proposal':original,'audit_action':settlement.audit_action(original),'observed_reserved_usd':'.529376'}
        (root/'artifacts/runpod-closed-warmup-settlement.json').write_text(json.dumps(previous))
        for index,name in enumerate(('runpod-warmup-startup-fix.json','runpod-warmup-diagnostic.json')):
            row={'endpoint_id':'endpoint-test','model_revision':'a'*40,'start_attempted':True,
                 'generation_verified':False,'provider_shutdown_verified':True,'app_shutdown_verified':True,
                 'deadline_seconds':360,'elapsed_seconds':24.08 if index==0 else 251.09,
                 'gpu_rate_usd_per_hour':'.75','prior_compute_reserved_usd':'.2125' if index==0 else '.529376',
                 'recorded_at':'2026-11-14T18:52:01Z' if index==0 else '2026-11-15T12:30:00Z',
                 'failure_stage':'start_request' if index==0 else 'warmup_status_read',
                 'provider_diagnostic':'Runpod submit: HTTP 409 (ENDPOINT_PAUSED); reconcile before retrying paid work',
                 'shutdown_app_status':{'state':'off','enabled':False,'demo_compute_reserved_usd':'.31875' if index==0 else '.648126'}}
            (root/'artifacts'/name).write_text(json.dumps(row))
        with patch.object(settlement,'bounds',return_value=original):
            result=settlement.paused_bounds(root,{'endpoint_id':'endpoint-test'},{'env':{'MODEL_REVISION':'a'*40}})
        return result,original

    def test_paused_hold_releases_only_padded_unused_portion(self):
        with tempfile.TemporaryDirectory() as folder:proposal,_=self.paused_proposal(folder)
        self.assertEqual(proposal['reserved_before_usd'],'0.648126')
        self.assertEqual(proposal['reserved_after_usd'],'0.559585')
        self.assertEqual(proposal['released_unused_hold_usd'],'0.088541')
        self.assertEqual(proposal['rows'][0]['padded_seconds'],85)
        self.assertEqual(proposal['rows'][0]['retained_bound_usd'],'0.017709')
        self.assertEqual(Decimal(proposal['reserved_after_usd'])+Decimal('.11875'),Decimal('.678335'))

    def test_paused_settlement_requires_prior_database_audit_and_original_job_identities(self):
        with tempfile.TemporaryDirectory() as folder:proposal,_=self.paused_proposal(folder)
        for kind in ('valid','missing_audit','accepted_paused','unmatched_diagnostic'):
            conn,app,_,ledger,jobs,calls,options=self.fixture(proposal)
            if kind!='missing_audit':options['prior_action']=proposal['required_prior_audit_action']
            if kind=='accepted_paused':jobs[0]['provider_id']='unexpected-job'
            if kind=='unmatched_diagnostic':jobs[1]['provider_id']=None
            if kind=='valid':
                original=deepcopy(jobs);result=settlement.settle(conn,app,proposal,Mock(),True)
                self.assertEqual(ledger['compute_reserved_usd'],Decimal('.559585'))
                self.assertEqual(jobs,original);self.assertTrue(result['database_update_prepared'])
            else:
                with self.assertRaises(settlement.SetupError,msg=kind):settlement.settle(conn,app,proposal,Mock(),True)
                self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in calls),kind)

    def test_paused_credit_cannot_be_applied_twice_after_lost_commit_response(self):
        with tempfile.TemporaryDirectory() as folder:proposal,_=self.paused_proposal(folder)
        conn,app,_,ledger,_,calls,options=self.fixture(proposal)
        options['event']=True;ledger['compute_reserved_usd']=Decimal('.559585');app['demo_compute_reserved_usd']=.559585
        result=settlement.settle(conn,app,proposal,Mock(),True)
        self.assertTrue(result['already_applied']);self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in calls))

    def test_paused_hold_rejects_unconfirmed_rejection_or_changed_receipt_history(self):
        for kind in ('rejection','shutdown','history'):
            with tempfile.TemporaryDirectory() as folder:
                _,original=self.paused_proposal(folder);root=Path(folder)
                path=root/'artifacts'/('runpod-closed-warmup-settlement.json' if kind=='history' else 'runpod-warmup-startup-fix.json')
                data=json.loads(path.read_text())
                if kind=='rejection':data['provider_diagnostic']='HTTP 409; unknown reason'
                elif kind=='shutdown':data['provider_shutdown_verified']=False
                else:data['audit_action']='unrelated-action'
                path.write_text(json.dumps(data))
                with patch.object(settlement,'bounds',return_value=original),self.assertRaises(settlement.SetupError):
                    settlement.paused_bounds(root,{'endpoint_id':'endpoint-test'},{'env':{'MODEL_REVISION':'a'*40}})

    def proposal(self,folder,mutate=None):
        root=Path(folder);(root/'artifacts').mkdir(exist_ok=True)
        state={'endpoint_id':'endpoint-test','conservative_serverless_usd_per_hour':'.75'}
        expected={'env':{'MODEL_REVISION':'a'*40}}
        for index,name in enumerate(settlement.NAMES):
            before='.4625' if index==0 else '.58125'
            after='.58125' if index==0 else '.70'
            attempt={'endpoint_id':'endpoint-test','model_revision':'a'*40,'start_attempted':True,
                'generation_verified':False,'provider_shutdown_verified':True,'app_shutdown_verified':True,
                'deadline_seconds':360,'elapsed_seconds':97.52 if index==0 else 102.27,
                'gpu_rate_usd_per_hour':'.75','prior_compute_reserved_usd':before,
                'recorded_at':f'2026-11-15T{9 if index==0 else 12:02d}:00:00+00:00',
                'shutdown_app_status':{'state':'off','enabled':False,'demo_compute_reserved_usd':after}}
            if mutate:mutate(attempt,index)
            (root/'artifacts'/name).write_text(json.dumps(attempt))
        with patch.object(settlement,'long_startup_reservation',return_value=Decimal('.58125')):
            return settlement.bounds(root,state,expected)

    def fixture(self,proposal):
        start=datetime(2026,11,15,12,0,1,tzinfo=timezone.utc)
        app={'configured':True,'operator':True,'state':'off','enabled':False,'started_at':start.isoformat(),
             'demo_inference_allowance_usd':1,'compute_allowance_usd':.7,'demo_compute_reserved_usd':.7}
        control={'phase':'off','enabled':False,'generation':20,'started_at':start,
                 'db_now':start+timedelta(hours=2)}
        ledger={'compute_reserved_usd':Decimal(proposal['reserved_before_usd']),'approved_total_usd':Decimal(1),
                'compute_reservation_limit_usd':Decimal('.70')}
        app['demo_compute_reserved_usd']=float(ledger['compute_reserved_usd'])
        jobs=[]
        for index,row in enumerate(proposal['rows']+proposal.get('validation_only_rows',[])):
            jid=f'00000000-0000-0000-0000-{index+1:012d}'
            jobs.append({'id':jid,'kind':'warmup','state':row['required_job_state'],'case_id':None,
                'generation':index+1,'created_at':settlement.timestamp(row['recorded_at'])+timedelta(seconds=1),
                'reserved_compute_usd':Decimal(row['original_reserved_usd']),'task':'warmup','request_id':jid,'artifact_revision':'a'*40,
                'provider_id':'known-job' if row.get('require_provider_id') else None})
        calls=[];options={'active':False,'event':False,'acquired':True,'ignore_update':False,'prior_action':None}
        def execute(sql,params=None):
            calls.append((sql,params));response=Mock();response.fetchone.return_value=None
            if 'pg_try_advisory' in sql:response.fetchone.return_value={'acquired':options['acquired']}
            elif 'FROM model_control' in sql:response.fetchone.return_value=deepcopy(control)
            elif 'FROM inference_allowance' in sql:response.fetchone.return_value=deepcopy(ledger)
            elif 'FROM model_jobs WHERE state=' in sql:response.fetchone.return_value={'active':1} if options['active'] else None
            elif 'FROM events' in sql:response.fetchone.return_value={'id':1} if options['event'] or params[0]==options['prior_action'] else None
            elif 'FROM model_jobs' in sql:
                response.fetchall.return_value=[deepcopy(j) for j in jobs if params[0]<=j['created_at']<=params[1]]
            elif sql.startswith('UPDATE inference_allowance'):
                if not options['ignore_update']:
                    ledger['compute_reserved_usd']=params[0]
                    response.fetchone.return_value={'compute_reserved_usd':params[0]}
            return response
        conn=Mock();conn.execute.side_effect=execute
        return conn,app,control,ledger,jobs,calls,options

    def test_padded_bounds_leave_original_records_and_limits_intact(self):
        with tempfile.TemporaryDirectory() as folder:proposal=self.proposal(folder)
        self.assertEqual(proposal['reserved_after_usd'],'0.529376')
        self.assertEqual(proposal['released_unused_hold_usd'],'0.170624')
        self.assertEqual([row['padded_seconds'] for row in proposal['rows']],[158,163])
        self.assertEqual(proposal['compute_limit_usd'],'0.700000')
        self.assertTrue(proposal['original_job_reservations_preserved'])
        self.assertFalse(proposal['bounds_are_invoice_amounts'])

    def test_unverified_shutdown_long_duration_or_rate_drift_blocks_bounds(self):
        for key,value in [('provider_shutdown_verified',False),('app_shutdown_verified',False),
                          ('elapsed_seconds',570),('gpu_rate_usd_per_hour','1.34'),('generation_verified',True)]:
            with tempfile.TemporaryDirectory() as folder,self.assertRaises(settlement.SetupError):
                self.proposal(folder,lambda row,index:row.update({key:value}))

    def test_preview_is_read_only_and_checks_provider_under_lock(self):
        with tempfile.TemporaryDirectory() as folder:proposal=self.proposal(folder)
        conn,app,_,ledger,_,calls,_=self.fixture(proposal);idle=Mock()
        result=settlement.settle(conn,app,proposal,idle)
        idle.assert_called_once();self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in calls))
        self.assertFalse(result['database_update_prepared']);self.assertEqual(ledger['compute_reserved_usd'],Decimal('.70'))

    def test_apply_changes_only_ledger_with_audit_original_jobs_preserved(self):
        with tempfile.TemporaryDirectory() as folder:proposal=self.proposal(folder)
        conn,app,_,ledger,jobs,calls,_=self.fixture(proposal);original=deepcopy(jobs)
        result=settlement.settle(conn,app,proposal,Mock(),True)
        writes=[sql for sql,_ in calls if not sql.startswith('SELECT ')]
        self.assertEqual(len(writes),2);self.assertTrue(writes[0].startswith('UPDATE inference_allowance'))
        self.assertTrue(writes[1].startswith('INSERT INTO events'))
        self.assertNotIn('compute_reservation_limit_usd=',writes[0])
        self.assertEqual(ledger['compute_reserved_usd'],Decimal('.529376'))
        self.assertEqual(jobs,original);self.assertTrue(result['database_update_prepared'])

    def test_audit_makes_interrupted_commit_reconciliation_idempotent(self):
        with tempfile.TemporaryDirectory() as folder:proposal=self.proposal(folder)
        conn,app,_,ledger,_,calls,options=self.fixture(proposal)
        options['event']=True;ledger['compute_reserved_usd']=Decimal('.529376');app['demo_compute_reserved_usd']=.529376
        result=settlement.settle(conn,app,proposal,Mock(),True)
        self.assertTrue(result['already_applied']);self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in calls))

    def test_active_jobs_wrong_db_ledger_or_terminal_state_blocks_all_writes(self):
        with tempfile.TemporaryDirectory() as folder:proposal=self.proposal(folder)
        for kind in ('active','lock','ledger','state','revision','identity','operator','session','young'):
            conn,app,control,ledger,jobs,calls,options=self.fixture(proposal)
            if kind=='active':options['active']=True
            elif kind=='lock':options['acquired']=False
            elif kind=='ledger':ledger['compute_reserved_usd']=Decimal('.6');app['demo_compute_reserved_usd']=.6
            elif kind=='state':jobs[1]['state']='IN_QUEUE'
            elif kind=='revision':jobs[1]['artifact_revision']='b'*40
            elif kind=='identity':jobs[1]['request_id']='unrelated'
            elif kind=='operator':app['operator']=False
            elif kind=='session':app['started_at']='2026-11-14T12:00:00Z'
            elif kind=='young':control['db_now']=control['started_at']+timedelta(seconds=200)
            with self.assertRaises(settlement.SetupError,msg=kind):settlement.settle(conn,app,proposal,Mock(),True)
            self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in calls),kind)

    def test_unknown_provider_state_or_failed_update_does_not_create_audit(self):
        with tempfile.TemporaryDirectory() as folder:proposal=self.proposal(folder)
        conn,app,_,_,_,calls,_=self.fixture(proposal)
        with self.assertRaises(settlement.SetupError):
            settlement.settle(conn,app,proposal,Mock(side_effect=settlement.SetupError('unavailable')),True)
        self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in calls))
        conn,app,_,_,_,calls,options=self.fixture(proposal);options['ignore_update']=True
        with self.assertRaises(settlement.SetupError):settlement.settle(conn,app,proposal,Mock(),True)
        self.assertFalse(any(sql.startswith('INSERT INTO events') for sql,_ in calls))
