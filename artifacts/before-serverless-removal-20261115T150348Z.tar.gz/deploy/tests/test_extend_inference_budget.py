from copy import deepcopy
from datetime import datetime,timedelta,timezone
from decimal import Decimal
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import Mock

spec=importlib.util.spec_from_file_location('extra_budget',Path(__file__).resolve().parents[1]/'extend_inference_budget.py')
budget=importlib.util.module_from_spec(spec);spec.loader.exec_module(budget)


class ExtraBudgetTests(unittest.TestCase):
    def fixture(self):
        start=datetime(2026,11,15,14,19,26,tzinfo=timezone.utc);reserved=Decimal('.678335')
        app={'configured':True,'operator':True,'enabled':False,'state':'off','started_at':start.isoformat(),
             'compute_allowance_usd':1.7,'demo_compute_reserved_usd':.678335,'demo_inference_allowance_usd':1}
        control={'enabled':False,'phase':'off','started_at':start,'generation':20}
        ledger={'compute_reserved_usd':reserved,'approved_total_usd':Decimal(1),'compute_reservation_limit_usd':Decimal('.70')}
        job={'id':'00000000-0000-0000-0000-000000000001','provider_id':'known-job','kind':'warmup',
             'state':'FAILED','case_id':None,'generation':19,'reserved_compute_usd':Decimal('.11875'),
             'task':'warmup','request_id':'00000000-0000-0000-0000-000000000001','artifact_revision':'a'*40}
        attempt={'recorded_at':(start-timedelta(seconds=1)).isoformat(),'model_revision':'a'*40}
        options={'lock':True,'active':False,'prior':True,'applied':False,'ignore_update':False,'corrupt_hold':False}
        calls=[]
        def execute(sql,params=None):
            calls.append((sql,params));result=Mock();result.fetchone.return_value=None
            if 'pg_try_advisory' in sql:result.fetchone.return_value={'acquired':options['lock']}
            elif 'FROM model_control' in sql:result.fetchone.return_value=deepcopy(control)
            elif 'FROM inference_allowance' in sql:result.fetchone.return_value=deepcopy(ledger)
            elif 'FROM model_jobs WHERE state=' in sql:result.fetchone.return_value={'id':1} if options['active'] else None
            elif 'FROM model_jobs' in sql:result.fetchall.return_value=[deepcopy(job)]
            elif 'FROM events' in sql:
                present=options['prior'] if params[0]=='prior-action' else options['applied']
                result.fetchone.return_value={'id':1} if present else None
            elif sql.startswith('UPDATE inference_allowance') and not options['ignore_update']:
                ledger.update(approved_total_usd=Decimal(2),compute_reservation_limit_usd=Decimal('1.70'))
                if options['corrupt_hold']:ledger['compute_reserved_usd']=Decimal(0)
                result.fetchone.return_value={'id':1}
            return result
        conn=Mock();conn.execute.side_effect=execute
        return conn,app,control,ledger,job,attempt,options,calls

    def invoke(self,fixture,idle=None,apply=True):
        conn,app,_,_,_,attempt,_,_=fixture
        return budget.extend(conn,app,'endpoint-test',Decimal('.678335'),'prior-action',attempt,idle or Mock(),apply)

    def test_extension_changes_only_two_limits_and_retains_all_holds_with_audit(self):
        fixture=self.fixture();_,_,_,ledger,job,_,_,calls=fixture;original=deepcopy(job)
        result=self.invoke(fixture)
        self.assertEqual(ledger['compute_reserved_usd'],Decimal('.678335'))
        self.assertEqual(ledger['approved_total_usd'],2);self.assertEqual(ledger['compute_reservation_limit_usd'],Decimal('1.70'))
        self.assertEqual(job,original);self.assertTrue(result['database_update_prepared'])
        writes=[(sql,params) for sql,params in calls if not sql.startswith('SELECT ')]
        self.assertEqual(len(writes),2)
        self.assertNotIn('SET compute_reserved_usd',writes[0][0]);self.assertTrue(writes[1][0].startswith('INSERT INTO events'))
        self.assertEqual(writes[0][1],(Decimal('.678335'),))

    def test_preview_checks_idle_but_never_updates_allowance(self):
        fixture=self.fixture();idle=Mock();result=self.invoke(fixture,idle,False)
        idle.assert_called_once();self.assertFalse(result['database_update_prepared'])
        self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in fixture[-1]))

    def test_committed_extension_cannot_add_another_dollar(self):
        fixture=self.fixture();_,app,_,ledger,_,_,options,calls=fixture
        options['applied']=True;ledger.update(approved_total_usd=Decimal(2),compute_reservation_limit_usd=Decimal('1.70'))
        app['demo_inference_allowance_usd']=2
        result=self.invoke(fixture)
        self.assertTrue(result['already_applied']);self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in calls))

    def test_mismatched_ledger_session_environment_or_job_blocks_all_mutations(self):
        for kind in ('lock','active','prior','limit','hold','job','session','unknown_existing_limits'):
            fixture=self.fixture();_,app,_,ledger,job,_,options,calls=fixture
            if kind in ('lock','prior'):options[kind]=False
            elif kind=='active':options['active']=True
            elif kind=='limit':app['compute_allowance_usd']=.7
            elif kind=='hold':ledger['compute_reserved_usd']=Decimal('.6');app['demo_compute_reserved_usd']=.6
            elif kind=='job':job['state']='IN_PROGRESS'
            elif kind=='session':app['started_at']='2026-11-14T14:19:26Z'
            else:ledger['approved_total_usd']=Decimal(2);app['demo_inference_allowance_usd']=2
            with self.assertRaises(budget.SetupError,msg=kind):self.invoke(fixture)
            self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in calls),kind)

    def test_unavailable_provider_or_failed_update_cannot_be_claimed_successful(self):
        fixture=self.fixture()
        with self.assertRaises(budget.SetupError):self.invoke(fixture,Mock(side_effect=budget.SetupError('unavailable')))
        self.assertTrue(all(sql.startswith('SELECT ') for sql,_ in fixture[-1]))
        for key in ('ignore_update','corrupt_hold'):
            fixture=self.fixture();fixture[-2][key]=True
            with self.assertRaises(budget.SetupError,msg=key):self.invoke(fixture)
