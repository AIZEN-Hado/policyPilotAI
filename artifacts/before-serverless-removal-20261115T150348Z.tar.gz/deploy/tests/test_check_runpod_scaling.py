from copy import deepcopy
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('scaling',Path(__file__).resolve().parents[1]/'check_runpod_scaling.py')
scaling=importlib.util.module_from_spec(spec);spec.loader.exec_module(scaling)


class Timer:
    def __init__(self,*args):pass
    def start(self):pass
    def cancel(self):pass
    def is_alive(self):return False


class ScalingTests(unittest.TestCase):
    def test_dedicated_legacy_key_is_optional_hidden_and_never_saved(self):
        private={'RUNPOD_API_KEY':'private-setup'}
        self.assertEqual(scaling.legacy_credential(private),'private-setup')
        with patch.object(scaling.sys.stdin,'isatty',return_value=True), \
             patch.object(scaling.getpass,'getpass',return_value=' private-control ') as prompt:
            self.assertEqual(scaling.legacy_credential(private,True),'private-control')
        self.assertEqual(private,{'RUNPOD_API_KEY':'private-setup'})
        self.assertIn('RUNPOD_CONTROL_KEY',prompt.call_args.args[0])

    def test_missing_or_noninteractive_control_key_blocks_before_provider_access(self):
        with patch.object(scaling.sys.stdin,'isatty',return_value=False), \
             patch.object(scaling.getpass,'getpass') as prompt:
            with self.assertRaises(scaling.SetupError):scaling.legacy_credential({},True)
            prompt.assert_not_called()
        with patch.object(scaling.sys.stdin,'isatty',return_value=True), \
             patch.object(scaling.getpass,'getpass',return_value=''):
            with self.assertRaises(scaling.SetupError):scaling.legacy_credential({},True)

    def setUp(self):
        self.expected=scaling.payload({'model':{'repository':'Qwen/Qwen2.5-7B-Instruct','revision':'a'*40},
            'image':'ghcr.io/aizen-hado/policypilot-gpu@sha256:'+'b'*64,'gpu':{'pool':'AMPERE_24'}},
            'c'*32,'registry-test','endpoint-test')
        self.actual=deepcopy(self.expected);self.actual['id']='endpoint-test'
        self.state={'endpoint_id':'endpoint-test','conservative_serverless_usd_per_hour':'.75'}
        self.calls=[];self.legacy_max=0;self.mismatch=False;self.read_failed=False;self.enabled=False
        self.billing='.5064673366287025';self.v2_disable_ignored=False

    def call(self,path,method='GET',body=None):
        self.calls.append((path,method,body))
        if path.startswith('/v2/billing'):return {'metadata':{'totals':{'totalAmount':self.billing}}}
        if path.startswith('/v2/catalog/'):
            return {'gpus':[{'manufacturer':'NVIDIA','memory':24,'pool':'AMPERE_24','price':{'serverless':.75},'availability':'HIGH','name':'synthetic'}]}
        if path.endswith('/workers'):
            return {'workers':[],'summary':{k:0 for k in ('running','idle','initializing','throttled','unhealthy','total')}}
        self.assertEqual(path,'/v2/serverless/endpoint-test')
        if method=='PATCH':
            maximum=body['workers']['max'];self.enabled=maximum==1
            self.actual['workers']['max']=maximum
            if not self.mismatch and not (maximum==0 and self.v2_disable_ignored):self.legacy_max=maximum
        return deepcopy(self.actual)

    def read(self):
        self.calls.append(('legacy','GET',None))
        if self.enabled and self.read_failed:raise scaling.SetupError('private-secret')
        return {'id':'endpoint-test','workersMin':0,'workersMax':self.legacy_max,'KEY':'private-secret'}

    def disable(self):
        self.calls.append(('legacy','PATCH',{'workersMin':0,'workersMax':0,'idleTimeout':300}))
        self.legacy_max=0

    def run_check(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'result.json'
            result=scaling.verify(self,self,self.state,self.expected,path,Timer,lambda _:None)
            self.assertEqual(json.loads(path.read_text()),result)
            self.assertNotIn('private-secret',path.read_text())
            return result

    def test_agreement_and_fresh_verified_shutdown_without_jobs(self):
        report=self.run_check()
        self.assertEqual(report['result'],'CONTROL_AGREEMENT')
        self.assertTrue(report['shutdown_verified'])
        self.assertEqual(report['requests_submitted'],0)
        self.assertTrue(all(method in ('GET','PATCH') for _,method,_ in self.calls))
        self.assertEqual(sum(method=='PATCH' and body.get('workers',{}).get('max')==1 for _,method,body in self.calls),1)

    def test_mismatch_is_saved_and_shut_down(self):
        self.mismatch=True
        report=self.run_check()
        self.assertEqual(report['result'],'CONTROL_MISMATCH')
        self.assertEqual(report['enabled_readback'],{'v1':{'min':0,'max':0},'v2':{'min':0,'max':1}})
        self.assertTrue(report['shutdown_verified'])

    def test_read_failure_after_enable_still_disables(self):
        self.read_failed=True
        with self.assertRaises(scaling.SetupError):self.run_check()
        self.assertEqual(self.actual['workers']['max'],0)
        self.assertEqual(self.legacy_max,0)

    def test_legacy_shutdown_fallback_is_read_back(self):
        self.v2_disable_ignored=True
        report=self.run_check()
        self.assertTrue(report['shutdown_verified'])
        self.assertTrue(any(path=='legacy' and method=='PATCH' for path,method,_ in self.calls))
        self.assertEqual(self.legacy_max,0)

    def test_active_endpoint_or_budget_shortfall_blocks_all_writes(self):
        for field in ('active','budget'):
            self.setUp()
            if field=='active':self.legacy_max=1
            else:self.billing='1.5'
            with self.assertRaises(scaling.SetupError):self.run_check()
            self.assertTrue(all(method=='GET' for _,method,_ in self.calls))
