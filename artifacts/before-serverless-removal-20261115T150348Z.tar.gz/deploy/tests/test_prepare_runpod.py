import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('preparation',Path(__file__).resolve().parents[1]/'prepare_runpod.py')
preparation=importlib.util.module_from_spec(spec);spec.loader.exec_module(preparation)


class PreparationTests(unittest.TestCase):
    def metadata(self):
        return {'id':preparation.MODEL,'sha':'a'*40,'private':False,'gated':False,
                'safetensors':{'total':7_615_616_512}}

    def test_model_plan_records_real_size_and_unverified_memory(self):
        result=preparation.model_details(self.metadata(),{'metadata':{'total_size':15_231_233_024}})
        self.assertEqual(result['quantized_weight_bytes_lower_bound'],3_807_808_256)
        self.assertIn('not_PolicyPilot',result['release_kind'])
        self.assertIn('unverified',result['model_process_ram_below_2000000000_bytes'])

    def test_model_identity_revision_and_access_fail_closed(self):
        for update in ({'id':'other'},{'sha':'main'},{'gated':'auto'},{'private':True},
                       {'safetensors':{'total':100}}):
            with self.assertRaises(preparation.PreparationError):
                preparation.model_details({**self.metadata(),**update},{'metadata':{'total_size':100}})

    def test_credentials_are_parsed_without_shell_expansion(self):
        with tempfile.TemporaryDirectory() as folder,patch.dict(preparation.os.environ,{},clear=True):
            path=Path(folder)/'cloud.env'
            path.write_text("export RUNPOD_API_KEY='literal-$(false)-token'\nexport R2_ACCOUNT_ID='"+'a'*32+"'\n")
            path.chmod(0o600)
            values=preparation.credentials(path)
            self.assertEqual(values['RUNPOD_API_KEY'],'literal-$(false)-token')
            path.chmod(0o644)
            with self.assertRaises(preparation.PreparationError):preparation.credentials(path)

    def test_management_key_cannot_be_sent_to_huggingface(self):
        with self.assertRaises(preparation.PreparationError):
            preparation.get_json('https://huggingface.co/api/models/x','test',token='private-token')

    def test_private_digest_required(self):
        for image in ({'name':'policypilot-gpu','visibility':'public','reference':'anything'},
                      {'name':'policypilot-gpu','visibility':'private','reference':'ghcr.io/aizen-hado/policypilot-gpu:latest'}):
            with self.assertRaises(preparation.PreparationError):preparation.image_reference({'images':[image]})

    def test_preparation_uses_only_reads_and_does_not_save_management_key(self):
        catalog={'gpus':[{'manufacturer':'NVIDIA','memory':24,'pool':'AMPERE_24',
                         'name':'Synthetic GPU','price':{'serverless':0.75},'availability':'HIGH'}]}
        image={'name':'policypilot-gpu','visibility':'private',
               'reference':'ghcr.io/aizen-hado/policypilot-gpu@sha256:'+'b'*64}
        results=[[],[],catalog,self.metadata(),{'metadata':{'total_size':15_231_233_024}},{'paths':{}}]
        output=io.StringIO()
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'artifacts').mkdir()
            (root/'artifacts/published-images.json').write_text(json.dumps({'images':[image]}))
            with patch.object(preparation,'ROOT',root),\
                 patch.object(preparation,'credentials',return_value={'RUNPOD_API_KEY':'private-token','R2_ACCOUNT_ID':'a'*32}),\
                 patch.object(preparation,'get_json',side_effect=results) as fetch,contextlib.redirect_stdout(output):
                preparation.main()
            plan_text=(root/'artifacts/runpod-connection-plan.json').read_text()
            plan=json.loads(plan_text)
        self.assertEqual(fetch.call_count,6)
        self.assertFalse(plan['compute_started'])
        self.assertFalse(plan['ready_for_paid_execution'])
        self.assertEqual(plan['proposed_disabled_settings']['workers']['max'],0)
        for value in (output.getvalue(),plan_text):self.assertNotIn('private-token',value)
        # Provider key is passed only for the fixed Runpod reads, never to HF/schema.
        for call in fetch.call_args_list[3:]:self.assertEqual(len(call.args),2)
