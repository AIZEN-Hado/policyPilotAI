from pathlib import Path
import importlib.util
import json
import tempfile
import unittest
from unittest.mock import Mock,patch

spec=importlib.util.spec_from_file_location('observer',Path(__file__).resolve().parents[1]/'worker_observer.py')
observer=importlib.util.module_from_spec(spec);spec.loader.exec_module(observer)


class ObserverTests(unittest.TestCase):
    def test_saves_ids_before_log_reads_with_no_env_or_raw_output(self):
        api=Mock();api.call.return_value={'workers':[{'id':'worker-one','status':'RUNNING','env':{'KEY':'private-secret'}}]}
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'workers.json';watch=observer.WorkerObserver(api,{'endpoint_id':'endpoint-one'},path)
            watch.sample()
            with patch.object(observer,'worker_log_read',return_value={'read_verified':True,'events':[]}) as read:
                self.assertEqual(watch.capture(),['worker-one'])
                self.assertEqual([call.args[3] for call in read.call_args_list],['system','container'])
                self.assertTrue(all(call.kwargs=={'duration':5} for call in read.call_args_list))
            report=json.loads(path.read_text())
            self.assertEqual(report['workers']['worker-one']['last_status'],'RUNNING')
            self.assertNotIn('private-secret',json.dumps(report))
            api.call.assert_called_once_with('/v2/serverless/endpoint-one/workers')

    def test_failed_log_read_stops_without_retry_or_mutation(self):
        api=Mock();api.call.return_value={'workers':[{'id':'worker-one','status':'INITIALIZING'}]}
        with tempfile.TemporaryDirectory() as folder:
            watch=observer.WorkerObserver(api,{'endpoint_id':'endpoint-one'},Path(folder)/'workers.json');watch.sample()
            with patch.object(observer,'worker_log_read',return_value={'read_verified':False,'http_status':404}) as read:
                watch.capture();read.assert_called_once()
            self.assertEqual(watch.report['log_sources'][0]['http_status'],404)
            api.call.assert_called_once()

    def test_old_worker_ids_survive_later_empty_worker_lists(self):
        api=Mock();api.call.side_effect=[{'workers':[{'id':'worker-one','status':'INITIALIZING'}]},{'workers':[]}]
        with tempfile.TemporaryDirectory() as folder:
            watch=observer.WorkerObserver(api,{'endpoint_id':'endpoint-one'},Path(folder)/'workers.json')
            watch.sample();watch.sample()
            self.assertIn('worker-one',watch.report['workers'])

    def test_invalid_worker_identifier_never_reaches_logs(self):
        api=Mock();api.call.return_value={'workers':[{'id':'../private-url'}]}
        with tempfile.TemporaryDirectory() as folder:
            watch=observer.WorkerObserver(api,{'endpoint_id':'endpoint-one'},Path(folder)/'workers.json')
            with self.assertRaises(observer.SetupError):watch.sample()
            self.assertEqual(watch.report['workers'],{})
