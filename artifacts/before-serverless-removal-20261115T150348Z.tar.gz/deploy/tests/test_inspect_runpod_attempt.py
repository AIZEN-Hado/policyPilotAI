import importlib.util
from pathlib import Path
import json
import unittest
import tempfile
import io
from contextlib import redirect_stdout
from unittest.mock import patch, Mock

spec=importlib.util.spec_from_file_location('attempt_inspection',Path(__file__).resolve().parents[1]/'inspect_runpod_attempt.py')
inspection=importlib.util.module_from_spec(spec);spec.loader.exec_module(inspection)


class InspectionTests(unittest.TestCase):
    def test_redacted_loader_reason_and_library_locations_survive_log_collection(self):
        row={'source':'container','line':'POLICYPILOT_DIAGNOSTIC '+json.dumps({
            'event':'failure','stage':'load_model','category':'processing_failure',
            'exception_type':'RuntimeError',
            'model_loader_reason':'CUDA error: invalid device function https://private.invalid?token=secret-value',
            'library_frames':[{'file':'transformers/modeling_utils.py','line':42,'locals':'private-secret'}]})}
        result=inspection.log_signals(row)
        diagnostic=result['worker_diagnostic']
        self.assertIn('invalid device function',diagnostic['model_loader_reason'])
        self.assertEqual(diagnostic['library_frames'],[{'file':'transformers/modeling_utils.py','line':42}])
        for value in ('private.invalid','secret-value','private-secret'):
            self.assertNotIn(value,json.dumps(result))

    def test_billing_reads_only_selected_endpoint_and_excludes_secrets(self):
        api=Mock();api.call.side_effect=[{'metadata':{'totals':{'totalAmount':'.63'}}},
            {'metadata':{'totals':{'totalAmount':'.12'}},'records':[
                {'serverlessId':'endpoint-test','totalAmount':'.12',
                 'startTime':'2026-11-15T12:00:00Z','secret':'private-secret'}]}]
        report=inspection.billing_check(api,{'endpoint_id':'endpoint-test'})
        self.assertEqual(report['account_30day_reported_usd'],'0.63')
        self.assertEqual(report['endpoint_last_120_hour_buckets_reported_usd'],'0.12')
        self.assertFalse(report['reservations_changed'])
        self.assertNotIn('private-secret',json.dumps(report))
        self.assertEqual(api.call.call_args_list[0].args,('/v2/billing?lastN=30&bucketSize=day',))
        self.assertEqual(api.call.call_args_list[1].args,
            ('/v2/billing/serverless?serverlessId=endpoint-test&lastN=120&bucketSize=hour',))
        self.assertTrue(all(not call.kwargs for call in api.call.call_args_list))

    def test_billing_rejects_wrong_endpoint_or_inconsistent_totals(self):
        for identifier,total in [('other-endpoint','.12'),('endpoint-test','.13')]:
            api=Mock();api.call.side_effect=[{'metadata':{'totals':{'totalAmount':'.63'}}},
                {'metadata':{'totals':{'totalAmount':total}},'records':[
                    {'serverlessId':identifier,'totalAmount':'.12','startTime':'2026-11-15T12:00:00Z'}]}]
            with self.assertRaises(inspection.SetupError):
                inspection.billing_check(api,{'endpoint_id':'endpoint-test'})

    def test_log_signal_classifier_never_saves_raw_text_or_credentials(self):
        row={'source':'system','ts':'2026-11-15T09:29:00Z',
             'line':'Failed to pull private-secret: unauthorized https://example.com?key=private-secret'}
        result=inspection.log_signals(row)
        self.assertIn('image_pull_failure',result['signals'])
        self.assertIn('access_rejection',result['signals'])
        self.assertNotIn('private-secret',json.dumps(result))
        self.assertNotIn('example.com',json.dumps(result))
        self.assertEqual(result['timestamp'],'2026-11-15T09:29:00+00:00')

    def test_structured_worker_diagnostic_is_retained_without_arbitrary_fields(self):
        row={'source':'container','line':'POLICYPILOT_DIAGNOSTIC '+json.dumps({
            'event':'failure','stage':'download_model','category':'remote_http','http_status':403,
            'message':'private-secret','token':'private-secret'})}
        result=inspection.log_signals(row)
        self.assertEqual(result['worker_diagnostic']['http_status'],403)
        self.assertIn('worker_diagnostic',result['signals'])
        self.assertNotIn('private-secret',json.dumps(result))

    def test_worker_log_read_uses_fixed_get_and_keeps_only_pattern_metadata(self):
        rows=[{'source':'container','ts':'2026-11-15T03:15:01Z','line':'Starting Serverless Worker | Version 1.7.9 private-secret'},
              {'source':'container','ts':'2026-11-15T03:15:02Z','line':'private-secret'}]
        response=io.BytesIO(b''.join(b'data: '+json.dumps(row).encode()+b'\n\n' for row in rows))
        response.headers={'Content-Type':'text/event-stream'}
        api=Mock();api.token='private-key';api.opener.open.return_value=response
        result=inspection.worker_log_read(api,{'endpoint_id':'endpoint-test'},'worker-test','container')
        self.assertEqual(result['records_seen'],2)
        self.assertEqual(result['events'][0]['signals'],['sdk_start_banner'])
        self.assertNotIn('private-secret',json.dumps(result))
        self.assertNotIn('private-key',json.dumps(result))
        request=api.opener.open.call_args.args[0]
        self.assertEqual(request.method,'GET')
        self.assertEqual(request.full_url,'https://api.runpod.io/v2/serverless/endpoint-test/workers/worker-test/logs?source=container&tail=200')
        self.assertEqual(request.get_header('Authorization'),'Bearer private-key')

    def test_log_permission_failure_and_unknown_body_never_verify_history(self):
        import urllib.error
        api=Mock();api.token='private-key'
        api.opener.open.side_effect=urllib.error.HTTPError('private-url',403,'private-secret',{},io.BytesIO())
        result=inspection.worker_log_read(api,{'endpoint_id':'endpoint-test'},'worker-test','system')
        self.assertFalse(result['read_verified']);self.assertEqual(result['http_status'],403)
        self.assertNotIn('private-secret',json.dumps(result))
        response=io.BytesIO(b'private-secret');response.headers={'Content-Type':'text/html'}
        api.opener.open.side_effect=None;api.opener.open.return_value=response
        result=inspection.worker_log_read(api,{'endpoint_id':'endpoint-test'},'worker-test','system')
        self.assertFalse(result['read_verified']);self.assertTrue(result['stream_format_unrecognized'])

    def test_worker_log_url_injection_is_blocked_before_network(self):
        api=Mock()
        with self.assertRaises(inspection.SetupError):
            inspection.worker_log_read(api,{'endpoint_id':'endpoint-test'},'../worker','system')
        api.opener.open.assert_not_called()

    def test_routing_read_checks_exact_urls_without_following_or_printing_them(self):
        api=Mock()
        urls={name:'https://api.runpod.ai/v2/endpoint-test/'+suffix for name,suffix in
              {'run':'run','health':'health','status':'status/{job_id}','cancel':'cancel/{job_id}'}.items()}
        api.call.return_value={'id':'endpoint-test','requestUrls':urls,'env':{'KEY':'private-secret'}}
        report=inspection.routing_check(api,{'endpoint_id':'endpoint-test'})
        self.assertTrue(report['all_client_routes_match'])
        api.call.assert_called_once_with('/v2/serverless/endpoint-test')
        urls['run']='https://private-secret.invalid/run?token=private-secret'
        report=inspection.routing_check(api,{'endpoint_id':'endpoint-test'})
        self.assertFalse(report['all_client_routes_match'])
        self.assertNotIn('private-secret',json.dumps(report))

    def test_missing_routing_or_wrong_identity_never_verifies(self):
        api=Mock();api.call.return_value={'id':'endpoint-test'}
        report=inspection.routing_check(api,{'endpoint_id':'endpoint-test'})
        self.assertFalse(report['provider_urls_present'])
        self.assertFalse(report['all_client_routes_match'])
        api.call.return_value={'id':'other'}
        with self.assertRaises(inspection.SetupError):inspection.routing_check(api,{'endpoint_id':'endpoint-test'})

    def audit_attempt(self):
        return {'endpoint_id':'endpoint-test','recorded_at':'2026-11-14T12:45:47+00:00',
                'failure_stage':'start_request',
                'provider_diagnostic':'Runpod submit: HTTP 409; reconcile before retrying paid work'}

    def test_conflict_audit_is_read_only_and_excludes_private_fields(self):
        api=Mock()
        api.call.return_value={'auditLogs':[
            {'resourceId':'endpoint-test','timestamp':'2026-11-14T12:45:49Z','action':'update',
             'email':'private-secret','value':json.dumps({'workers':{'min':0,'max':1},'KEY':'private-secret'})},
            {'resourceId':'other','value':'private-secret'}],
            'pagination':{'hasNextPage':False}}
        report=inspection.conflict_audit(api,{'endpoint_id':'endpoint-test'},self.audit_attempt())
        api.call.assert_called_once()
        self.assertTrue(api.call.call_args.args[0].startswith('/v2/audit-logs?'))
        self.assertEqual(len(api.call.call_args.args),1)
        self.assertEqual(report['audit_entries'][0]['workers'],{'min':0,'max':1})
        self.assertTrue(report['audit_complete'])
        self.assertNotIn('private-secret',json.dumps(report))
        self.assertFalse(report['original_rejection_reason_verified'])

    def test_audit_permission_failure_never_becomes_empty_history(self):
        api=Mock();api.call.side_effect=inspection.ProviderHTTPError('private-secret',403)
        report=inspection.conflict_audit(api,{'endpoint_id':'endpoint-test'},self.audit_attempt())
        self.assertEqual(report['audit_http_status'],403)
        self.assertFalse(report['audit_read_verified'])
        self.assertFalse(report['audit_complete'])
        self.assertNotIn('private-secret',json.dumps(report))
        api.call.assert_called_once()

    def test_audit_bounds_pagination_and_rejects_wrong_endpoint_before_read(self):
        api=Mock();api.call.return_value={'auditLogs':[],
                    'pagination':{'hasNextPage':True,'nextCursor':'next'}}
        report=inspection.conflict_audit(api,{'endpoint_id':'endpoint-test'},self.audit_attempt())
        self.assertEqual(api.call.call_count,3)
        self.assertFalse(report['audit_complete'])
        api.reset_mock()
        with self.assertRaises(inspection.SetupError):
            inspection.conflict_audit(api,{'endpoint_id':'other-endpoint'},self.audit_attempt())
        api.call.assert_not_called()

    def test_main_uses_different_management_and_runtime_keys_without_saving_them(self):
        control=Mock()
        control.call.return_value={'workers':{'min':0,'max':0,'idleTimeout':300},
                                   'metadata':{'totals':{'totalAmount':'.506'}}}
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder); (root/'artifacts').mkdir()
            (root/'artifacts/runpod-disabled-setup.json').write_text(json.dumps({
                'endpoint_id':'endpoint-test','model_revision':'a'*40}))
            with patch.object(inspection,'ROOT',root), \
                 patch.object(inspection,'credentials',return_value={'RUNPOD_API_KEY':'private-setup-key'}), \
                 patch.object(inspection.sys.stdin,'isatty',return_value=True), \
                 patch.object(inspection.getpass,'getpass',return_value='private-inference-key'), \
                 patch.object(inspection,'API',return_value=control) as constructor, \
                 patch.object(inspection,'runtime_read',return_value={'requests':[]}) as runtime, \
                 redirect_stdout(io.StringIO()) as output:
                inspection.main()
            constructor.assert_called_once_with('private-setup-key')
            self.assertEqual([c.args for c in runtime.call_args_list],[
                ('endpoint-test','private-inference-key','health'),
                ('endpoint-test','private-inference-key','requests')])
            saved=(root/'artifacts/runpod-attempt-inspection.json').read_text()
            for secret in ('private-setup-key','private-inference-key'):
                self.assertNotIn(secret,saved+output.getvalue())

    def test_setup_or_missing_key_rejected_before_provider_reads(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder); (root/'artifacts').mkdir()
            (root/'artifacts/runpod-disabled-setup.json').write_text('{}')
            for supplied in ('','private-setup-key'):
                with patch.object(inspection,'ROOT',root), \
                     patch.object(inspection,'credentials',return_value={'RUNPOD_API_KEY':'private-setup-key'}), \
                     patch.object(inspection.sys.stdin,'isatty',return_value=True), \
                     patch.object(inspection.getpass,'getpass',return_value=supplied), \
                     patch.object(inspection,'API') as api, \
                     patch.object(inspection,'runtime_read') as runtime, \
                     redirect_stdout(io.StringIO()), self.assertRaises(inspection.SetupError):
                    inspection.main()
                api.assert_not_called(); runtime.assert_not_called()

    def test_request_summary_keeps_only_safe_metadata(self):
        row={'id':'11111111-2222-3333-4444-555555555555-u1','status':'FAILED','executionTime':42,
             'error':'private-secret','output':'private-secret','input':{'task':'warmup','artifact_revision':'a'*40,
                'request_id':'11111111-2222-3333-4444-555555555555','token':'private-secret'}}
        result=inspection.request_summary({'requests':[row]},'a'*40)
        self.assertNotIn('private-secret',json.dumps(result))
        self.assertTrue(result['requests'][0]['matches_pinned_warmup'])
        self.assertEqual(result['requests'][0]['status'],'FAILED')
        self.assertFalse(result['history_completeness_verified'])

    def test_empty_unknown_history_never_proves_absence(self):
        self.assertFalse(inspection.request_summary({},'a'*40)['list_shape_recognized'])
        result=inspection.request_summary({'requests':[]},'a'*40)
        self.assertEqual(result['returned_rows'],0)
        self.assertFalse(result['history_completeness_verified'])

    def test_reads_only_with_permission_failure_recorded_and_no_raw_data(self):
        calls=[]
        class API:
            def call(self,path,method='GET',body=None):
                calls.append((path,method,body))
                if '/billing' in path:return {'metadata':{'totals':{'totalAmount':'.506'}}}
                if path.endswith('/workers'):return {'summary':{'total':0,'secret':'private-secret'}}
                return {'workers':{'min':0,'max':0,'idleTimeout':300},'env':{'KEY':'private-secret'}}
        def runtime(operation):
            calls.append((operation,'GET',None))
            if operation=='requests':raise inspection.ProviderHTTPError('private-secret',403)
            return {'jobs':{'inQueue':0,'inProgress':0},'workers':{'running':0}}
        result=inspection.inspect(API(),runtime,{'endpoint_id':'endpoint-test','model_revision':'a'*40})
        self.assertTrue(all(method=='GET' and body is None for _,method,body in calls))
        self.assertEqual(result['request_history']['http_status'],403)
        self.assertNotIn('private-secret',json.dumps(result))
        self.assertFalse(result['historical_absence_proven'])
