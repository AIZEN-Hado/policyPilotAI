from copy import deepcopy
from datetime import datetime,timezone
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import io
from contextlib import redirect_stdout
from unittest.mock import Mock

spec=importlib.util.spec_from_file_location('worker_start',Path(__file__).resolve().parents[1]/'start_existing_worker.py')
worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker)


class Timer:
    def __init__(self,seconds,callback):self.seconds=seconds;self.callback=callback
    def start(self):pass
    def cancel(self):pass
    def is_alive(self):return False


class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.seconds=0;self.calls=[];self.started=False;self.fail_start=False;self.fail_readback=False
        self.expected=worker.payload({'model':{'repository':'Qwen/Qwen2.5-7B-Instruct','revision':'a'*40},
            'image':'ghcr.io/aizen-hado/policypilot-gpu@sha256:'+'b'*64,'gpu':{'pool':'AMPERE_24'}},
            'c'*32,'registry-test','endpoint-test')
        self.actual=deepcopy(self.expected);self.actual['id']='endpoint-test'
        self.state={'endpoint_id':'endpoint-test'}
        self.app={'configured':True,'operator':True,'state':'off','enabled':False,'can_start':False,
                  'model':'Qwen/Qwen2.5-7B-Instruct','demo_compute_reserved_usd':.31875,
                  'compute_allowance_usd':.70,'demo_inference_allowance_usd':1,
                  'started_at':'2026-11-14T18:52:02+00:00'}
        self.billed='.5064673366287025'

    def clock(self):return self.seconds
    def sleep(self,seconds):self.seconds+=seconds

    def call(self,path,method='GET',body=None):
        self.calls.append((path,method,body))
        if path=='/api/model/status':return self.app
        if path.startswith('/v2/billing'):return {'metadata':{'totals':{'totalAmount':self.billed}}}
        if path.startswith('/v2/catalog/'):
            return {'gpus':[{'manufacturer':'NVIDIA','memory':24,'pool':'AMPERE_24','price':{'serverless':.75},'availability':'HIGH','name':'synthetic'}]}
        if path.endswith('/workers'):
            return {'workers':[{}] if self.started else [],'summary':{k:int(self.started and k in ('running','total')) for k in ('running','idle','initializing','throttled','unhealthy','total')}}
        self.assertEqual(path,'/v2/serverless/endpoint-test')
        if method=='PATCH':
            self.assertEqual(body['workers']['min'],body['workers']['max'])
            self.started=body['workers']['min']==1
            self.actual['workers']['min']=int(self.started);self.actual['workers']['max']=int(self.started)
            if self.started and self.fail_start:raise worker.SetupError('private-secret')
        elif self.started and self.fail_readback:raise worker.SetupError('private-secret')
        return deepcopy(self.actual)

    def run_check(self):
        report={'reservation_committed':True,'provider_shutdown_verified':False,'requests_submitted':0}
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'report.json'
            with redirect_stdout(io.StringIO()):
                result=worker.run_worker(self,self.state,self.expected,report,path,self.clock,self.sleep,Timer)
            self.assertEqual(json.loads(path.read_text()),result)
            self.assertNotIn('private-secret',path.read_text())
        return result

    def test_start_once_wait_deadline_and_verify_shutdown_without_job(self):
        report=self.run_check()
        self.assertTrue(report['provider_shutdown_verified'])
        self.assertTrue(report['worker_allocation_observed'])
        self.assertEqual(self.seconds,360)
        self.assertEqual(sum(method=='PATCH' and body['workers']['min']==1 for _,method,body in self.calls),1)
        self.assertTrue(all(method in ('GET','PATCH') for _,method,_ in self.calls))

    def test_uncertain_start_or_read_failure_still_shuts_down_and_never_repeats(self):
        for mode in ('fail_start','fail_readback'):
            self.setUp();setattr(self,mode,True)
            report=self.run_check()
            self.assertTrue(report['start_or_poll_failed'])
            self.assertTrue(report['provider_shutdown_verified'])
            self.assertEqual(sum(method=='PATCH' and body['workers']['min']==1 for _,method,body in self.calls),1)

    def test_no_reservation_blocks_compute(self):
        with self.assertRaises(worker.SetupError):worker.run_worker(self,self.state,self.expected,{},Path('/unused'))
        self.assertEqual(self.calls,[])

    def test_shutdown_recheck_waits_for_app_off_without_compute_writes(self):
        statuses=[dict(self.app,state='stopping',demo_compute_reserved_usd=.4625),
                  dict(self.app,state='off',can_start=True,demo_compute_reserved_usd=.4625)]
        web=Mock();web.call.side_effect=statuses
        report={'endpoint_id':'endpoint-test','start_attempted':True,'reservation_committed':True,
                'total_compute_reserved_usd':'.46250','app_after':{'state':'stopping'}}
        with tempfile.TemporaryDirectory() as folder:
            ok=worker.verify_stopped(self,web,self.state,self.expected,report,Path(folder)/'report.json',self.clock,self.sleep)
        self.assertTrue(ok)
        self.assertEqual(report['app_after_first_check'],{'state':'stopping'})
        self.assertTrue(report['app_after']['can_start'])
        self.assertTrue(all(method=='GET' for _,method,_ in self.calls))
        self.assertTrue(all(call.args==('/api/model/status',) and not call.kwargs for call in web.call.call_args_list))

    def test_shutdown_recheck_never_claims_off_on_ledger_mismatch(self):
        web=Mock();web.call.return_value=dict(self.app,state='off',demo_compute_reserved_usd=.31875)
        report={'endpoint_id':'endpoint-test','start_attempted':True,'reservation_committed':True,
                'total_compute_reserved_usd':'.46250'}
        with tempfile.TemporaryDirectory() as folder:
            ok=worker.verify_stopped(self,web,self.state,self.expected,report,Path(folder)/'report.json',self.clock,self.sleep)
        self.assertFalse(ok)
        self.assertTrue(all(method=='GET' for _,method,_ in self.calls))

    def test_nonzero_workers_after_disable_never_claim_shutdown(self):
        original=self.call
        def call(path,method='GET',body=None):
            result=original(path,method,body)
            if path.endswith('/workers') and not self.started:
                result['workers']=[{}];result['summary']['running']=1;result['summary']['total']=1
            return result
        self.call=call
        report=self.run_check()
        self.assertFalse(report['provider_shutdown_verified'])
        self.assertGreaterEqual(self.seconds,540)

    def test_independent_watchdog_only_requests_zero_workers(self):
        timers=[]
        class CapturedTimer(Timer):
            def __init__(self,*args):super().__init__(*args);timers.append(self)
        report={'reservation_committed':True,'provider_shutdown_verified':False}
        with tempfile.TemporaryDirectory() as folder,redirect_stdout(io.StringIO()):
            worker.run_worker(self,self.state,self.expected,report,Path(folder)/'report.json',
                              self.clock,self.sleep,CapturedTimer)
            self.calls.clear();timers[0].callback()
        self.assertEqual(self.calls,[('/v2/serverless/endpoint-test','PATCH',{'workers':{'min':0,'max':0,'idleTimeout':300}})])

    def test_preflight_preserves_budget_and_rejects_enabled_app_or_high_spend(self):
        _,billed,rate=worker.preflight(self,self,self.state,self.expected)
        self.assertEqual(rate,Decimal('.75'));self.assertEqual(billed,Decimal(self.billed))
        for field in ('enabled','billing'):
            self.setUp()
            if field=='enabled':self.app['enabled']=True
            else:self.billed='1.5'
            with self.assertRaises(worker.SetupError):worker.preflight(self,self,self.state,self.expected)
            self.assertTrue(all(method=='GET' for _,method,_ in self.calls))

    def test_budget_approval_may_remain_enabled_without_relaxing_ledger_checks(self):
        self.app['can_start']=True
        app,_,_=worker.preflight(self,self,self.state,self.expected)
        self.assertTrue(app['can_start'])
        self.assertTrue(all(method=='GET' for _,method,_ in self.calls))
        self.app['demo_compute_reserved_usd']=0
        with self.assertRaises(worker.SetupError):worker.preflight(self,self,self.state,self.expected)

    def connection(self,active=False,wrong_session=False):
        conn=Mock();self.sql=[]
        def execute(sql,params=None):
            self.sql.append((sql,params));result=Mock();result.fetchone.return_value=None
            if 'pg_try_advisory' in sql:result.fetchone.return_value={'acquired':True}
            elif 'FROM model_control' in sql:
                result.fetchone.return_value={'enabled':False,'phase':'off','started_at':datetime(2026,11,14 if not wrong_session else 13,18,52,2,tzinfo=timezone.utc)}
            elif 'SELECT * FROM inference_allowance' in sql:
                result.fetchone.return_value={'compute_reserved_usd':Decimal('.31875'),'approved_total_usd':1,'compute_reservation_limit_usd':Decimal('.70')}
            elif 'FROM model_jobs' in sql:result.fetchone.return_value={'active':True} if active else None
            elif sql.startswith('UPDATE inference_allowance'):result.fetchone.return_value={'compute_reserved_usd':Decimal('.4625')}
            return result
        conn.execute.side_effect=execute
        return conn

    def test_reservation_updates_existing_ledger_once_without_refund(self):
        result=worker.reserve(self.connection(),self.app,Decimal('.14375'),'operation')
        self.assertEqual(result,Decimal('.4625'))
        writes=[sql for sql,_ in self.sql if not sql.startswith('SELECT')]
        self.assertEqual(len(writes),2)
        self.assertTrue(writes[0].startswith('UPDATE inference_allowance'))

    def test_outstanding_job_or_wrong_database_session_blocks_reservation(self):
        for active,wrong in ((True,False),(False,True)):
            with self.assertRaises(worker.SetupError):
                worker.reserve(self.connection(active,wrong),self.app,Decimal('.14375'),'operation')
            self.assertTrue(all(sql.startswith('SELECT') for sql,_ in self.sql))
