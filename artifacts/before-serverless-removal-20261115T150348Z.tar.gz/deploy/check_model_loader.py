"""Offline image diagnostics: tiny synthetic CPU weights and native library loading.

Run in the GPU image without network, GPU flags, env files or credential mounts.
No Hugging Face model is downloaded and no cloud resource is accessed.
"""
import ctypes
from importlib.metadata import version
from pathlib import Path
import re
import tempfile
import traceback


def main():
    import torch
    torch.set_num_threads(1)
    for name in ('torch','transformers','accelerate','bitsandbytes','safetensors'):
        print(name+'='+version(name),flush=True)
    print('PyTorch build CUDA:',torch.version.cuda,flush=True)
    print('CUDA detected locally:',torch.cuda.is_available(),flush=True)
    # The package's CPU-library warning is expected without an attached GPU.
    import bitsandbytes
    from transformers import AutoModelForCausalLM,Qwen2Config,Qwen2ForCausalLM
    cpu_passed=False
    try:
        config=Qwen2Config(vocab_size=32,hidden_size=16,intermediate_size=32,
            num_hidden_layers=1,num_attention_heads=2,num_key_value_heads=2,
            max_position_embeddings=64,bos_token_id=1,eos_token_id=2,pad_token_id=0)
        with tempfile.TemporaryDirectory(prefix='synthetic-qwen-check-') as folder:
            model=Qwen2ForCausalLM(config)
            model.save_pretrained(folder,safe_serialization=True)
            del model
            loaded=AutoModelForCausalLM.from_pretrained(folder,local_files_only=True,
                trust_remote_code=False,use_safetensors=True,device_map={'':'cpu'},torch_dtype=torch.float16)
            assert all(parameter.device.type=='cpu' for parameter in loaded.parameters())
            print('PASS: tiny synthetic Qwen2 checkpoint saved and reloaded on CPU; '
                  +str(sum(parameter.numel() for parameter in loaded.parameters()))+' parameters',flush=True)
            cpu_passed=True
    except Exception:
        print('FAIL: tiny CPU checkpoint load. Isolated diagnostic traceback follows:',flush=True)
        traceback.print_exc()
    cuda=str(torch.version.cuda or '')
    if re.fullmatch(r'\d+\.\d+',cuda):
        name='libbitsandbytes_cuda'+cuda.replace('.','')+'.so'
        binary=Path(bitsandbytes.__file__).parent/name
        print('CUDA binary present:',binary.is_file(),name,flush=True)
        if binary.is_file():
            try:
                ctypes.CDLL(str(binary))
                print('PASS: CUDA native library opens; GPU kernels remain untested',flush=True)
            except OSError:
                print('CHECK: CUDA library could not open on this CPU host. '
                      'Missing driver libraries here do not establish a Runpod fault.',flush=True)
                traceback.print_exc()
    else:
        print('CHECK: this PyTorch build has no recognized CUDA version',flush=True)
    print('No real model, GPU quantization or generation was tested.',flush=True)
    if not cpu_passed:raise SystemExit(1)


if __name__=='__main__':main()
