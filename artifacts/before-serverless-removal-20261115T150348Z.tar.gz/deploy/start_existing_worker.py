"""One supervised, reserved six-minute worker start; no inference or training jobs."""
import argparse
from datetime import datetime,timezone
from decimal import Decimal
import fcntl
import getpass
import json
from pathlib import Path
import sys
import threading
import time
from urllib.parse import urlsplit
import uuid

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'deploy'))
from create_runpod_disabled import API,SetupError,save,resource_id,payload,verify_disabled,verify_no_workers,billed_amount,account_for_history
from prepare_runpod import credentials,PreparationError,candidates
from rehearse_model import Web,number,safe_app_state,COOKIE
from pilot.model_service import ACTIVE

DEADLINE=360


def preflight(api,web,state,expected):
    route='/v2/serverless/'+resource_id(state['endpoint_id'])
    actual=api.call(route)
    if actual.get('id')!=state['endpoint_id']:raise SetupError('Endpoint identity mismatch')
    verify_disabled(actual,expected);verify_no_workers(api.call(route+'/workers'))
    billed=billed_amount(api.call('/v2/billing?lastN=30&bucketSize=day'))
    if not account_for_history(billed,state):raise SetupError('Reported account spend leaves insufficient budget headroom')
    rows=[row for row in candidates(api.call('/v2/catalog/gpus?include=AVAILABILITY&product=SERVERLESS&cloud=SECURE&count=1&minCudaVersion=12.8')) if row['pool']=='AMPERE_24']
    if not rows or not any(row['stock'] in ('LOW','MEDIUM','HIGH') for row in rows):
        raise SetupError('Selected GPU stock unavailable')
    rates=[number(row['serverless_usd_per_hour']) for row in rows];rate=max(rates)
    if rate<=0 or rate>Decimal('.75'):raise SetupError('GPU rate not confirmed at or below $0.75/hour')
    app=web.call('/api/model/status')
    if not (app.get('configured') is True and app.get('operator') is True
            and app.get('state')=='off' and app.get('enabled') is False
            and type(app.get('can_start')) is bool):
        raise SetupError('App must be configured, off and operator-accessible before starting a worker')
    if (app.get('model')!=expected['env']['MODEL_REPOSITORY']
            or number(app.get('demo_compute_reserved_usd'))!=Decimal('.31875')
            or number(app.get('compute_allowance_usd'))!=Decimal('.70')
            or number(app.get('demo_inference_allowance_usd'))!=Decimal('1')):
        raise SetupError('Live model identity or preserved $0.31875/$0.70/$1 allowance mismatch')
    return app,billed,rate


def reserve(conn,app,amount,operation):
    if conn.execute('SELECT pg_try_advisory_xact_lock(519826) AS acquired').fetchone()['acquired'] is not True:
        raise SetupError('App operation active; no reservation or compute start')
    control=conn.execute('SELECT enabled,phase,started_at FROM model_control WHERE id=1 FOR UPDATE').fetchone()
    ledger=conn.execute('SELECT * FROM inference_allowance WHERE id=1 FOR UPDATE').fetchone()
    if not control or control['enabled'] is not False or control['phase']!='off':
        raise SetupError('Database app state must be off')
    try:
        live_time=datetime.fromisoformat(app['started_at'].replace('Z','+00:00'))
        db_time=control['started_at']
        if not db_time or not db_time.tzinfo or abs((db_time-live_time).total_seconds())>1:raise ValueError()
    except (ValueError,TypeError,KeyError,AttributeError):
        raise SetupError('Database session does not match the live app') from None
    if conn.execute('SELECT 1 FROM model_jobs WHERE state=ANY(%s)',(list(ACTIVE),)).fetchone():
        raise SetupError('Outstanding model job blocks a manual worker start')
    previous=number(app['demo_compute_reserved_usd'])
    if (not ledger or number(ledger['compute_reserved_usd'])!=previous
            or number(ledger['approved_total_usd'])!=Decimal('1')
            or number(ledger['compute_reservation_limit_usd'])!=Decimal('.70')
            or previous+amount>Decimal('.70')):
        raise SetupError('Reservation ledger changed or cannot cover this worker start')
    row=conn.execute('UPDATE inference_allowance SET compute_reserved_usd=compute_reserved_usd+%s '
                     'WHERE id=1 AND compute_reserved_usd=%s AND compute_reserved_usd+%s<=compute_reservation_limit_usd '
                     'RETURNING compute_reserved_usd',(amount,previous,amount)).fetchone()
    if not row or number(row['compute_reserved_usd'])!=previous+amount:
        raise SetupError('Reservation update not confirmed; transaction must roll back')
    conn.execute('INSERT INTO events(case_id,action,actor) VALUES(NULL,%s,%s)',
                 ('manual_worker_reservation:'+operation,'supervised-worker-start'))
    return previous+amount


def run_worker(api,state,expected,report,destination,clock=time.monotonic,sleep=time.sleep,timer_factory=threading.Timer):
    if report.get('reservation_committed') is not True:raise SetupError('Committed reservation required before compute')
    route='/v2/serverless/'+resource_id(state['endpoint_id'])
    start=clock()
    def disable():api.call(route,'PATCH',{'workers':{'min':0,'max':0,'idleTimeout':300}})
    def watchdog():
        try:disable()
        except Exception:pass
    timer=timer_factory(DEADLINE,watchdog);timer.daemon=True
    try:
        report['start_attempted']=True;save(destination,report)
        timer.start()
        api.call(route,'PATCH',{'workers':{'min':1,'max':1,'idleTimeout':300}})
        workers=api.call(route).get('workers',{})
        if workers.get('min')!=1 or workers.get('max')!=1:
            raise SetupError('One-worker read-back mismatch')
        print('PASS: min=max=1 read back. Waiting for worker allocation; no model job submitted.',flush=True)
        while clock()-start<DEADLINE:
            data=api.call(route+'/workers')
            summary=data.get('summary',{})
            safe={k:summary[k] for k in ('running','idle','initializing','throttled','unhealthy','total')
                  if type(summary.get(k)) is int and summary[k]>=0}
            report['last_worker_summary']=safe
            if safe.get('total',0)>0:report['worker_allocation_observed']=True
            save(destination,report)
            print('Worker counters:',json.dumps(safe),flush=True)
            sleep(min(10,max(0,DEADLINE-(clock()-start))))
    except (Exception,KeyboardInterrupt):
        report['start_or_poll_failed']=True
        print('CHECK: start interrupted or provider response unconfirmed. Requesting shutdown.',flush=True)
    finally:
        print('Restoring min=max=0 and verifying empty allocated workers…',flush=True)
        for _ in range(3):
            try:disable();break
            except Exception:sleep(2)
        end=clock()+180
        while clock()<end:
            try:
                verify_disabled(api.call(route),expected)
                verify_no_workers(api.call(route+'/workers'))
                report['provider_shutdown_verified']=True
                break
            except Exception:sleep(5)
        timer.cancel()
        if timer.is_alive():timer.join(timeout=35)
        report['elapsed_seconds']=round(clock()-start,2)
        try:report['account_billing_after_usd']=str(billed_amount(api.call('/v2/billing?lastN=30&bucketSize=day')))
        except Exception:report['billing_after_unverified']=True
        report['billing_may_lag']=True
        save(destination,report)
        if json.loads(destination.read_text())!=report:raise SetupError('Worker report read-back failed')
    return report


def verify_stopped(api,web,state,expected,report,destination,clock=time.monotonic,sleep=time.sleep):
    """Recheck shutdown without a provider write, DB reservation or Start call."""
    if (report.get('endpoint_id')!=state['endpoint_id'] or report.get('start_attempted') is not True
            or report.get('reservation_committed') is not True):
        raise SetupError('Expected the saved existing-worker start report')
    route='/v2/serverless/'+resource_id(state['endpoint_id'])
    verify_disabled(api.call(route),expected)
    verify_no_workers(api.call(route+'/workers'))
    report.setdefault('app_after_first_check',report.get('app_after',{}))
    report['shutdown_rechecked_at']=datetime.now(timezone.utc).isoformat()
    report['provider_shutdown_recheck_verified']=True
    end=clock()+90
    while True:
        after=web.call('/api/model/status')
        report['app_after']=safe_app_state(after)
        workers=after.get('workers',{})
        report['last_app_worker_counters']={k:workers[k] for k in
            ('idle','initializing','ready','running','throttled','unhealthy')
            if isinstance(workers,dict) and type(workers.get(k)) is int and workers[k]>=0}
        report['app_off_verified']=(after.get('state')=='off' and after.get('enabled') is False
             and number(after.get('demo_compute_reserved_usd'))==number(report['total_compute_reserved_usd']))
        save(destination,report)
        if report['app_off_verified'] or clock()>=end:break
        if after.get('enabled') is not False or after.get('state')!='stopping':break
        sleep(min(5,max(0,end-clock())))
    if json.loads(destination.read_text())!=report:raise SetupError('Shutdown recheck report read-back failed')
    return report['app_off_verified']


def recheck_main(origin):
    state=json.loads((ROOT/'artifacts/runpod-disabled-setup.json').read_text())
    destination=ROOT/'artifacts/runpod-existing-worker-start.json'
    report=json.loads(destination.read_text())
    private=credentials(ROOT/'deploy/cloud.env')
    plan=json.loads((ROOT/'artifacts/runpod-connection-plan.json').read_text())
    expected=payload(plan,private['R2_ACCOUNT_ID'],state['registry_id'],state['endpoint_name'])
    web=Web(origin)
    username=input('Pilot username [reviewer]: ').strip() or 'reviewer'
    password=getpass.getpass('Pilot password (hidden): ')
    try:
        web.login(username,password);password=None
        ok=verify_stopped(API(private['RUNPOD_API_KEY']),web,state,expected,report,destination)
        print('Provider zero workers rechecked: True | App off:',ok)
        print('Reservation retained: $'+report['total_compute_reserved_usd'])
        if not ok:print('App snapshot:',json.dumps(report['app_after']),'Worker counters:',json.dumps(report['last_app_worker_counters']))
        print('Saved and verified:',destination)
        print('No worker started, model job submitted or budget reservation added.')
    finally:
        if any(cookie.name==COOKIE for cookie in web.cookies):
            try:web.call('/api/auth/logout','POST')
            except Exception:pass


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('origin')
    parser.add_argument('--start-worker',action='store_true')
    parser.add_argument('--verify-stopped',action='store_true',help='Recheck the saved run shutdown without starting or reserving compute')
    args=parser.parse_args()
    if args.verify_stopped:
        if args.start_worker:raise SetupError('Select either start or shutdown recheck')
        recheck_main(args.origin)
        return
    if not args.start_worker:
        print('Preview: one min=max=1 worker, six-minute shutdown timer, no inference. Add --start-worker to execute.')
        return
    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError:raise SetupError('Run inside the existing policypilot-api:demo Docker image; psycopg is required') from None
    if not sys.stdin.isatty():raise SetupError('Interactive terminal required for hidden credentials')
    destination=ROOT/'artifacts/runpod-existing-worker-start.json'
    with (ROOT/'artifacts/runpod-disabled-setup.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SetupError('Another local setup operation is active') from None
        if destination.exists():raise SetupError('Worker start already recorded; preserve its report before further paid work')
        journal=ROOT/'artifacts/runpod-disabled-setup.json';state=json.loads(journal.read_text())
        if state.get('phase')!='disabled_verified':raise SetupError('Verified existing endpoint required')
        private=credentials(ROOT/'deploy/cloud.env')
        plan=json.loads((ROOT/'artifacts/runpod-connection-plan.json').read_text())
        expected=payload(plan,private['R2_ACCOUNT_ID'],state['registry_id'],state['endpoint_name'])
        api=API(private['RUNPOD_API_KEY']);web=Web(args.origin)
        username=input('Pilot username [reviewer]: ').strip() or 'reviewer'
        password=getpass.getpass('Pilot password (hidden): ')
        logged_in=False
        try:
            web.login(username,password);password=None
            logged_in=True
            app,billed,rate=preflight(api,web,state,expected);save(journal,state)
            amount=rate*Decimal(DEADLINE+300+30)/Decimal(3600)
            operation=str(uuid.uuid4())
            report={'endpoint_id':state['endpoint_id'],'recorded_at':datetime.now(timezone.utc).isoformat(),
                    'operation':operation,'start_attempted':False,'reservation_committed':False,
                    'reserved_compute_usd':str(amount),'prior_compute_reserved_usd':str(number(app['demo_compute_reserved_usd'])),
                    'account_billing_before_usd':str(billed),'rate_usd_per_hour':str(rate),
                    'deadline_seconds':DEADLINE,'requests_submitted':0,'generation_verified':False,
                    'worker_allocation_observed':False,'provider_shutdown_verified':False,'financial_hard_cap':False}
            print(f'PASS: account reported ${billed}; rate ${rate}/hour. Six minutes estimates ${rate/10} before overhead.',flush=True)
            print(f'Reserving ${amount} in the app ledger, including idle/termination margin. Keep this terminal open.',flush=True)
            dsn=getpass.getpass('Render database External Database URL (hidden): ').strip()
            parsed=urlsplit(dsn)
            if parsed.scheme not in ('postgres','postgresql') or not parsed.hostname or not parsed.hostname.endswith('.render.com'):
                raise SetupError('Expected the external Render PostgreSQL URL')
            report['reservation_commit_outcome']='pending';save(destination,report)
            with psycopg.connect(dsn,row_factory=dict_row,connect_timeout=10,sslmode='require',
                                  options='-c statement_timeout=15000') as conn:
                with conn.transaction():
                    total=reserve(conn,app,amount,operation)
            report.update(reservation_committed=True,reservation_commit_outcome='committed',total_compute_reserved_usd=str(total))
            save(destination,report)
            run_worker(api,state,expected,report,destination)
            verify_stopped(api,web,state,expected,report,destination)
            print('Saved and verified:',destination)
            print('Worker allocation observed:',report['worker_allocation_observed'],
                  '| Provider stopped:',report['provider_shutdown_verified'],'| App off:',report['app_off_verified'])
            if not report['provider_shutdown_verified']:raise SetupError('Shutdown unconfirmed: set min=max=0 in Runpod and inspect workers now')
            if not report['app_off_verified']:raise SetupError('Provider stopped, but live app state or reservation remains unverified')
            print('PASS: shutdown verified. No inference submitted; model loading, CUDA and RAM remain unverified.')
        finally:
            if logged_in or any(cookie.name==COOKIE for cookie in web.cookies):
                try:web.call('/api/auth/logout','POST')
                except Exception:pass


if __name__=='__main__':
    try:main()
    except (SetupError,PreparationError) as exc:raise SystemExit('CHECK: '+str(exc)) from None
    except (Exception,KeyboardInterrupt):raise SystemExit('CHECK: worker start failed; inspect artifacts/runpod-existing-worker-start.json and zero-worker settings. Credentials/details withheld.') from None
