"""Apply the user's one additional dollar once, preserving every existing hold."""
import argparse
from datetime import datetime,timedelta,timezone
from decimal import Decimal
import fcntl
import getpass
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'deploy'))
from create_runpod_disabled import API,SetupError,save,payload,billed_amount,account_for_history,EXTRA_DOLLAR_AUTHORIZATION
from prepare_runpod import credentials,PreparationError
from rehearse_model import Web,number,safe_app_state,compiler_ready,COMPILER_FIXED_IMAGE,BILLING
from reconcile_warmup import timestamp,provider_idle
from inspect_runpod_attempt import runtime_read


def extension_action(endpoint):return 'one_extra_dollar_compiler_fix:'+endpoint


def extend(conn,app,endpoint,reserved,prior_audit,attempt,idle_check,apply=False):
    if conn.execute('SELECT pg_try_advisory_xact_lock(519826) AS acquired').fetchone()['acquired'] is not True:
        raise SetupError('App operation is active; no budget change attempted')
    control=conn.execute('SELECT * FROM model_control WHERE id=1 FOR UPDATE').fetchone()
    ledger=conn.execute('SELECT * FROM inference_allowance WHERE id=1 FOR UPDATE').fetchone()
    if not (app.get('configured') is True and app.get('operator') is True
            and app.get('enabled') is False and app.get('state')=='off'
            and number(app.get('compute_allowance_usd'))==Decimal('1.70')
            and control and control.get('enabled') is False and control.get('phase')=='off'
            and ledger and number(app.get('demo_compute_reserved_usd'))==number(ledger['compute_reserved_usd'])
            and number(app.get('demo_inference_allowance_usd'))==number(ledger['approved_total_usd'])
            and abs((timestamp(app.get('started_at'))-timestamp(control.get('started_at'))).total_seconds())<1):
        raise SetupError('Live app/database must agree and be off; deploy RUNPOD_SESSION_COMPUTE_LIMIT_USD=1.70 first')
    if conn.execute('SELECT 1 FROM model_jobs WHERE state=ANY(%s) LIMIT 1',
            (['pending','submitted','IN_QUEUE','IN_PROGRESS','uncertain'],)).fetchone():
        raise SetupError('Outstanding jobs block the allowance update')
    if not conn.execute('SELECT id FROM events WHERE action=%s LIMIT 1',(prior_audit,)).fetchone():
        raise SetupError('Prior reservation audit missing from this database')
    action=extension_action(endpoint)
    applied=conn.execute('SELECT id FROM events WHERE action=%s LIMIT 1',(action,)).fetchone()
    if applied:
        if (number(ledger['approved_total_usd'])!=2 or number(ledger['compute_reservation_limit_usd'])!=Decimal('1.70')
                or not reserved<=number(ledger['compute_reserved_usd'])<=Decimal('1.70')):
            raise SetupError('Previously applied allowance disagrees with its audit')
        idle_check()
        return {'already_applied':True,'reserved_compute_usd':str(ledger['compute_reserved_usd']),
                'audit_action':action,'database_update_prepared':False}
    if (reserved!=Decimal('.678335') or number(ledger['compute_reserved_usd'])!=reserved
            or number(ledger['approved_total_usd'])!=1
            or number(ledger['compute_reservation_limit_usd'])!=Decimal('.70')):
        raise SetupError('Expected the original $1/$0.70 allowance and all $0.678335 retained holds')
    began=timestamp(attempt['recorded_at'])
    jobs=conn.execute("SELECT id,provider_id,kind,state,case_id,generation,reserved_compute_usd, "
        "payload->>'request_id' AS request_id,payload->>'task' AS task, "
        "payload->>'artifact_revision' AS artifact_revision FROM model_jobs "
        "WHERE created_at>=%s AND created_at<=%s ORDER BY created_at FOR UPDATE",
        (began-timedelta(seconds=5),began+timedelta(seconds=120))).fetchall()
    if len(jobs)!=1:raise SetupError('The last compiler-failure job was not uniquely matched')
    job=jobs[0]
    if (job['kind']!='warmup' or job['state']!='FAILED' or not job['provider_id'] or job['case_id'] is not None
            or job['task']!='warmup' or job['request_id']!=str(job['id'])
            or job['artifact_revision']!=attempt['model_revision']
            or number(job['reserved_compute_usd'])!=Decimal('.11875')
            or type(job['generation']) is not int or job['generation']>=control['generation']):
        raise SetupError('The closed compiler-failure job identity or reservation changed')
    idle_check()
    result={'already_applied':False,'reserved_compute_usd':str(reserved),
            'audit_action':action,'database_update_prepared':False}
    if apply:
        updated=conn.execute('UPDATE inference_allowance SET approved_total_usd=2.00, '
            'compute_reservation_limit_usd=1.70 WHERE id=1 AND approved_total_usd=1.00 '
            'AND compute_reservation_limit_usd=0.70 AND compute_reserved_usd=%s RETURNING id',(reserved,)).fetchone()
        if not updated:raise SetupError('Allowance update did not match; transaction must roll back')
        conn.execute('INSERT INTO events(case_id,action,actor) VALUES(NULL,%s,%s)',
                     (action,'operator-explicit-additional-dollar'))
        check=conn.execute('SELECT * FROM inference_allowance WHERE id=1').fetchone()
        if (number(check['compute_reserved_usd'])!=reserved or number(check['approved_total_usd'])!=2
                or number(check['compute_reservation_limit_usd'])!=Decimal('1.70')):
            raise SetupError('Allowance read-back mismatch; transaction must roll back')
        result['database_update_prepared']=True
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('origin');parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError:raise SetupError('Run in the existing API Docker image for psycopg') from None
    if not sys.stdin.isatty():raise SetupError('Interactive hidden credential prompts required')
    state_path=ROOT/'artifacts/runpod-disabled-setup.json'
    state=json.loads(state_path.read_text())
    plan=json.loads((ROOT/'artifacts/runpod-connection-plan.json').read_text())
    private=credentials(ROOT/'deploy/cloud.env')
    expected=payload(plan,private['R2_ACCOUNT_ID'],state['registry_id'],state['endpoint_name'])
    reserved,prior_audit=compiler_ready(ROOT,state,expected)
    attempt=json.loads((ROOT/'artifacts/runpod-warmup-loader-diagnostic.json').read_text())
    report={'authorization':EXTRA_DOLLAR_AUTHORIZATION,'endpoint_id':state['endpoint_id'],
            'recorded_at':datetime.now(timezone.utc).isoformat(),'additional_allowance_usd':'1.00',
            'planning_ceiling_usd':'2.99','inference_allowance_usd':'2.00','compute_limit_usd':'1.70',
            'overhead_provision_usd':'0.30','reserved_compute_usd':str(reserved),
            'compiler_image':COMPILER_FIXED_IMAGE,'provider_resources_changed':False,'jobs_submitted':0,
            'holds_released_usd':'0','database_committed':False,'result':'CHECK','apply_requested':args.apply}
    destination=ROOT/'artifacts/runpod-extra-dollar-authorization.json'
    web=Web(args.origin)
    try:
        username=input('Pilot username [reviewer]: ').strip() or 'reviewer'
        password=getpass.getpass('Pilot password (hidden): ');web.login(username,password);password=None
        app=web.call('/api/model/status')
        if number(app.get('compute_allowance_usd'))!=Decimal('1.70'):
            raise SetupError('Set RUNPOD_SESSION_COMPUTE_LIMIT_USD=1.70 in Render and save/deploy first')
        if app.get('model')!=expected['env']['MODEL_REPOSITORY']:raise SetupError('App model identity mismatch')
        inference=getpass.getpass('RUNPOD_INFERENCE_KEY from Render (hidden): ').strip()
        if not inference or inference==private['RUNPOD_API_KEY']:raise SetupError('Dedicated inference key required')
        dsn=getpass.getpass('Render database External Database URL (hidden): ').strip()
        parsed=urlsplit(dsn)
        if parsed.scheme not in ('postgres','postgresql') or not (parsed.hostname or '').endswith('.render.com'):
            raise SetupError('Use the Render external database URL')
        api=API(private['RUNPOD_API_KEY'])
        def idle():provider_idle(api,lambda:runtime_read(state['endpoint_id'],inference,'health'),state['endpoint_id'],expected)
        with (ROOT/'artifacts/runpod-disabled-setup.lock').open('a') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:raise SetupError('Another local operation is active') from None
            planned=dict(state,budget_authorization=EXTRA_DOLLAR_AUTHORIZATION)
            billed=billed_amount(api.call(BILLING))
            if not account_for_history(billed,planned):raise SetupError('Reported spend cannot cover $2 inference within $2.99')
            report['account_30day_reported_usd']=str(billed);save(destination,report)
            with psycopg.connect(dsn,row_factory=dict_row,connect_timeout=10,sslmode='require',
                    options='-c statement_timeout=15000 -c idle_in_transaction_session_timeout=180000') as conn:
                with conn.transaction():
                    report.update(extend(conn,app,state['endpoint_id'],reserved,prior_audit,attempt,idle,args.apply))
                    save(destination,report)
            report['database_committed']=args.apply or report.get('already_applied') is True
            save(destination,report)
            if report['database_committed']:save(state_path,planned)
            idle();after=web.call('/api/model/status');report['app_after']=safe_app_state(after)
            wanted_total=Decimal(2) if report['database_committed'] else number(app['demo_inference_allowance_usd'])
            if (after.get('state')!='off' or after.get('enabled') is not False
                    or number(after.get('demo_compute_reserved_usd'))!=number(report['reserved_compute_usd'])
                    or number(after.get('demo_inference_allowance_usd'))!=wanted_total
                    or number(after.get('compute_allowance_usd'))!=Decimal('1.70')):
                raise SetupError('Live allowance read-back mismatch; do not start a GPU')
            if report['database_committed'] and json.loads(state_path.read_text())!=planned:
                raise SetupError('Local budget receipt read-back mismatch')
            report['result']='PASS';save(destination,report)
            if json.loads(destination.read_text())!=report:raise SetupError('Authorization report read-back mismatch')
            print('PASS: allowance verified; previous reservations retained at $'+report['reserved_compute_usd'])
            print('Approved inference $2.00 / compute cap $1.70 / total planning ceiling $2.99.' if report['database_committed'] else 'Preview only; add --apply to commit the one-dollar increase.')
            print('No provider change or GPU job. Repeating this helper cannot add another dollar.')
            print('Saved and verified:',destination)
    except Exception as exc:
        save(destination,report)
        if isinstance(exc,SetupError):raise
        raise SetupError('Allowance database/network check failed; details withheld. Reconcile the saved report before paid work.') from None
    finally:
        try:web.call('/api/auth/logout','POST')
        except Exception:pass


if __name__=='__main__':
    try:main()
    except (SetupError,PreparationError) as exc:raise SystemExit('CHECK: '+str(exc)) from None
    except (OSError,ValueError,KeyError,TypeError,EOFError,KeyboardInterrupt):
        raise SystemExit('CHECK: allowance operation interrupted or local evidence invalid; details withheld. No paid retry.') from None
