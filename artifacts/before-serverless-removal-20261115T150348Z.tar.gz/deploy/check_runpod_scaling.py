"""Compare control APIs with an optional bounded scaling test; never submits jobs."""
import argparse
from datetime import datetime,timezone
from decimal import Decimal
import fcntl
import getpass
import json
from pathlib import Path
import sys
import threading
import time
import urllib.error
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'deploy'))
from create_runpod_disabled import API,SetupError,save,resource_id,payload,verify_disabled,verify_no_workers,billed_amount,account_for_history
from prepare_runpod import credentials,PreparationError,NoRedirect,candidates


class Legacy:
    def __init__(self,key,endpoint):
        self.key=key
        self.url='https://rest.runpod.io/v1/endpoints/'+resource_id(endpoint)
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())

    def read(self):return self.call()
    def disable(self):return self.call('PATCH',{'workersMin':0,'workersMax':0,'idleTimeout':300})

    def call(self,method='GET',body=None):
        request=urllib.request.Request(self.url,method=method,
            data=None if body is None else json.dumps(body).encode(),
            headers={'Authorization':'Bearer '+self.key,'Content-Type':'application/json','Accept':'application/json'})
        try:
            with self.opener.open(request,timeout=20) as response:
                if response.code==204:return {}
                raw=response.read(4*1024*1024+1)
                if len(raw)>4*1024*1024:raise ValueError()
                value=json.loads(raw)
                if not isinstance(value,dict):raise ValueError()
                return value
        except urllib.error.HTTPError as exc:
            code=exc.code;exc.close()
            raise SetupError(f'Legacy control {method}: HTTP {code}; body withheld') from None
        except (OSError,ValueError):
            raise SetupError('Legacy control unavailable; details withheld') from None


def limits(value,endpoint,legacy=False):
    if value.get('id')!=endpoint:raise SetupError('Control API endpoint identity mismatch')
    source=value if legacy else value.get('workers',{})
    keys=('workersMin','workersMax') if legacy else ('min','max')
    result={name:source.get(key) for name,key in zip(('min','max'),keys)}
    if any(type(v) is not int or v<0 for v in result.values()):
        raise SetupError('Control API omitted numeric worker limits')
    return result


def verify(api,legacy,state,expected,destination,timer_factory=threading.Timer,sleep=time.sleep):
    endpoint=resource_id(state['endpoint_id']);route='/v2/serverless/'+endpoint
    actual=api.call(route);verify_disabled(actual,expected)
    before_v2=limits(actual,endpoint)
    before_v1=limits(legacy.read(),endpoint,True)
    if before_v1!={'min':0,'max':0}:raise SetupError('Both control APIs must start disabled; no test run')
    verify_no_workers(api.call(route+'/workers'))
    billed=billed_amount(api.call('/v2/billing?lastN=30&bucketSize=day'))
    if not account_for_history(billed,state):raise SetupError('Budget headroom cannot cover the retained inference allowance')
    rows=candidates(api.call('/v2/catalog/gpus?include=AVAILABILITY&product=SERVERLESS&cloud=SECURE&count=1&minCudaVersion=12.8'))
    rates=[Decimal(str(row['serverless_usd_per_hour'])) for row in rows if row['pool']=='AMPERE_24']
    if not rates or any(not x.is_finite() or x<=0 for x in rates) or max(rates)>Decimal('.75'):
        raise SetupError('GPU rate is unverified or exceeds $0.75/hour')
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),'endpoint_id':endpoint,
            'requests_submitted':0,'configuration_changes_requested':True,
            'before':{'v2':before_v2,'v1':before_v1},'account_reported_usd':str(billed),
            'enabled_readback':{},'shutdown_verified':False,'result':'CHECK'}
    def disable():
        # Only shutdown writes are retried; no job-submission method exists here.
        try:api.call(route,'PATCH',{'workers':{'min':0,'max':0,'idleTimeout':300}})
        except SetupError:legacy.disable()
    def deadline():
        try:disable()
        except SetupError:pass
    timer=timer_factory(60,deadline);timer.daemon=True
    save(destination,report)
    try:
        timer.start()
        api.call(route,'PATCH',{'workers':{'min':0,'max':1,'idleTimeout':300}})
        report['enabled_readback']['v2']=limits(api.call(route),endpoint)
        report['enabled_readback']['v1']=limits(legacy.read(),endpoint,True)
        report['control_apis_agree_enabled']=all(
            value=={'min':0,'max':1} for value in report['enabled_readback'].values())
        save(destination,report)
    finally:
        try:
            disable()
            for _ in range(3):
                v2=limits(api.call(route),endpoint)
                v1=limits(legacy.read(),endpoint,True)
                if v1!={'min':0,'max':0}:legacy.disable();sleep(2);continue
                if v2!={'min':0,'max':0}:disable();sleep(2);continue
                verify_no_workers(api.call(route+'/workers'))
                report['shutdown_verified']=True
                break
            if report['shutdown_verified'] and len(report['enabled_readback'])==2:
                report['result']='CONTROL_AGREEMENT' if report.get('control_apis_agree_enabled') else 'CONTROL_MISMATCH'
        finally:
            timer.cancel()
            if timer.is_alive():timer.join(timeout=45)
            save(destination,report)
            if json.loads(destination.read_text())!=report:raise SetupError('Scaling report verification failed')
    return report


def legacy_credential(private,prompt=False):
    if not prompt:return private['RUNPOD_API_KEY']
    if not sys.stdin.isatty():raise SetupError('Use an interactive terminal for hidden control-key entry')
    value=getpass.getpass('RUNPOD_CONTROL_KEY from Render (hidden; not the inference key): ').strip()
    if not value:raise SetupError('Control key missing; no provider calls made')
    return value


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-scaling',action='store_true',help='Temporarily set min=0/max=1, compare both control APIs, then restore zero; no jobs')
    parser.add_argument('--prompt-legacy-control-key',action='store_true',
                        help='Use the dedicated Render control key for legacy API access only, without saving it')
    args=parser.parse_args()
    if not args.verify_scaling:
        print('Add --verify-scaling for the bounded control test. No provider access performed.')
        return
    private=credentials(ROOT/'deploy/cloud.env')
    legacy_key=legacy_credential(private,args.prompt_legacy_control_key)
    journal=ROOT/'artifacts/runpod-disabled-setup.json';state=json.loads(journal.read_text())
    attempt=json.loads((ROOT/'artifacts/runpod-warmup-startup-fix.json').read_text())
    if (state.get('phase')!='disabled_verified' or attempt.get('endpoint_id')!=state.get('endpoint_id')
            or attempt.get('app_shutdown_verified') is not True or attempt.get('provider_shutdown_verified') is not True
            or attempt.get('provider_diagnostic')!='Runpod submit: HTTP 409 (ENDPOINT_PAUSED); reconcile before retrying paid work'):
        raise SetupError('The saved paused-rejection attempt must have verified app/provider shutdown')
    plan=json.loads((ROOT/'artifacts/runpod-connection-plan.json').read_text())
    expected=payload(plan,private['R2_ACCOUNT_ID'],state['registry_id'],state['endpoint_name'])
    destination=ROOT/'artifacts/runpod-scaling-comparison.json'
    if destination.exists():raise SetupError('Scaling test already recorded; preserve its report before deciding further work')
    with (ROOT/'artifacts/runpod-disabled-setup.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SetupError('Another setup command is active') from None
        report=verify(API(private['RUNPOD_API_KEY']),Legacy(legacy_key,state['endpoint_id']),state,expected,destination)
        save(journal,state)
    print(json.dumps(report,indent=2))
    print('Saved and verified:',destination)
    if not report['shutdown_verified']:raise SetupError('Shutdown unconfirmed; inspect Runpod workers and set both limits zero immediately')
    print('PASS: both limits restored to zero and no allocated workers. No model job submitted.')


if __name__=='__main__':
    try:main()
    except (SetupError,PreparationError) as exc:raise SystemExit('CHECK: '+str(exc)) from None
    except (OSError,ValueError,KeyError,TypeError,KeyboardInterrupt):
        raise SystemExit('CHECK: scaling test interrupted or invalid data; inspect saved report and zero-worker settings. Details withheld.') from None
