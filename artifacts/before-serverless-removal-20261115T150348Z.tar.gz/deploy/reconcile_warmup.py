"""Reconcile only the expired first uncertain warm-up; never refund or start GPU work."""
import argparse
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import fcntl
import getpass
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'deploy'))
from create_runpod_disabled import API, SetupError, save, payload, resource_id, verify_disabled, verify_no_workers
from prepare_runpod import credentials, PreparationError
from inspect_runpod_attempt import runtime_read
from verify_runpod_connection import check_health
from rehearse_model import Web, number, safe_app_state, reconciled_reservation


def timestamp(value):
    try:
        result=value if isinstance(value,datetime) else datetime.fromisoformat(value.replace('Z','+00:00'))
        if result.tzinfo is None: raise ValueError()
        return result
    except (ValueError,TypeError,AttributeError): raise SetupError('Missing or invalid reconciliation timestamp') from None


def validate_candidate(app, control, jobs, ledger, attempt, expected, prior_recovery=None):
    if not (app.get('configured') is True and app.get('operator') is True
            and app.get('enabled') is False and app.get('can_start') is False
            and app.get('state') in ('error','stopping')):
        raise SetupError('Deploy RUNPOD_INFERENCE_BUDGET_APPROVED=0 first; app must be disabled with an unresolved attempt')
    if app.get('model')!=expected['env']['MODEL_REPOSITORY']:
        raise SetupError('App model identity mismatch')
    prior_reserved=Decimal(0)
    if prior_recovery is not None:
        prior_reserved=number(prior_recovery.get('reserved_compute_usd'))
        old=[job for job in jobs if str(job.get('id'))==prior_recovery.get('job_id')]
        if (len(jobs)!=2 or len(old)!=1 or prior_reserved!=Decimal('.10625')
                or prior_recovery.get('database_committed') is not True or prior_recovery.get('result')!='PASS'
                or old[0].get('state')!='RECONCILED_EXPIRED' or old[0].get('provider_id') is not None
                or old[0].get('kind')!='warmup' or old[0].get('case_id') is not None
                or number(old[0].get('reserved_compute_usd'))!=prior_reserved
                or number(attempt.get('prior_compute_reserved_usd'))!=prior_reserved):
            raise SetupError('The prior reconciled job and preserved reservation must match exactly')
        jobs=[job for job in jobs if str(job.get('id'))!=prior_recovery['job_id']]
    if len(jobs)!=1: raise SetupError('Expected exactly one unresolved warm-up; broader reconciliation is not permitted')
    job=jobs[0]
    if (job.get('kind')!='warmup' or job.get('state') not in ('pending','uncertain')
            or job.get('provider_id') is not None or job.get('case_id') is not None
            or job.get('task')!='warmup' or job.get('request_id')!=str(job.get('id'))
            or job.get('artifact_revision')!=expected['env']['MODEL_REVISION']):
        raise SetupError('The database job is not the original unacknowledged warm-up')
    if (control.get('enabled') is not False or control.get('phase') not in ('error','stopping')
            or control.get('model_revision') is not None or control.get('warmup_job') is not None):
        raise SetupError('Database model control state does not match the failed warm-up')
    created=timestamp(job['created_at']); began=timestamp(attempt['recorded_at'])
    if not -5<=(created-began).total_seconds()<=120:
        raise SetupError('Job timestamp does not match the saved rehearsal')
    if (timestamp(control['db_now'])-created).total_seconds()<900:
        raise SetupError('Wait until the ten-minute submitted TTL plus five-minute safety margin has elapsed')
    elapsed=number(attempt.get('elapsed_seconds'))
    if attempt.get('provider_shutdown_verified') is not True or not 0<elapsed<=1800:
        raise SetupError('The saved rehearsal must contain bounded, verified provider shutdown evidence')
    stop_bound=began+timedelta(seconds=float(elapsed)+60)
    if not timestamp(control['started_at'])<=stop_bound<=timestamp(control['db_now']):
        raise SetupError('Saved shutdown evidence is inconsistent with the database timestamps')
    if abs((timestamp(control['started_at'])-timestamp(app.get('started_at'))).total_seconds())>1:
        raise SetupError('Database session does not match the deployed app')
    if not (type(control.get('generation')) is int and type(job.get('generation')) is int
            and control['generation']>job['generation']>=1):
        raise SetupError('Stop generation was not confirmed')
    job_reserved=number(job.get('reserved_compute_usd'))
    reserved=prior_reserved+job_reserved
    if (not Decimal(0)<reserved<=Decimal('0.70')
            or job_reserved<=0
            or (prior_recovery is not None and job_reserved!=Decimal('.10625'))
            or number(ledger.get('compute_reserved_usd'))!=reserved
            or number(app.get('demo_compute_reserved_usd'))!=reserved
            or number(ledger.get('approved_total_usd'))!=Decimal('1')
            or number(ledger.get('compute_reservation_limit_usd'))!=Decimal('0.70')):
        raise SetupError('Reservation ledger does not match this single warm-up')
    return job,reserved,stop_bound


def provider_idle(api, runtime, endpoint, expected):
    route='/v2/serverless/'+resource_id(endpoint)
    actual=api.call(route)
    if actual.get('id')!=endpoint: raise SetupError('Provider endpoint identity mismatch')
    verify_disabled(actual,expected)
    verify_no_workers(api.call(route+'/workers'))
    check_health(runtime())


def reconcile(conn, app, attempt, expected, idle_check, report, apply=False, prior_recovery=None):
    # Transaction-level and session-level locks share the app's advisory key.
    if conn.execute('SELECT pg_try_advisory_xact_lock(519826) AS acquired').fetchone()['acquired'] is not True:
        raise SetupError('App model operation is in progress; no recovery attempted')
    control=conn.execute('SELECT *, now() AS db_now FROM model_control WHERE id=1 FOR UPDATE').fetchone()
    jobs=conn.execute("SELECT id,provider_id,generation,kind,case_id,state,created_at,reserved_compute_usd, "
        "payload->>'request_id' AS request_id,payload->>'task' AS task, "
        "payload->>'artifact_revision' AS artifact_revision FROM model_jobs ORDER BY created_at LIMIT 3 FOR UPDATE").fetchall()
    ledger=conn.execute('SELECT * FROM inference_allowance WHERE id=1 FOR UPDATE').fetchone()
    if control is None or ledger is None: raise SetupError('Expected control/allowance rows are missing')
    job,reserved,stop_bound=validate_candidate(app,control,jobs,ledger,attempt,expected,prior_recovery)
    idle_check()  # Fresh provider reads under the same app-operation lock.
    report.update(job_id=str(job['id']),original_job_state=job['state'],created_at=job['created_at'].isoformat(),
                  reserved_compute_usd=str(reserved),provider_disabled_and_idle_verified=True,
                  past_submitted_ttl_and_margin=True,outcome_verified=False,refund_usd='0',
                  candidate_verified=True,estimate_ended_at=stop_bound.isoformat(),
                  estimate_end_basis='Saved verified rehearsal shutdown plus 60-second clock margin')
    if not apply: return
    updated=conn.execute("UPDATE model_jobs SET state='RECONCILED_EXPIRED' "
                         "WHERE id=%s AND state=%s AND provider_id IS NULL RETURNING id",(job['id'],job['state'])).fetchone()
    if updated is None: raise SetupError('Job changed during reconciliation; transaction must roll back')
    conn.execute("UPDATE model_control SET enabled=false,phase='off',generation=generation+1, "
                 "ended_at=COALESCE(ended_at,%s),updated_at=now() WHERE id=1",(stop_bound,))
    conn.execute("INSERT INTO events(case_id,action,actor) VALUES(NULL,%s,%s)",
                 ('warmup_expired_unconfirmed_no_refund:'+str(job['id']),'operator-reconciliation'))
    check=conn.execute('SELECT compute_reserved_usd FROM inference_allowance WHERE id=1').fetchone()
    if number(check['compute_reserved_usd'])!=reserved: raise SetupError('Reservation changed; transaction must roll back')
    report['database_update_prepared']=True


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('origin')
    parser.add_argument('--apply',action='store_true',help='Record this expired uncertain warm-up without refunding its reservation')
    parser.add_argument('--followup',action='store_true',help='Recover the second warm-up while preserving the first reconciled job')
    args=parser.parse_args()
    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError: raise SetupError('Run this helper inside the existing policypilot-api:demo Docker image; it contains psycopg') from None
    if not sys.stdin.isatty(): raise SetupError('An interactive terminal is required for hidden credentials')
    state=json.loads((ROOT/'artifacts/runpod-disabled-setup.json').read_text())
    attempt_name='runpod-warmup-followup.json' if args.followup else 'runpod-warmup-rehearsal.json'
    attempt=json.loads((ROOT/'artifacts'/attempt_name).read_text())
    if (state.get('phase')!='disabled_verified' or attempt.get('endpoint_id')!=state.get('endpoint_id')
            or attempt.get('start_attempted') is not True or attempt.get('generation_verified') is not False):
        raise SetupError('Saved setup/rehearsal does not identify a failed first warm-up')
    private=credentials(ROOT/'deploy/cloud.env')
    plan=json.loads((ROOT/'artifacts/runpod-connection-plan.json').read_text())
    expected=payload(plan,private['R2_ACCOUNT_ID'],state['registry_id'],state['endpoint_name'])
    prior_recovery=None
    if args.followup:
        reconciled_reservation(ROOT,state,expected)
        prior_recovery=json.loads((ROOT/'artifacts/runpod-warmup-reconciliation.json').read_text())
        if (attempt.get('provider_diagnostic')!='Runpod submit: HTTP 409; reconcile before retrying paid work'
                or attempt.get('failure_stage')!='start_request'
                or timestamp(prior_recovery['recorded_at'])>=timestamp(attempt['recorded_at'])):
            raise SetupError('Follow-up report does not match the recorded HTTP 409 failure after recovery')
    destination=ROOT/'artifacts'/('runpod-warmup-followup-reconciliation.json' if args.followup else 'runpod-warmup-reconciliation.json')
    if destination.exists() and json.loads(destination.read_text()).get('database_committed') is True:
        raise SetupError('Recovery already committed; preserving its report. Do not rerun recovery.')
    web=Web(args.origin)
    username=input('Pilot username [reviewer]: ').strip() or 'reviewer'
    password=getpass.getpass('Pilot password (hidden): ')
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),'endpoint_id':state['endpoint_id'],
            'apply_requested':args.apply,'database_committed':False,'result':'CHECK',
            'provider_resources_changed':False,'new_jobs_submitted':0,'refund_usd':'0'}
    try:
        web.login(username,password); password=None
        app=web.call('/api/model/status')
        if app.get('can_start') is not False or app.get('enabled') is not False:
            raise SetupError('Set RUNPOD_INFERENCE_BUDGET_APPROVED=0 in Render and save/deploy before recovery')
        inference=getpass.getpass('RUNPOD_INFERENCE_KEY from Render (hidden): ').strip()
        if not inference or inference==private['RUNPOD_API_KEY']:
            raise SetupError('Use the dedicated inference key, not the setup key')
        dsn=getpass.getpass('Render database External Database URL (hidden): ').strip()
        parsed=urlsplit(dsn)
        if parsed.scheme not in ('postgres','postgresql') or not parsed.hostname or not parsed.hostname.endswith('.render.com'):
            raise SetupError('Use the full external PostgreSQL URL from this Render database Info page')
        api=API(private['RUNPOD_API_KEY'])
        def idle(): provider_idle(api,lambda:runtime_read(state['endpoint_id'],inference,'health'),state['endpoint_id'],expected)
        with (ROOT/'artifacts/runpod-disabled-setup.lock').open('a') as lock:
            try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError: raise SetupError('Another local setup/rehearsal is active') from None
            save(destination,report)
            with psycopg.connect(dsn,row_factory=dict_row,connect_timeout=10,sslmode='require',
                                  options='-c statement_timeout=15000 -c idle_in_transaction_session_timeout=180000') as conn:
                with conn.transaction():
                    reconcile(conn,app,attempt,expected,idle,report,args.apply,prior_recovery)
                    save(destination,report)  # Before commit, record the intended narrow mutation.
            report['database_committed']=args.apply; save(destination,report)
            if args.apply:
                idle()
                after=web.call('/api/model/status')
                report['app_after']=safe_app_state(after)
                if (after.get('state')!='off' or after.get('enabled') is not False or after.get('can_start') is not False
                        or number(after.get('demo_compute_reserved_usd'))!=number(report['reserved_compute_usd'])):
                    raise SetupError('Database committed but live app off/unchanged reservation not verified; do not retry paid work')
            report['result']='PASS'; save(destination,report)
            if json.loads(destination.read_text())!=report: raise SetupError('Recovery artifact read-back mismatch')
            print('PASS: expired warm-up matched; provider remains disabled and idle.')
            print('PASS: reservation retained at $'+report['reserved_compute_usd']+'; no refund, new job or provider change.')
            print('PASS: live app is off and Start remains budget-blocked.' if args.apply else 'Preview only: database state was not changed. Use --apply for this verified recovery.')
            print('Saved and verified recovery report:',destination)
    except Exception as exc:
        code=getattr(exc,'sqlstate',None)
        if isinstance(code,str) and re.fullmatch('[A-Z0-9]{5}',code): report['sqlstate']=code
        save(destination,report)
        if isinstance(exc,SetupError): raise
        raise SetupError('Database/network recovery check failed; credentials and exception details withheld. Inspect recovery report; do not retry paid work.') from None
    finally:
        try: web.call('/api/auth/logout','POST')
        except Exception: print('NOTICE: diagnostic logout was not confirmed.')


if __name__=='__main__':
    try: main()
    except (SetupError,PreparationError) as exc: raise SystemExit('CHECK: '+str(exc)) from None
    except (OSError,ValueError,KeyError,TypeError,EOFError,KeyboardInterrupt):
        raise SystemExit('CHECK: recovery interrupted or local input invalid; details withheld. Keep paid work disabled and inspect recovery report.') from None
