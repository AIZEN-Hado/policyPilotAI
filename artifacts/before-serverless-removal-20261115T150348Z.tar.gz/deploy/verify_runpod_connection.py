"""Verify app keys without jobs; optionally PATCH the already-zero worker limits."""
import argparse
from datetime import datetime, timezone
import getpass
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'deploy'))
from create_runpod_disabled import API, SetupError, ProviderHTTPError, payload, resource_id, save, verify_disabled, verify_no_workers
from prepare_runpod import credentials, PreparationError
from pilot.runpod_control import Runpod, ProviderError, confirmed_idle


def check_health(response):
    if not all(isinstance(response.get(group), dict) for group in ('workers', 'jobs')):
        raise SetupError('Health worker/job groups missing')
    if not confirmed_idle(response):
        raise SetupError('Zero active jobs and workers not confirmed')


def verify(api, client, endpoint, expected, destination, control_write=False):
    report = {'endpoint_id': endpoint, 'recorded_at': datetime.now(timezone.utc).isoformat(),
              'result': 'CHECK', 'jobs_submitted': 0, 'control_write_attempted': False,
              'control_write_verified': False, 'key_resource_restrictions_verified': False,
              'inference_submission_permission_verified': False, 'generation_verified': False}
    save(destination, report)
    route = '/v2/serverless/' + resource_id(endpoint)

    def snapshot(label):
        report['stage'] = label + ': control configuration read'
        actual = api.call(route)
        if actual.get('id') != endpoint:
            raise SetupError('Endpoint identity mismatch')
        verify_disabled(actual, expected)
        report['stage'] = label + ': allocated workers read'
        verify_no_workers(api.call(route + '/workers'))
        report['stage'] = label + ': inference health read'
        check_health(client.health())

    try:
        snapshot('Before')
        if control_write:
            report['stage'] = 'Verify control write with workers min=max=0'
            report['control_write_attempted'] = True
            save(destination, report)
            api.call(route, 'PATCH', {'workers': {'min': 0, 'max': 0, 'idleTimeout': 300}})
            snapshot('After')
            report['control_write_verified'] = True
        report.update(result='PASS', stage='Complete', disabled_configuration_verified=True,
                      zero_allocated_workers_verified=True, inference_health_access_verified=True)
        save(destination, report)
        return report
    except (SetupError, ProviderError, ValueError, TypeError, AttributeError, OSError) as exc:
        # No raw responses or exceptions containing credentials are persisted.
        if isinstance(exc, ProviderHTTPError): report['http_status'] = exc.status
        save(destination, report)
        status = ' HTTP ' + str(exc.status) if isinstance(exc, ProviderHTTPError) else ''
        raise SetupError('Connection verification failed at ' + report['stage'] + status +
                         '. Details withheld; no jobs submitted. See the connection report.') from None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-control-write', action='store_true',
                        help='After confirming idle/disabled state, PATCH min=max=0 and read back')
    args = parser.parse_args()
    state = json.loads((ROOT / 'artifacts/runpod-disabled-setup.json').read_text())
    if state.get('phase') != 'disabled_verified':
        raise SetupError('Complete disabled endpoint verification first')
    endpoint = resource_id(state['endpoint_id'])
    plan = json.loads((ROOT / 'artifacts/runpod-connection-plan.json').read_text())
    private = credentials(ROOT / 'deploy/cloud.env')
    expected = payload(plan, private['R2_ACCOUNT_ID'], state['registry_id'], state['endpoint_name'])
    if not sys.stdin.isatty(): raise SetupError('Use an interactive terminal for hidden key entry')
    print('Endpoint:', endpoint)
    print('Paste the dedicated keys used in Render. They will not be saved or printed.')
    control = getpass.getpass('RUNPOD_CONTROL_KEY (hidden): ').strip()
    inference = getpass.getpass('RUNPOD_INFERENCE_KEY (hidden): ').strip()
    if not control or not inference: raise SetupError('Both dedicated app keys are required')
    if private['RUNPOD_API_KEY'] in (control, inference):
        raise SetupError('Use dedicated app keys, not the broad setup credential')
    destination = ROOT / 'artifacts/runpod-connection-verification.json'
    verify(API(control), Runpod(endpoint, control, inference), endpoint, expected,
           destination, args.verify_control_write)
    print('PASS: control read access, disabled configuration, zero allocated workers and inference health access.')
    if args.verify_control_write: print('PASS: control PATCH accepted; min=max=0 verified again after the write.')
    print('Saved safe connection report:', destination)
    print('No jobs submitted. Key restrictions, inference submission, image pull, generation and RAM remain unverified.')
    print('Keep ENABLE_MODEL_CONTROL=0 and RUNPOD_INFERENCE_BUDGET_APPROVED=0 in Render.')


if __name__ == '__main__':
    try: main()
    except (SetupError, PreparationError) as exc: raise SystemExit('CHECK: ' + str(exc)) from None
    except (OSError, ValueError, KeyError, TypeError, EOFError, KeyboardInterrupt):
        raise SystemExit('CHECK: local input invalid or interrupted; details withheld. Inspect the connection report before continuing.') from None
