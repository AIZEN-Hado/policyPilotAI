"""One synthetic generation request; may start a billable serverless worker."""
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pilot.inference import runpod_generate
from pilot.review_prompt import SCHEMA, SYSTEM
from pilot.core import validate_output


def main():
    if '--run-synthetic-request' not in sys.argv:
        raise SystemExit('Use --run-synthetic-request to send one billable synthetic inference request.')
    endpoint=os.environ.get('RUNPOD_ENDPOINT_ID','')
    token=os.environ.get('RUNPOD_INFERENCE_KEY','')
    model=os.environ.get('RUNPOD_MODEL','Qwen/Qwen2.5-7B-Instruct')
    # No real policy or financial claim content is read from disk.
    evidence=[{'id':'synthetic:1','document_id':'synthetic','filename':'synthetic-policy.pdf',
               'kind':'policy','page':1,'text':'This synthetic policy excludes registration fees.'}]
    result=runpod_generate(endpoint,token,model,SYSTEM,
        json.dumps({'claim_description':'Synthetic connectivity test: identify the registration fee exclusion.',
                    'excerpts':evidence,'partial_context':False}),SCHEMA)
    verified=validate_output(result,evidence,False)
    if not verified['findings']:
        raise ValueError('No supported finding generated')
    print('PASS: authenticated Runpod generation, JSON validation and source-quote check.')
    print('This verifies one synthetic response, not insurance accuracy or production readiness.')


if __name__ == '__main__':
    try:
        main()
    except Exception:
        raise SystemExit('Inference check failed. Inspect endpoint readiness/configuration; response and credentials withheld.')
