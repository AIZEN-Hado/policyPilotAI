"""Read-only Runpod access check. Prints counts, never resource details or secrets."""
import json
import os
import urllib.error
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def main():
    token = os.environ.get('RUNPOD_API_KEY')
    if not token:
        raise SystemExit('RUNPOD_API_KEY missing. Load deploy/cloud.env first.')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    failed = False
    for resource in ('pods', 'endpoints'):
        request = urllib.request.Request(
            'https://rest.runpod.io/v1/' + resource,
            headers={'Authorization': 'Bearer ' + token, 'Accept': 'application/json',
                     'User-Agent':'PolicyPilot-ConnectivityCheck/1.0'})
        try:
            with opener.open(request, timeout=20) as response:
                data = response.read(2 * 1024 * 1024 + 1)
                if len(data) > 2 * 1024 * 1024:
                    raise ValueError('Oversized response')
                records = json.loads(data)
            if not isinstance(records, list):
                raise ValueError('Unexpected response format')
            print(f'PASS: Runpod {resource} read access; {len(records)} existing resources.')
        except urllib.error.HTTPError as exc:
            failed = True
            kind = 'HTML' if 'text/html' in exc.headers.get('Content-Type','') else 'non-HTML'
            print(f'Runpod {resource} check failed: HTTP {exc.code} ({kind} response). Body withheld.')
            if exc.code in (401,403):
                print('Check that the key is enabled and has read access for this resource. An endpoint-only key may not allow account resource listing.')
        except (OSError, ValueError):
            failed = True
            print(f'Runpod {resource} check failed: network or response error. No secrets printed.')
    if failed:
        raise SystemExit('Runpod access not fully verified. No resources changed.')
    print('No compute started or resources changed. This does not verify inference readiness.')


if __name__ == '__main__':
    main()
