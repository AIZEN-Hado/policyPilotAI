# Deploy the uploaded API image for the interview demo

This path deploys the existing private image. No Git repository, rebuild, GPU or
background worker is needed to bring up login, cases and synthetic PDF storage.
Model generation remains unavailable until a separate endpoint and artifact are
verified. This is a deployment procedure, not evidence of a live application.

## 1. Verify the built release

Run in the ordinary terminal with Docker access:

```sh
docker run --rm --network none --entrypoint python policypilot-api:demo -m pilot.check_tests
```

Require a successful exit and zero skipped tests. Keep both local images.

## 2. Create free hosting

Create an account at https://dashboard.render.com/register.

In the dashboard, create a **Postgres** database called `policypilot-demo-db` in
Singapore. Select **Free** explicitly. If Free is unavailable, stop rather than
selecting a paid substitute. Copy its **Internal Database URL** privately.

Create a **Web Service**, choose **Existing Image**, and use:

```text
ghcr.io/aizen-hado/policypilot-api@sha256:c2c5f3460fbd743943473c17510ab6d5e1ec0a4a4d050c1c8263b0a450232b7a
```

Add a GHCR credential with username `AIZEN-Hado` and a classic token with
`read:packages`. Enter the token only in Render's credential form. Keep the image
private. Choose Singapore, service name `policypilot-demo`, and compute **Free**.
Do not add a disk or background worker.

Set **Docker Command** under Advanced to:

```text
sh /srv/deploy/render-start.sh web
```

This applies migrations and binds to Render's assigned port. Set health check
path to `/healthz`.

## 3. Configure application settings

Set these environment variables in Render:

| Variable | Value |
| --- | --- |
| DATABASE_URL | The new database's Internal Database URL |
| AUTH_MODE | `session` |
| APP_ORIGIN | The exact assigned `https://...onrender.com` origin, no trailing path |
| PILOT_USER | `reviewer` |
| MODEL_OPERATOR | `reviewer` |
| PILOT_PASSWORD_HASH | Generate with the command below; enter privately |
| DOCUMENT_STORAGE | `r2` |
| R2_ACCOUNT_ID | Corresponding value from local `deploy/cloud.env` |
| S3_BUCKET | Corresponding value from local `deploy/cloud.env` |
| AWS_ACCESS_KEY_ID | Corresponding value from local `deploy/cloud.env` |
| AWS_SECRET_ACCESS_KEY | Corresponding value from local `deploy/cloud.env` |
| AWS_EC2_METADATA_DISABLED | `true` |
| PROCESSING_BACKEND | `runpod` |
| INFERENCE_BACKEND | `ollama` |
| ENABLE_MODEL_CONTROL | `0` |
| RUNPOD_INFERENCE_BUDGET_APPROVED | `0` |

```sh
python deploy/hash_password.py
```

`INFERENCE_BACKEND=ollama` temporarily allows startup without endpoint credentials;
no Ollama service or local model is started. `PROCESSING_BACKEND=runpod` routes
processing to the disabled remote controls, so requests cannot silently enter a
local worker queue. Do not add Runpod credentials at this stage.

If the assigned origin is only visible after service creation, use
`https://setup.invalid` temporarily for APP_ORIGIN. After Render assigns the real
HTTPS origin, replace the temporary value, save and redeploy before testing
login. The temporary value deliberately prevents browser mutations on the public
URL. Missing settings can cause startup failure. Do not guess the assigned URL.

The historical `render.yaml` describes paid services. Do not apply it for this
free image deployment. `render-demo.yaml` is a separate source-based Blueprint;
the Existing Image flow above does not require applying either Blueprint.

## 4. Verify the actual deployment

Wait for migration completion and a healthy deploy in Render's logs. Open the
assigned HTTPS URL, log in, and run from the ordinary terminal:

```sh
python deploy/smoke.py https://YOUR-ASSIGNED-SERVICE.onrender.com
```

This uses synthetic PDFs and does not submit inference by default. The smoke
script uses Python's standard library and needs no additional Python packages.
Require login, origin checks, upload/download integrity, case deletion and logout
to pass. Confirm deletion cleanup with the operator controls. Verify the browser
UI on desktop and mobile. An HTTP health check alone is not an application test.

Only then configure the remote model. A successful image upload does not prove
Runpod private-image pull, CUDA, model generation, fine-tuning or shutdown.

## Diagnose a rejected login without another reset

Run locally with the actual public origin:

```sh
python deploy/diagnose_login.py https://YOUR-ASSIGNED-SERVICE.onrender.com
```

Enter the exact PILOT_USER, paste the current web service's PILOT_PASSWORD_HASH
at the hidden prompt, and enter the attempted password at its hidden prompt.
No credentials are saved or printed. A malformed hash or mismatched password
stops before network requests. Otherwise the helper checks health, sends one
login attempt with the exact origin, verifies the Secure cookie and session, and
attempts to log out that diagnostic session. It does not alter cases, retry login
or call model endpoints. Report only its PASS/CHECK/NOTICE lines, never credentials.

Local matching does not prove the hash is active in the live deployment: a 401
after a local match points to the active username/hash, wrong service or a deploy
that has not picked up Environment changes. A 403 identifies an origin rejection;
429 is the account lockout; 503 requires checking database/migrations. If the
diagnostic succeeds but the browser fails, enter the same credentials manually
in a private browser window without autofill.

## Free-tier limits

As checked on 2026-11-11, free web services sleep after 15 minutes without inbound
traffic and can take about a minute to wake. Open the app before the interview.
Free Postgres expires after 30 days; only one free database is allowed per
workspace. These tiers do not provide a guarantee of uninterrupted availability.
Stay on Free plans and within included usage. No paid upgrade is authorized.

Sources:
- https://render.com/docs/deploying-an-image
- https://render.com/docs/free
# Connect the verified disabled Runpod endpoint — 2026-11-11

Endpoint `tjkkm5pkp7lrej` (`policypilot-demo-fd468331939a`) passed disabled
configuration and zero-worker verification in the user's terminal. This verifies
metadata only; image pull and generation remain pending.

In the Render web service's Environment page, copy the values from
`artifacts/runpod-render-settings.json`, excluding its explanatory `note` field.
Keep `ENABLE_MODEL_CONTROL=0` and `RUNPOD_INFERENCE_BUDGET_APPROVED=0`.
Keep `INFERENCE_BACKEND=ollama` until `RUNPOD_INFERENCE_KEY` has been added;
the configuration refuses startup with the Runpod backend and a missing key.

Create dedicated keys in Runpod's Credentials → API Keys page:
https://console.runpod.io/user/credentials . Official permission guidance:
https://docs.runpod.io/get-started/credentials . Use Restricted access scoped to
this endpoint. The inference key goes in Render as `RUNPOD_INFERENCE_KEY`;
the separate control key goes in `RUNPOD_CONTROL_KEY`. The control client needs
REST v2 endpoint reads and PATCH (schema scopes `serverless:read` and
`serverless:write`); invocation access alone does not prove management access.
If the console cannot restrict management access to this endpoint, establish the
available permission options before broadening access. Do not copy the broad
setup key from deploy/cloud.env to Render. Never paste either key into chat.

After adding the keys, set `INFERENCE_BACKEND=runpod`, keep both enable flags at
zero, then save and deploy. Key scope, private pull and controlled warm-up still
need verification before enabling Start. No Docker rebuild or image upload is
needed for these environment changes.

