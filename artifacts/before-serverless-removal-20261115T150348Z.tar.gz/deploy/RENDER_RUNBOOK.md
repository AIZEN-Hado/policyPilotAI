# Render release preparation

For the current uploaded-image, free demo path, use
[RENDER_IMAGE_DEMO.md](RENDER_IMAGE_DEMO.md). It needs no source repository and
keeps model compute disabled during web verification. The paid source-based
procedure below is historical preparation, not the current deployment choice.

This is an unprovisioned configuration, not a working deployment. It uses one
shared reviewer account, synthetic PDFs, R2 documents, PostgreSQL and one OCR
worker. The web and worker region is proposed as Singapore. No real claims are
authorized. No hosting or ongoing inference budget has been approved by this file.

## Current release blockers

- This shell cannot resolve Runpod, Render or PyPI. Runpod credential validity is
  unverified; no resource was created. The Render connector is offered but its
  connection has not been confirmed.
- API packages are absent and the Docker daemon is inaccessible. The local
  release test gate fails with 16 skipped HTTP tests; 49 other tests pass.
- Blueprint fields were reviewed against the current [Render reference](https://render.com/docs/blueprint-spec).
  Provider-side Blueprint validation and a real container build remain required.
- The Runpod adapter is existing staging infrastructure support. It does not
  implement the desired below-2,000,000,000-byte model runtime. There is no tested
  small-model artifact or live endpoint. Do not select the historical 7B baseline
  as an implementation of that RAM target.

## Deployment procedure once access and budgets are available

1. Review the paid web/worker/database plans in `render.yaml` against a current
   provider quote. Recurring hosting and inference costs are separate from the
   strictly under-$2 GPU experiment allowance. Do not apply the Blueprint until
   those hosting costs are authorized. Avoid collisions with existing service names.
2. Push the verified source to the user's private repository. This workspace has
   inaccessible Git metadata; no repository or push was created here.
3. Run the provider's Blueprint validation. Build `pilot/Dockerfile`; it runs
   `python -m pilot.check_tests`, which fails on any skip. Dependencies must install
   and all HTTP boundary tests must execute before proceeding.
4. Generate the shared login hash using `python deploy/hash_password.py`. Its hidden
   prompt prints a PBKDF2 hash, never the password. Put the hash in the Render
   secret setting `PILOT_PASSWORD_HASH`. Do not use the older Caddy bcrypt hash.
5. Supply `APP_ORIGIN` as the exact assigned HTTPS origin, without a path, plus the
   bucket-scoped R2 settings from `deploy/cloud.env`. Do not upload that file or use
   the broad Runpod management key as `RUNPOD_INFERENCE_KEY`. The Blueprint prompts
   for all unknown secrets and shares the required values with the worker.
6. Resolve inference before starting processing. A disposable training Pod must
   never become the application's permanent inference dependency. Use a measured
   small CPU model artifact/runtime when available, or explicitly approve separate
   ongoing inference costs. The current Blueprint's Runpod settings require a
   validated, authenticated existing endpoint; it creates no endpoint or GPU.
7. Startup applies migrations under a PostgreSQL advisory lock, then launches the
   web server on Render's `PORT` or the single worker. `/healthz` checks the database
   without exposing private records. It does not certify OCR or inference readiness.
8. Run `python deploy/smoke.py https://YOUR-SERVICE.onrender.com`. It prompts for
   credentials and checks login, missing-Origin rejection, synthetic uploads,
   byte-for-byte downloads, case deletion and logout. No inference is invoked by
   default. The worker must separately confirm queued object deletion in R2.
9. Only after cost controls are verified, use the explicit `--run-inference` flag
   for the real pipeline, then `--case SYN-C003 --run-inference` for scanned input.
   This can incur charges. It submits once and leaves the case for inspection;
   never automatically rerun a timed-out job. Verify browser behavior, source links,
   OCR accuracy, model memory, persistence after restart, recovery and removal.

## Session behavior and limits

`AUTH_MODE=session` requires a generated password hash and ignores proxy identity
headers. The `__Host-` session cookie is Secure, HttpOnly, SameSite=Strict, path `/`,
without a Domain attribute. Session tokens are random; PostgreSQL stores hashes
only. Sessions expire after eight hours, survive a service restart, and are revoked
on logout or a change to username/password hash. At most 20 sessions are retained.
No public signup exists. Reviewer attribution comes from the validated session.

Mutation requests, including login/logout, require the exact configured Origin.
Five failed attempts lock the shared account until the 15-minute window ends;
this account-wide throttle can also temporarily block legitimate users. HTTPS is
mandatory. The old trusted-proxy deployment remains available via `AUTH_MODE=proxy`.

## GPU experiment contract

Do not provision while access, price, billing visibility or deletion controls are
unverified. The cumulative experiment total must stay strictly below USD 2,
including startup, idle, disk and temporary storage. Reserve termination margin;
a client timeout alone is not a spending cap. Use synthetic data only.

Run the unmodified base evaluation before training. Record model/base revisions,
dataset split provenance, training configuration, quality results and measured RSS.
Download all required outputs; verify hashes and reload the saved model. Only then
remove dedicated training compute and temporary billed storage, and confirm their
absence by fresh provider reads. Failed jobs also require cleanup. No training
resource was created in this session, and there is no trained artifact to verify.
