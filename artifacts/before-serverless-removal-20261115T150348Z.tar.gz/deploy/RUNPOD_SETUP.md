# Runpod inference staging

> Historical vLLM adapter procedure. The current live app uses a custom queue
> worker for document processing and model controls. Follow
> [GPU_WORKER.md](GPU_WORKER.md) for that contract. Do not provision this historical
> vLLM endpoint for the current app or follow its older budget/hosting settings.

Use a **Serverless vLLM endpoint**, not a public model API or unauthenticated Pod.
The app adapter uses Runpod's authenticated chat-completions gateway. The API
format is OpenAI-compatible; no OpenAI account, key or model is involved.

## Console configuration to review before deployment

Open Runpod → Serverless → deploy the maintained vLLM worker. Configure:

| Setting | Initial staging value |
| --- | --- |
| Name | policypilot-staging |
| Model / MODEL_NAME | Qwen/Qwen2.5-7B-Instruct |
| GPU | One 24 GB GPU, preferably RTX 4090 if available |
| Active/minimum workers | 0 |
| Maximum workers | 1 |
| Idle timeout | 5 seconds initially |
| MAX_MODEL_LEN | 8192 |
| MAX_NUM_SEQS | 1 |
| MAX_CONCURRENCY | 1 |
| TENSOR_PARALLEL_SIZE | 1 |
| GPU_MEMORY_UTILIZATION | 0.90 |

This model is a staging baseline, not a claim of best insurance accuracy. FP16/BF16
7B plus bounded context is a 24 GB sizing candidate; verify actual startup/memory.
Use the maintained worker offered in the console and record its exact image tag
and digest before deployment. Do not choose an unversioned image for release.
Do not enable tools, remote code execution, debug prompt logging or public access.
Review provider logs/retention before real claims; synthetic requests only now.

Prefer provider model caching for the first test. A separately purchased network
volume is not required initially. If added later, store model weights only and
account for storage charges and region constraints. Do not give the model service
R2 or database credentials.

Choose and record the endpoint region; the user has not confirmed India-only
requirements. Cross-region synthetic testing does not authorize real-claim handling.

## Cost review

User constraint: **under USD 2 total for the current Runpod experiment**, interpreted
as cumulative usage including startup, idle time, storage and applicable taxes,
not an hourly rate or authorization for recurring hosting. Do not provision until
the displayed rate is known. Target at most USD 1 estimated total, reserving the
remaining margin for billing/termination delays. No separate network volume,
fine-tuning, active workers, automatic resubmissions or unattended operation.
Run one synthetic smoke request initially, then delete the test endpoint and verify
workers stopped and final billed usage. Do not alter other account resources.
If startup stalls, terminate the experiment rather than repeatedly retrying.

Worker count and client timeouts are not provider-enforced dollar limits. A client
timeout does not stop remote billing. A strict USD 2 ceiling is not yet technically
enforced; if adequate controls cannot be established, do not start the experiment.
Account credit top-ups may exceed USD 2 even when actual usage is below it; do not
request or initiate such a payment without clarifying this with the user.

Record the exact **serverless** rate displayed for the selected GPU in the console,
not a Pod rental price. No live quote or endpoint creation was possible from this
authoring shell. Flex workers bill startup, execution and idle timeout until stopped.
Zero active workers avoids always-on GPU charges but is not a hard spending cap;
maximum one worker also does not cap monthly spending. Storage is separately billed.
For a displayed per-second rate R, ten billed minutes cost 600 × R plus storage/tax.
Review the selected rate before clicking Deploy. No compute has been started by us.

## Credentials and verification after deployment

Create an inference credential restricted to the new endpoint's invocation needs.
Keep the existing account-management key out of the web app. In a bash terminal:

```bash
export RUNPOD_ENDPOINT_ID='the-endpoint-id-from-runpod'
export RUNPOD_MODEL='Qwen/Qwen2.5-7B-Instruct'
read -rsp 'Endpoint inference key: ' RUNPOD_INFERENCE_KEY; echo
export RUNPOD_INFERENCE_KEY
nix-shell -p 'python3.withPackages (ps: [ ps.httpx ])' --run 'python3 deploy/check_inference.py --run-synthetic-request'
```

The explicit smoke-test flag sends **one billable synthetic request**. It uses no
real claims and prints no model text or secrets. First startup can exceed the
client's five-minute timeout. Do not automatically resubmit: check worker status
first because a timed-out request can still be running/billable.

After validation, configure Render worker and API with INFERENCE_BACKEND=runpod,
RUNPOD_ENDPOINT_ID, RUNPOD_MODEL and RUNPOD_INFERENCE_KEY in provider secret settings.
R2 credentials stay in the API/worker. Do not put inference keys in frontend JS.

## Current implementation limits

- JSON schema is supplied in the prompt; server-side constrained decoding is not
  asserted for this gateway. Malformed/unsupported JSON and truncated/tool responses
  are rejected. Existing quote checks still run before results are stored.
- `/models` readiness means model registration, not warm GPU or proven generation.
- No redirects, provider fallback or automatic generation retries.
- API login remains proxy-based; hosted session authentication is a later gate.
- Live generation, image compatibility, GPU memory and latency remain unverified.
- A successful smoke request validates connectivity and one citation, not clinical
  or insurance accuracy. Complete the three-case and adversarial evaluation later.

Sources checked 2026-11-10:
- https://docs.runpod.io/serverless/vllm/get-started
- https://github.com/runpod-workers/worker-vllm
- https://docs.runpod.io/serverless/pricing
