"""Allowlisted source package; excludes credentials, evaluation answers and legacy data."""
from pathlib import Path
import hashlib
import json
import tarfile
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'artifacts/policypilot-live-pilot.tar.gz'
out.parent.mkdir(exist_ok=True)
files=[ROOT/'.dockerignore', ROOT/'render.yaml', ROOT/'render-demo.yaml',
       ROOT/'docs/IMPLEMENTATION_PLAN.md',ROOT/'docs/RUNPOD_APP_CONTROL_PLAN.md']
files += [p for p in (ROOT/'pilot').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
files += [p for p in (ROOT/'deploy').iterdir() if p.is_file() and p.name in {'compose.yaml','Caddyfile','db-init.sql','configure.py','start.sh','smoke.py','backup.sh','package.py','HOSTINGER_RUNBOOK.md','render-start.sh','hash_password.py','RENDER_RUNBOOK.md','check_runpod.py','check_r2.py','check_inference.py','GPU_WORKER.md','gpu.Dockerfile','gpu-requirements.txt','preview_ui.py','preflight_live.py','publish_images.py'}]
files += list((ROOT/'deploy/tests').glob('test_*.py'))
files += [ROOT/'deploy/RENDER_IMAGE_DEMO.md']
files += [ROOT/'deploy/diagnose_login.py']
files += [ROOT/'deploy/prepare_runpod.py']
files += [ROOT/'deploy/create_runpod_disabled.py']
files += [ROOT/'deploy/verify_runpod_connection.py']
files += [ROOT/'deploy/rehearse_model.py']
files += [ROOT/'deploy/inspect_runpod_attempt.py']
files += [ROOT/'deploy/check_runpod_scaling.py']
files += [ROOT/'deploy/start_existing_worker.py']
files += [ROOT/'deploy/worker_observer.py']
files += [ROOT/'deploy/reconcile_warmup.py']
files += [ROOT/'deploy/settle_closed_warmups.py']
files += [ROOT/'deploy/check_model_loader.py']
files += [ROOT/'deploy/extend_inference_budget.py']
files += list((ROOT/'data/synthetic/exemplars').rglob('*.pdf'))
files += [ROOT/'data/synthetic/README.md']
with tarfile.open(out,'w:gz') as archive:
    for p in sorted(files): archive.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
with tarfile.open(out) as archive:
    names=archive.getnames()
    assert not any('.env' in Path(n).parts or 'evaluation' in Path(n).parts or '.git' in Path(n).parts for n in names)
    assert 'pilot/static/index.html' in names and 'deploy/compose.yaml' in names
    assert 'render.yaml' in names and 'deploy/render-start.sh' in names
    assert not any(Path(n).name.endswith('.env') for n in names)
    for path in files:
        member=archive.extractfile(str(path.relative_to(ROOT)))
        assert member is not None
        assert hashlib.sha256(member.read()).digest()==hashlib.sha256(path.read_bytes()).digest()
digest=hashlib.sha256(out.read_bytes()).hexdigest()
out.with_suffix(out.suffix+'.sha256').write_text(digest+'  '+out.name+'\n')
manifest={'artifact_type':'source_release_not_trained_model','archive':out.name,'sha256':digest,
          'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)},
          'verified':'Every archived file was read back and its SHA-256 matched its source.'}
out.with_suffix(out.suffix+'.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'Packaged {len(files)} files: {out}')
print('Verified archive contents and SHA-256:',digest)
