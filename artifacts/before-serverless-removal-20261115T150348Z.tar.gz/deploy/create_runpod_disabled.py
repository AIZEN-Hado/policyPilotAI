"""Create and verify the demo endpoint with workers min=max=0. Never submit jobs."""
import argparse
from datetime import datetime,timezone
from decimal import Decimal
import fcntl
import getpass
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'deploy'))
from prepare_runpod import credentials,candidates,PreparationError,NoRedirect,MODEL
from publish_images import github,assert_private,PublishError,safe_docker_detail

BASE='https://api.runpod.io'


class SetupError(Exception):pass


class ProviderHTTPError(SetupError):
    def __init__(self,message,status):
        super().__init__(message)
        self.status=status


def protected_values(value,sensitive=False):
    if isinstance(value,str):return [value] if sensitive and value else []
    if isinstance(value,dict):
        return [secret for key,child in value.items() for secret in protected_values(child,
                sensitive or key=='env' or bool(re.search('password|secret|token|key|credential|username',key,re.I)))]
    if isinstance(value,list):return [secret for child in value for secret in protected_values(child,sensitive)]
    return []


def validation_detail(raw,protected):
    """Allowlisted JSON error fields only; redact known secrets before display."""
    try:data=json.loads(raw) if len(raw)<=16384 else None
    except (ValueError,UnicodeError):data=None
    if not isinstance(data,dict):return 'Non-JSON or oversized error body withheld.'
    lines=[]
    for key in ('title','detail','message','error'):
        if isinstance(data.get(key),str):lines.append(key+': '+data[key])
    errors=data.get('errors')
    if isinstance(errors,list):
        lines.extend('validation: '+value for value in errors[:5] if isinstance(value,str))
    if not lines:return 'No recognized validation fields; body withheld.'
    safe=safe_docker_detail('\n'.join(lines),protected)
    return re.sub(r'[\x00-\x08\x0b-\x1f\x7f]','',safe)


class API:
    def __init__(self,token):
        self.token=token
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())

    def call(self,path,method='GET',body=None,missing_ok=False):
        if not path.startswith('/v2/') or '..' in path:
            raise SetupError('Invalid fixed provider API path')
        request=urllib.request.Request(BASE+path,method=method,
            data=None if body is None else json.dumps(body).encode(),
            headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json','Accept':'application/json'})
        try:
            with self.opener.open(request,timeout=30) as response:
                if response.code==204:return None
                raw=response.read(4*1024*1024+1)
                if len(raw)>4*1024*1024:raise ValueError()
                result=json.loads(raw)
                if not isinstance(result,dict):raise ValueError()
                return result
        except urllib.error.HTTPError as exc:
            if exc.code==404 and missing_ok:return None
            try:raw=exc.read(16385)
            except OSError:raw=b''
            detail=validation_detail(raw,[self.token,*protected_values(body)])
            raise ProviderHTTPError(f'Provider {method} failed: HTTP {exc.code}. Sanitized validation detail:\n'+detail+'\nNo automatic retry.',exc.code) from None
        except (OSError,ValueError):
            raise SetupError(f'Provider {method} response uncertain or unavailable. No automatic retry. Inspect the saved setup journal and Runpod console before repeating a create.') from None


def save(path,value):
    path.parent.mkdir(exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w',dir=path.parent,delete=False) as output:
        temporary=Path(output.name)
        try:
            json.dump(value,output,indent=2);output.write('\n');output.flush();os.fsync(output.fileno())
            os.replace(temporary,path)
        finally:temporary.unlink(missing_ok=True)


def resource_id(value):
    if not isinstance(value,str) or not re.fullmatch('[A-Za-z0-9_-]{3,160}',value):
        raise SetupError('Provider resource ID was not confirmed. Reconcile the create in the console; do not retry blindly.')
    return value


def payload(plan,account,registry,name):
    model=plan.get('model',{})
    image=plan.get('image','')
    if (model.get('repository')!=MODEL or not re.fullmatch('[a-f0-9]{40}',str(model.get('revision','')))
            or not re.fullmatch(r'ghcr\.io/aizen-hado/policypilot-gpu@sha256:[a-f0-9]{64}',image)):
        raise SetupError('The saved model/image pin is invalid. Run prepare_runpod.py again.')
    if plan.get('gpu',{}).get('pool')!='AMPERE_24':raise SetupError('Unexpected saved GPU pool')
    return {'name':name,'type':'QUEUE','image':image,'registry':registry,'disk':30,
            'cmd':['python','-m','pilot.gpu_handler'],'ports':[],
            'env':{'MODEL_REPOSITORY':MODEL,'MODEL_REVISION':model['revision'],
                   'DOCUMENT_DOWNLOAD_HOST':account.lower()+'.r2.cloudflarestorage.com',
                   'HF_HOME':'/tmp/huggingface','RUNPOD_INIT_TIMEOUT':'180'},
            'gpu':{'pools':['AMPERE_24'],'count':1,'minCudaVersion':'12.8','excludedTypes':[]},
            'workers':{'min':0,'max':0,'idleTimeout':300},
            'scaling':{'type':'QUEUE_DELAY','queueDelay':4},'timeout':180000,'flashboot':'OFF',
            'dataCenterIds':[],'mounts':{'network':[],'global':[]}}


def normalized_config(actual):
    value=dict(actual)
    # Observed v2 queue responses omit the optional ports field for ports=[].
    # This pinned queue-worker image declares no EXPOSE ports. Normalize omission
    # only; explicit null, malformed values and any exposed ports still fail.
    if value.get('type')=='QUEUE' and 'ports' not in value:value['ports']=[]
    # Canonical mounts explicitly confirm both lists empty. An omitted deprecated
    # networkVolumes alias adds no storage; a conflicting present alias fails.
    if value.get('mounts')=={'network':[],'global':[]} and 'networkVolumes' not in value:
        value['networkVolumes']=[]
    if isinstance(actual.get('gpu'),dict):
        value['gpu']=dict(actual['gpu'])
        # The provider schema explicitly defines omitted exclusions as the whole
        # selected pool, identical to our requested empty exclusion list.
        if 'excludedTypes' not in value['gpu']:value['gpu']['excludedTypes']=[]
    if 'cmd' not in value and isinstance(value.get('args'),str):
        raw=value['args']
        try:
            if raw.lstrip().startswith('{'):
                encoded=json.loads(raw)
                if isinstance(encoded,dict) and isinstance(encoded.get('cmd'),list):
                    value['cmd']=encoded['cmd']
                    if 'entrypoint' in encoded and 'entrypoint' not in value:value['entrypoint']=encoded['entrypoint']
            elif raw.strip():value['cmd']=shlex.split(raw)
        except ValueError:pass
    return value


def verification_report(actual,expected):
    """Record field presence/types/matches only, never arbitrary returned values."""
    normalized=normalized_config(actual)
    checks={}
    for key in ('name','type','image','registry','disk','cmd','ports','env','scaling','timeout','flashboot','mounts','dataCenterIds'):
        checks[key]={'present':key in actual,'observed_type':type(actual.get(key)).__name__,
                     'matches':normalized.get(key)==expected.get(key)}
    for group in ('workers','gpu'):
        values=actual.get(group,{})
        clean=normalized.get(group,{})
        for key,wanted in expected[group].items():
            raw=values.get(key) if isinstance(values,dict) else None
            check={'present':isinstance(values,dict) and key in values,
                   'observed_type':type(raw).__name__,
                   'matches':isinstance(clean,dict) and clean.get(key)==wanted}
            if key in ('min','max','idleTimeout','count') and type(raw) is int:check['observed_integer']=raw
            checks[group+'.'+key]=check
    return {'fields':checks,'arbitrary_provider_values_saved':False}


def verify_disabled(actual,expected):
    actual=normalized_config(actual)
    # No unknown/missing value becomes a safe default.
    if not isinstance(actual.get('workers'),dict) or not isinstance(actual.get('gpu'),dict):
        raise SetupError('Worker/GPU configuration is missing or malformed')
    if actual.get('entrypoint') not in (None,[]):raise SetupError('Unexpected container entrypoint')
    for key in ('name','type','image','registry','disk','cmd','ports','env','scaling','timeout','flashboot'):
        if actual.get(key)!=expected[key]:raise SetupError('Disabled endpoint read-back mismatch: '+key)
    for key,value in expected['workers'].items():
        received=actual.get('workers',{}).get(key)
        if type(received) is not int or received!=value:raise SetupError('Worker settings were not confirmed disabled: workers.'+key)
    for key,value in expected['gpu'].items():
        if actual.get('gpu',{}).get(key)!=value:raise SetupError('GPU constraints were not confirmed: gpu.'+key)
    if type(actual.get('gpu',{}).get('count')) is not int:raise SetupError('GPU count is not an integer')
    if (actual.get('mounts')!={'network':[],'global':[]} or actual.get('networkVolumes')!=[]
            or actual.get('dataCenterIds')!=[] or actual.get('cpu')):
        raise SetupError('Unexpected storage, CPU or placement configuration')


def verify_no_workers(response):
    summary=response.get('summary',{})
    if not isinstance(summary,dict):raise SetupError('Worker summary is missing or malformed')
    if response.get('workers')!=[] or any(type(summary.get(k)) is not int or summary[k]!=0
        for k in ('running','idle','initializing','throttled','unhealthy','total')):
        raise SetupError('Zero allocated workers was not confirmed')


def list_rows(api,path,key):
    rows=[];cursor=None;seen=set()
    for _ in range(20):
        page=api.call(path+('?' + urllib.parse.urlencode({'cursor':cursor}) if cursor else ''))
        if not isinstance(page.get(key),list):raise SetupError('Unexpected provider list; contents withheld')
        rows.extend(page[key])
        pagination=page.get('pagination',{})
        if not pagination.get('hasNextPage'):return rows
        cursor=pagination.get('nextCursor')
        if not isinstance(cursor,str) or cursor in seen:break
        seen.add(cursor)
    raise SetupError('Provider inventory pagination was not fully confirmed')


def billed_amount(response):
    try:
        value=Decimal(str(response['metadata']['totals']['totalAmount']))
        if not value.is_finite() or value<0:raise ValueError()
        return value
    except (KeyError,ValueError,TypeError,ArithmeticError):raise SetupError('Billing visibility was not confirmed') from None


EXTRA_DOLLAR_AUTHORIZATION='user_extra_usd1_compiler_fix_20261115'


def budget_policy(state):
    authorization=state.get('budget_authorization')
    if authorization is None:return Decimal('1.99'),Decimal('1.00'),Decimal('0.70')
    if authorization==EXTRA_DOLLAR_AUTHORIZATION:return Decimal('2.99'),Decimal('2.00'),Decimal('1.70')
    raise SetupError('Unknown budget authorization; no paid action permitted')


def account_for_history(amount,state):
    """Conservatively charge all observed history to this demo, never exclude it."""
    try:
        previous=Decimal(str(state.get('conservative_prior_spend_usd','0')))
        if not previous.is_finite() or previous<0:raise ValueError()
    except (ValueError,ArithmeticError):raise SetupError('Saved budget history is invalid') from None
    counted=max(amount,previous)
    ceiling,inference,_=budget_policy(state)
    remaining=ceiling-counted
    other=remaining-inference
    state.update(conservative_prior_spend_usd=str(counted),
                 experiment_planning_ceiling_usd=str(ceiling),inference_allowance_usd=str(inference),
                 remaining_total_allowance_usd=str(remaining),
                 remaining_training_and_other_allowance_usd=str(other),
                 historical_spend_excluded_usd='0')
    return other>=0


def audit_billing(api,response):
    """Read-only attribution. Save selected billing fields, never resource env/keys."""
    total=billed_amount(response)
    totals=response['metadata']['totals']
    groups={
        'Pods':(('podGpuAmount','podCpuAmount','podDiskAmount'),'pods','podId'),
        'Serverless':(('serverlessGpuAmount','serverlessCpuAmount','serverlessDiskAmount','serverlessFeeAmount'),'serverless','serverlessId'),
        'Public endpoints':(('endpointAmount',),'endpoints',None),
        'Network storage':(('storageStandardAmount','storageHighPerformanceAmount'),'network-volumes','networkVolumeId'),
        'Clusters':(('clusterGpuAmount','clusterDiskAmount','clusterNetworkingAmount'),'clusters','clusterId')}
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),
            'window':'last 30 day buckets, including current bucket',
            'reported_total_usd':str(total),'categories':{},'resources':[],
            'resources_changed':False,'billing_may_lag':True}
    for label,(fields,route,id_field) in groups.items():
        amounts=[]
        for field in fields:
            if field not in totals:raise SetupError('Aggregate billing breakdown is incomplete; no resources changed')
            amount=Decimal(str(totals[field]))
            if not amount.is_finite() or amount<0:raise SetupError('Invalid billing component; no resources changed')
            amounts.append(amount)
        subtotal=sum(amounts,Decimal(0));report['categories'][label]=str(subtotal)
        print(f'Reported 30-day {label}: ${subtotal}',flush=True)
        if not subtotal:continue
        detail=api.call('/v2/billing/'+route+'?lastN=30&bucketSize=day')
        records=detail.get('records')
        if not isinstance(records,list):raise SetupError('Billing resource attribution was not confirmed; no creates attempted')
        grouped={}
        for row in records:
            amount=Decimal(str(row.get('totalAmount','NaN')))
            if not amount.is_finite() or amount<0:raise SetupError('Invalid per-resource billing amount')
            if amount==0:continue
            rid=resource_id(row.get(id_field)) if id_field else 'public-endpoint-usage'
            entry=grouped.setdefault(rid,{'category':label,'resource_id':rid,'amount_usd':Decimal(0),'bucket_starts':set()})
            entry['amount_usd']+=amount
            timestamp=row.get('startTime')
            if isinstance(timestamp,str):
                # Normalize dates; never print arbitrary provider strings.
                entry['bucket_starts'].add(datetime.fromisoformat(timestamp.replace('Z','+00:00')).isoformat())
        for entry in grouped.values():
            entry['amount_usd']=str(entry['amount_usd']);entry['bucket_starts']=sorted(entry['bucket_starts'])
            report['resources'].append(entry)
    components=sum((Decimal(value) for value in report['categories'].values()),Decimal(0))
    if abs(components-total)>Decimal('0.000001'):
        raise SetupError('Aggregate billing components do not reconcile; no creates attempted')
    report['resources'].sort(key=lambda row:Decimal(row['amount_usd']),reverse=True)
    for entry in report['resources'][:10]:
        print(f"Billed source: {entry['category']} {entry['resource_id']} ${entry['amount_usd']} (UTC buckets: {', '.join(entry['bucket_starts'][:5])})",flush=True)
    if total and not report['resources']:raise SetupError('Positive account spend has no attributed billing records; no creates attempted')
    return report


def remove_unsafe_endpoint(api,state,journal):
    """Compensate only for the endpoint this operation just created."""
    eid=resource_id(state['endpoint_id'])
    state['phase']='unsafe_endpoint_cleanup_pending';save(journal,state)
    api.call('/v2/serverless/'+eid,'DELETE')
    if api.call('/v2/serverless/'+eid,missing_ok=True) is not None:
        raise SetupError('Endpoint removal was not confirmed. Check the saved endpoint ID immediately.')
    state['phase']='unsafe_endpoint_removed';save(journal,state)


def select_endpoint_name(state,endpoints,templates,journal):
    """Avoid retained inline-template names without mutating existing templates."""
    if state['endpoint_id'] is not None:return
    old=state['endpoint_name']
    # An endpoint with this name is not evidence of ownership. Never rename past
    # an ambiguous surviving endpoint and create a second one.
    if any(row.get('name')==old for row in endpoints):
        raise SetupError('An endpoint already uses the planned name. Reconcile its ownership before retrying.')
    error=state.get('request_error',{})
    rejected=(error.get('stage')=='create endpoint' and error.get('status')==400
              and 'endpoint template names must be unique' in str(error.get('detail','')).lower())
    collisions=[row for row in templates if row.get('name')==old]
    retired=state.get('endpoint_name_needs_rotation',False)
    if not (rejected or collisions or retired):return
    occupied={row.get('name') for row in [*endpoints,*templates]}
    history=state.setdefault('endpoint_name_history',[])
    occupied.update(entry['name'] for entry in history)
    occupied.add(old)
    for _ in range(10):
        name='policypilot-demo-'+secrets.token_hex(6)
        if name not in occupied:break
    else:raise SetupError('Could not reserve an unused endpoint/template name; no create attempted.')
    history.append({'name':old,
                    'reason':'duplicate_template_rejection' if rejected else 'removed_endpoint' if retired else 'template_name_collision',
                    'matching_template_ids':[resource_id(row.get('id')) for row in collisions],
                    'templates_changed':False})
    state['endpoint_name']=name
    state.pop('endpoint_name_needs_rotation',None)
    # Archive the rejection with the retired name. It must not rotate the new
    # name again if a subsequent read fails before the POST is attempted.
    if rejected:
        history[-1]['request_error']=state.pop('request_error')
    save(journal,state)
    print('PASS: reserved a fresh endpoint/template name: '+name+'. Existing templates left unchanged.',flush=True)


def provision(api,plan,account,journal,token_prompt=getpass.getpass):
    # Journal contains IDs/status only; never a provider key or registry token.
    if journal.exists():
        state=json.loads(journal.read_text())
        if state.get('phase') not in ('new','registry_verified','disabled_verified','unsafe_endpoint_removed'):
            raise SetupError('An earlier create is incomplete or uncertain. Inspect artifacts/runpod-disabled-setup.json and the console; no repeated create was attempted.')
    else:
        operation=secrets.token_hex(6)
        state={'operation':operation,'phase':'new','registry_name':'policypilot-ghcr-'+operation,
               'endpoint_name':'policypilot-demo-'+operation,'registry_id':None,'endpoint_id':None,
               'jobs_submitted':0,'compute_started':False}
        save(journal,state)
    if not re.fullmatch('[a-f0-9]{12}',state.get('operation','')):raise SetupError('Setup journal identity is invalid')
    if state['phase']=='unsafe_endpoint_removed':
        previous=resource_id(state['endpoint_id'])
        if api.call('/v2/serverless/'+previous,missing_ok=True) is not None:
            raise SetupError('Previously removed endpoint is visible again. No repeated create was attempted.')
        state.setdefault('removed_endpoint_ids',[]).append(previous)
        state['endpoint_id']=None;state['phase']='registry_verified'
        state['endpoint_name_needs_rotation']=True;save(journal,state)
        print('PASS: previous endpoint absence rechecked; reusing the owned registry credential.',flush=True)
    # Read before writes. Unrelated resources are never changed or reused.
    registries=list_rows(api,'/v2/registries','registries')
    endpoints=list_rows(api,'/v2/serverless','endpoints')
    templates=list_rows(api,'/v2/templates','templates')
    for rows,name,owned in ((registries,state['registry_name'],state['registry_id']),
                            (endpoints,state['endpoint_name'],state['endpoint_id'])):
        if any(row.get('name')==name and row.get('id')!=owned for row in rows):
            raise SetupError('A setup name already exists without a confirmed owned ID. No resource was changed.')
    select_endpoint_name(state,endpoints,templates,journal)
    billing_path='/v2/billing?lastN=30&bucketSize=day'
    billing=api.call(billing_path)
    before=billed_amount(billing)
    state['reported_account_30day_amount_before_usd']=str(before);save(journal,state)
    covered=account_for_history(before,state);save(journal,state)
    audit=audit_billing(api,billing);save(journal.with_name('runpod-billing-audit.json'),audit)
    print(f"Counted prior spend: ${state['conservative_prior_spend_usd']}; total allowance left: ${state['remaining_total_allowance_usd']}; $1 remains reserved for inference.",flush=True)
    if not covered:
        raise SetupError('Reported/counted history leaves less than the approved $1 inference reserve inside the $1.99 ceiling. No creates attempted; budget was not increased.')
    catalog=api.call('/v2/catalog/gpus?include=AVAILABILITY&product=SERVERLESS&cloud=SECURE&count=1&minCudaVersion=12.8')
    rows=[row for row in candidates(catalog) if row['pool']=='AMPERE_24']
    if not any(row['stock'] in ('LOW','MEDIUM','HIGH') for row in rows):raise SetupError('Selected pool has no confirmed stock; no create attempted')
    rate=max(Decimal(str(row['serverless_usd_per_hour'])) for row in rows)
    quoted=Decimal(str(plan['gpu']['conservative_serverless_usd_per_hour']))
    if rate>quoted:raise SetupError('GPU rate increased. Refresh the connection plan before creating anything.')
    print(f'GPU execution would cost up to ${rate}/hour before storage/tax. This setup requests min=max=0 and no volumes.',flush=True)
    print('Execution remains unverified and disabled; the $1 inference allowance is not a provider-enforced spending cap.',flush=True)
    if state['registry_id'] is None:
        token=token_prompt('Dedicated GitHub classic token with read:packages (hidden): ')
        if not token:raise SetupError('Registry token missing; no provider credential created')
        identity=github('/user',token)
        if str(identity.get('login','')).lower()!='aizen-hado':raise SetupError('Registry token belongs to another GitHub account')
        package=github('/users/aizen-hado/packages/container/policypilot-gpu',token)
        if package is None:raise SetupError('GPU package was not confirmed')
        assert_private(package)
        state['phase']='registry_create_pending';save(journal,state)
        try:
            created=api.call('/v2/registries','POST',{'name':state['registry_name'],'username':'AIZEN-Hado','password':token})
        except ProviderHTTPError as exc:
            state['request_error']={'stage':'create registry credential','status':exc.status,'detail':str(exc)}
            save(journal.with_name('runpod-request-error.json'),state['request_error'])
            if exc.status in (400,401,403,404,409,422):
                state['phase']='new';save(journal,state)
            raise
        state['registry_id']=resource_id(created.get('id'));save(journal,state)
        token=None
    registry=api.call('/v2/registries/'+resource_id(state['registry_id']))
    if registry.get('name')!=state['registry_name']:raise SetupError('Registry metadata read-back mismatch')
    if state['endpoint_id'] is None:
        state['phase']='registry_verified';save(journal,state)
    print('PASS: private registry credential metadata verified; its password is write-only.',flush=True)
    body=payload(plan,account,state['registry_id'],state['endpoint_name'])
    created_now=False
    if state['endpoint_id'] is None:
        state['phase']='endpoint_create_pending';save(journal,state)
        try:created=api.call('/v2/serverless','POST',body)
        except ProviderHTTPError as exc:
            state['request_error']={'stage':'create endpoint','status':exc.status,'detail':str(exc)}
            save(journal.with_name('runpod-request-error.json'),state['request_error'])
            if exc.status in (400,401,403,404,409,422):
                state['phase']='registry_verified';save(journal,state)
            raise
        state['endpoint_id']=resource_id(created.get('id'));save(journal,state)
        created_now=True
    eid=resource_id(state['endpoint_id'])
    stage='read endpoint configuration'
    report={'stage':stage}
    try:
        actual=api.call('/v2/serverless/'+eid)
        report.update(verification_report(actual,body))
        stage='verify endpoint configuration';report['stage']=stage
        verify_disabled(actual,body)
        stage='read allocated workers';report['stage']=stage
        worker_state=api.call('/v2/serverless/'+eid+'/workers')
        summary=worker_state.get('summary',{})
        report['worker_summary']={key:summary[key] for key in ('running','idle','initializing','throttled','unhealthy','total')
                                  if isinstance(summary,dict) and type(summary.get(key)) is int}
        report['worker_list_present']=isinstance(worker_state.get('workers'),list)
        if report['worker_list_present']:report['worker_list_count']=len(worker_state['workers'])
        stage='verify zero allocated workers';report['stage']=stage
        verify_no_workers(worker_state)
        report['result']='PASS';save(journal.with_name('runpod-disabled-verification.json'),report)
    except SetupError as exc:
        reason=str(exc)  # Our static errors and HTTP codes; never provider bodies.
        report.update(result='CHECK',stage=stage,error=reason)
        save(journal.with_name('runpod-disabled-verification.json'),report)
        state['verification_error']=reason;state['verification_stage']=stage;save(journal,state)
        print('Verification detail: '+stage+': '+reason,flush=True)
        if not created_now:
            raise SetupError('Previously created endpoint is no longer confirmed disabled or reachable. No endpoint changes were attempted; inspect its current settings.') from None
        remove_unsafe_endpoint(api,state,journal)
        raise SetupError('Verification failed: '+reason+'. The endpoint was removed and absence verified; the registry credential remains. Saved safe diagnostics in artifacts/runpod-disabled-verification.json.') from None
    state.update(phase='disabled_verified',verified_at=datetime.now(timezone.utc).isoformat(),
                 image=body['image'],model_revision=plan['model']['revision'],
                 conservative_serverless_usd_per_hour=str(rate))
    save(journal,state)
    # A post-create read is evidence, not a claim that delayed billing is final.
    after=billed_amount(api.call(billing_path))
    state['reported_account_30day_amount_after_usd']=str(after);save(journal,state)
    if after!=before:raise SetupError('Reported billing changed. Endpoint remains min=max=0; reconcile before any execution.')
    return state


def restore_timeouts(api,state,expected,destination,apply=False):
    """Repair only timeout drift on the verified, disabled owned endpoint."""
    if state.get('phase')!='disabled_verified':raise SetupError('Verified disabled endpoint journal required')
    endpoint=resource_id(state['endpoint_id']);route='/v2/serverless/'+endpoint
    actual=api.call(route)
    if actual.get('id')!=endpoint:raise SetupError('Endpoint identity mismatch')
    if not isinstance(actual.get('workers'),dict):raise SetupError('Worker configuration missing; no timeout repair attempted')
    # Validate every other field and explicit zero limits before allowing writes.
    check=dict(actual)
    check['workers']=dict(actual.get('workers',{}))
    check['timeout']=expected['timeout'];check['workers']['idleTimeout']=expected['workers']['idleTimeout']
    verify_disabled(check,expected)
    verify_no_workers(api.call(route+'/workers'))
    before={'execution_timeout_ms':actual.get('timeout'),'idle_timeout_seconds':actual.get('workers',{}).get('idleTimeout')}
    before={key:value if type(value) is int and 0<=value<=604800000 else None for key,value in before.items()}
    changed=(actual.get('timeout')!=180000 or actual.get('workers',{}).get('idleTimeout')!=300)
    report={'endpoint_id':endpoint,'recorded_at':datetime.now(timezone.utc).isoformat(),
            'before':before,'desired':{'execution_timeout_ms':180000,'idle_timeout_seconds':300},
            'apply_requested':apply,'write_attempted':False,'verified':False,'jobs_submitted':0}
    save(destination,report)
    if apply and changed:
        report['write_attempted']=True;save(destination,report)
        # Sparse PATCH preserves min/max and all unrelated endpoint settings.
        api.call(route,'PATCH',{'timeout':180000,'workers':{'idleTimeout':300}})
    if apply or not changed:
        after=api.call(route)
        if after.get('id')!=endpoint:raise SetupError('Endpoint identity mismatch after repair')
        verify_disabled(after,expected);verify_no_workers(api.call(route+'/workers'))
        report['verified']=True
    save(destination,report)
    if json.loads(destination.read_text())!=report:raise SetupError('Timeout repair report read-back mismatch')
    return report


def update_image(api,state,plan,account,new_image,journal,plan_path,destination,apply=False):
    """Change only the pinned image on the owned endpoint with no allocated workers."""
    image_pattern=r'ghcr\.io/aizen-hado/policypilot-gpu@sha256:[a-f0-9]{64}'
    if (state.get('phase')!='disabled_verified'
            or not isinstance(new_image,str) or not re.fullmatch(image_pattern,new_image)):
        raise SetupError('Verified endpoint journal and published GPU digest required')
    endpoint=resource_id(state['endpoint_id']);route='/v2/serverless/'+endpoint
    old=state.get('image')
    previous=json.loads(destination.read_text()) if destination.exists() else {}
    # A saved intent allows read-only reconciliation after an uncertain PATCH or
    # interruption between the two local receipt writes. Never repeat a paid job.
    if previous.get('endpoint_id')==endpoint and previous.get('desired_image')==new_image:
        old=previous.get('before_image')
    if (not isinstance(old,str) or not re.fullmatch(image_pattern,old)
            or state.get('image') not in (old,new_image) or plan.get('image') not in (old,new_image)):
        raise SetupError('Local image receipts disagree; no endpoint change attempted')
    if old==new_image:raise SetupError('GPU image is unchanged; build and publish the diagnostic worker first')
    expected=payload(plan,account,state['registry_id'],state['endpoint_name'])
    if state.get('model_revision')!=plan['model']['revision']:
        raise SetupError('Local model revision receipts disagree')
    actual=api.call(route)
    if actual.get('id')!=endpoint or actual.get('image') not in (old,new_image):
        raise SetupError('Endpoint identity or current image mismatch')
    expected['image']=actual['image']
    verify_disabled(actual,expected);verify_no_workers(api.call(route+'/workers'))
    report={'endpoint_id':endpoint,'recorded_at':datetime.now(timezone.utc).isoformat(),
            'before_image':old,'desired_image':new_image,'apply_requested':apply,
            'write_attempted':False,'provider_verified':False,'local_receipts_verified':False,
            'jobs_submitted':0,'reservations_changed':False}
    save(destination,report)
    if apply:
        if actual['image']!=new_image:
            report['write_attempted']=True;save(destination,report)
            api.call(route,'PATCH',{'image':new_image})
        expected['image']=new_image
        after=api.call(route)
        if after.get('id')!=endpoint:raise SetupError('Endpoint identity mismatch after image update')
        verify_disabled(after,expected);verify_no_workers(api.call(route+'/workers'))
        report['provider_verified']=True;save(destination,report)
        # Persist only after fresh provider read-back. Existing budget history,
        # model pin and all unrelated local fields are preserved.
        state['image']=new_image;plan['image']=new_image
        save(journal,state);save(plan_path,plan)
        if json.loads(journal.read_text())!=state or json.loads(plan_path.read_text())!=plan:
            raise SetupError('Image receipt read-back mismatch; retain update report for recovery')
        report['local_receipts_verified']=True
    save(destination,report)
    if json.loads(destination.read_text())!=report:raise SetupError('Image update report read-back mismatch')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply',action='store_true',help='Create only the disabled registry/endpoint configuration')
    parser.add_argument('--restore-timeouts',action='store_true',help='Inspect or restore only execution/idle timeouts on the existing disabled endpoint; never creates resources')
    parser.add_argument('--update-image',action='store_true',help='Use the published GPU digest on the existing zero-worker endpoint; no jobs or budget changes')
    args=parser.parse_args()
    if args.restore_timeouts and args.update_image:raise SetupError('Select only one endpoint update mode')
    plan=json.loads((ROOT/'artifacts/runpod-connection-plan.json').read_text())
    private=credentials(ROOT/'deploy/cloud.env')
    if args.update_image:
        state=json.loads((ROOT/'artifacts/runpod-disabled-setup.json').read_text())
        published=json.loads((ROOT/'artifacts/published-images.json').read_text())
        images=[row for row in published.get('images',[]) if row.get('name')=='policypilot-gpu']
        if published.get('namespace')!='aizen-hado' or len(images)!=1 or images[0].get('visibility')!='private':
            raise SetupError('Exactly one published private GPU image is required')
        destination=ROOT/'artifacts/runpod-image-update.json'
        with (ROOT/'artifacts/runpod-disabled-setup.lock').open('a') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:raise SetupError('Another local setup operation is active') from None
            report=update_image(API(private['RUNPOD_API_KEY']),state,plan,private['R2_ACCOUNT_ID'],
                images[0].get('reference'),ROOT/'artifacts/runpod-disabled-setup.json',
                ROOT/'artifacts/runpod-connection-plan.json',destination,args.apply)
        print(json.dumps(report,indent=2))
        print('Saved and verified:',destination)
        if args.apply:print('PASS: new GPU image, min=max=0, zero workers and local image receipts verified. No inference tested.')
        else:print('Preview only; add --apply to update only this endpoint image.')
        print('No resource created, worker started, job submitted or reservation changed.')
        return
    if args.restore_timeouts:
        state=json.loads((ROOT/'artifacts/runpod-disabled-setup.json').read_text())
        expected=payload(plan,private['R2_ACCOUNT_ID'],state['registry_id'],state['endpoint_name'])
        destination=ROOT/'artifacts/runpod-timeout-repair.json'
        with (ROOT/'artifacts/runpod-disabled-setup.lock').open('a') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:raise SetupError('Another local setup operation is active') from None
            report=restore_timeouts(API(private['RUNPOD_API_KEY']),state,expected,destination,args.apply)
        print(json.dumps(report,indent=2))
        print('Saved and verified:',destination)
        print('No resource created, worker started, job submitted or budget reservation added.')
        if args.apply:print('PASS: execution timeout 180 seconds, idle timeout 300 seconds, min=max=0 and zero workers verified.')
        else:print('Preview only; add --apply to restore these timeout settings.')
        return
    schema=json.loads((ROOT/'artifacts/runpod-openapi.json').read_text())
    for path in ('/v2/serverless','/v2/registries'):
        if 'post' not in schema.get('paths',{}).get(path,{}):raise SetupError('Saved provider create schema is missing; run prepare_runpod.py again')
    body=payload(plan,private['R2_ACCOUNT_ID'],'REGISTRY_ID_FROM_CREATE','policypilot-demo-PREVIEW')
    preview=ROOT/'artifacts/runpod-disabled-request.json';save(preview,body)
    print('Saved disabled create-request preview:',preview,flush=True)
    if not args.apply:
        print('Preview only. Use --apply to create the disabled configuration; no job will be submitted.')
        return
    if not sys.stdin.isatty():raise SetupError('Run --apply in an interactive terminal for hidden registry-token entry')
    lock_path=ROOT/'artifacts/runpod-disabled-setup.lock'
    with lock_path.open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SetupError('Another setup process holds the lock; no concurrent create attempted') from None
        state=provision(API(private['RUNPOD_API_KEY']),plan,private['R2_ACCOUNT_ID'],ROOT/'artifacts/runpod-disabled-setup.json')
    settings={'RUNPOD_ENDPOINT_ID':state['endpoint_id'],'RUNPOD_MODEL':MODEL,
              'RUNPOD_ARTIFACT_REVISION':state['model_revision'],'ENABLE_MODEL_CONTROL':'0',
              'RUNPOD_INFERENCE_BUDGET_APPROVED':'0',
              'RUNPOD_VERIFIED_HOURLY_RATE_USD':state['conservative_serverless_usd_per_hour'],
              'RUNPOD_SESSION_COMPUTE_LIMIT_USD':'0.70',
              'PROCESSING_BACKEND':'runpod',
              'note':'Separate endpoint invocation/control keys are still required. Do not put the broad setup key in Render.'}
    path=ROOT/'artifacts/runpod-render-settings.json';save(path,settings)
    print('PASS: endpoint configuration read back with min=0, max=0, no volumes and zero allocated workers.')
    print('Endpoint ID:',state['endpoint_id'])
    print('Saved non-secret Render settings:',path)
    print('No inference submitted. Private image pull, CUDA, generation and model RAM are NOT verified.')
    print('Keep ENABLE_MODEL_CONTROL=0. Do not delete local images until a real provider pull succeeds.')


if __name__=='__main__':
    try:main()
    except (SetupError,PreparationError,PublishError) as exc:raise SystemExit('CHECK: '+str(exc)) from None
    except (OSError,ValueError,KeyError,TypeError,ArithmeticError,EOFError,KeyboardInterrupt):
        raise SystemExit('CHECK: setup interrupted or local data invalid. Details withheld. Inspect artifacts/runpod-disabled-setup.json and the console before retrying; a create might have succeeded.') from None
