"""Settle explicitly matched closed holds against padded wall-time bounds; no GPU jobs."""
import argparse
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_CEILING
import fcntl
import getpass
import hashlib
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'deploy'))
from create_runpod_disabled import API, SetupError, save, payload, billed_amount, account_for_history
from prepare_runpod import credentials, PreparationError
from rehearse_model import Web, number, safe_app_state, long_startup_reservation, BILLING
from reconcile_warmup import timestamp, provider_idle
from inspect_runpod_attempt import runtime_read

NAMES=('runpod-warmup-activation.json','runpod-warmup-long-startup.json')


def audit_action(proposal):
    return 'closed_warmup_settlement_v1:'+hashlib.sha256(json.dumps(proposal,sort_keys=True).encode()).hexdigest()


def bounds(root,state,expected):
    if long_startup_reservation(root,state,expected)!=Decimal('.58125'):
        raise SetupError('Complete earlier reservation history required')
    rows=[];hashes={}
    for index,name in enumerate(NAMES):
        raw=(root/'artifacts'/name).read_bytes();attempt=json.loads(raw)
        elapsed=number(attempt.get('elapsed_seconds'))
        rate=number(attempt.get('gpu_rate_usd_per_hour'))
        prior=Decimal('.4625') if index==0 else Decimal('.58125')
        app=attempt.get('shutdown_app_status',{})
        if (attempt.get('endpoint_id')!=state['endpoint_id']
                or attempt.get('model_revision')!=expected['env']['MODEL_REVISION']
                or attempt.get('start_attempted') is not True
                or attempt.get('generation_verified') is not False
                or attempt.get('provider_shutdown_verified') is not True
                or attempt.get('app_shutdown_verified') is not True
                or attempt.get('deadline_seconds')!=360 or not Decimal(0)<elapsed<Decimal(300)
                or rate!=Decimal('.75') or rate!=number(state['conservative_serverless_usd_per_hour'])
                or number(attempt.get('prior_compute_reserved_usd'))!=prior
                or number(app.get('demo_compute_reserved_usd'))!=prior+Decimal('.11875')
                or app.get('state')!='off' or app.get('enabled') is not False):
            raise SetupError('Closed warm-up evidence or reserved amounts do not match')
        seconds=elapsed.to_integral_value(rounding=ROUND_CEILING)+60
        retained=(seconds*rate/3600).quantize(Decimal('.000001'),rounding=ROUND_CEILING)
        rows.append({'report':name,'recorded_at':timestamp(attempt['recorded_at']).isoformat(),
                     'elapsed_seconds':str(elapsed),'padded_seconds':int(seconds),
                     'original_reserved_usd':'0.118750','retained_bound_usd':str(retained),
                     'required_job_state':'STARTUP_FAILED' if index==0 else 'FAILED'})
        hashes[name]=hashlib.sha256(raw).hexdigest()
    retained=sum((number(row['retained_bound_usd']) for row in rows),Decimal(0))
    credit=Decimal('.2375')-retained
    after=Decimal('.70')-credit
    if not Decimal(0)<credit<Decimal('.2375') or after+Decimal('.11875')>Decimal('.70'):
        raise SetupError('Conservative settlement cannot cover one diagnostic attempt')
    return {'endpoint_id':state['endpoint_id'],'model_revision':expected['env']['MODEL_REVISION'],
            'rows':rows,'source_sha256':hashes,'reserved_before_usd':'0.700000',
            'reserved_after_usd':str(after),'released_unused_hold_usd':str(credit),
            'original_job_reservations_preserved':True,'compute_limit_usd':'0.700000',
            'inference_total_usd':'1.000000','bounds_are_invoice_amounts':False}


def paused_bounds(root,state,expected):
    original=bounds(root,state,expected)
    previous=json.loads((root/'artifacts/runpod-closed-warmup-settlement.json').read_text())
    if (previous.get('result')!='PASS' or previous.get('database_committed') is not True
            or previous.get('endpoint_id')!=state['endpoint_id'] or previous.get('proposal')!=original
            or previous.get('audit_action')!=audit_action(original)
            or number(previous.get('observed_reserved_usd'))!=number(original['reserved_after_usd'])):
        raise SetupError('The original committed settlement must match its complete receipt history')
    names=('runpod-warmup-startup-fix.json','runpod-warmup-diagnostic.json')
    records=[];hashes={}
    for name in names:
        raw=(root/'artifacts'/name).read_bytes();records.append(json.loads(raw))
        hashes[name]=hashlib.sha256(raw).hexdigest()
    paused,diagnostic=records
    before=number(original['reserved_after_usd'])+Decimal('.11875')
    for attempt,prior,after in ((paused,Decimal('.2125'),Decimal('.31875')),
                                (diagnostic,number(original['reserved_after_usd']),before)):
        app=attempt.get('shutdown_app_status',{})
        if (attempt.get('endpoint_id')!=state['endpoint_id']
                or attempt.get('model_revision')!=expected['env']['MODEL_REVISION']
                or attempt.get('start_attempted') is not True or attempt.get('generation_verified') is not False
                or attempt.get('provider_shutdown_verified') is not True or attempt.get('app_shutdown_verified') is not True
                or attempt.get('deadline_seconds')!=360 or not Decimal(0)<number(attempt.get('elapsed_seconds'))<360
                or number(attempt.get('gpu_rate_usd_per_hour'))!=Decimal('.75')
                or number(attempt.get('prior_compute_reserved_usd'))!=prior
                or number(app.get('demo_compute_reserved_usd'))!=after
                or app.get('state')!='off' or app.get('enabled') is not False):
            raise SetupError('Paused attempt and latest diagnostic must have matched bounded shutdown receipts')
    if paused.get('provider_diagnostic')!='Runpod submit: HTTP 409 (ENDPOINT_PAUSED); reconcile before retrying paid work':
        raise SetupError('The historical paused rejection was not confirmed')
    if diagnostic.get('failure_stage')!='warmup_status_read':
        raise SetupError('Latest diagnostic failure does not match the recorded loader attempt')
    seconds=number(paused['elapsed_seconds']).to_integral_value(rounding=ROUND_CEILING)+60
    retained=(seconds*Decimal('.75')/3600).quantize(Decimal('.000001'),rounding=ROUND_CEILING)
    credit=Decimal('.10625')-retained;after=before-credit
    if not 0<credit<Decimal('.10625') or after+Decimal('.11875')>Decimal('.70'):
        raise SetupError('Paused hold cannot cover one diagnostic within the unchanged cap')
    row={'report':names[0],'recorded_at':timestamp(paused['recorded_at']).isoformat(),
         'elapsed_seconds':str(number(paused['elapsed_seconds'])),'padded_seconds':int(seconds),
         'original_reserved_usd':'0.106250','retained_bound_usd':str(retained),
         'required_job_state':'REJECTED_PAUSED','require_no_provider_id':True}
    check={'report':names[1],'recorded_at':timestamp(diagnostic['recorded_at']).isoformat(),
           'padded_seconds':int(number(diagnostic['elapsed_seconds']).to_integral_value(rounding=ROUND_CEILING))+60,
           'original_reserved_usd':'0.118750','required_job_state':'FAILED','minimum_age_seconds':0,
           'require_provider_id':True}
    return {'endpoint_id':state['endpoint_id'],'model_revision':expected['env']['MODEL_REVISION'],
            'rows':[row],'validation_only_rows':[check],'source_sha256':hashes,
            'reserved_before_usd':str(before),'reserved_after_usd':str(after),
            'released_unused_hold_usd':str(credit),'required_prior_audit_action':audit_action(original),
            'original_job_reservations_preserved':True,'compute_limit_usd':'0.700000',
            'inference_total_usd':'1.000000','bounds_are_invoice_amounts':False}


def settle(conn,app,proposal,idle_check,apply=False):
    if conn.execute('SELECT pg_try_advisory_xact_lock(519826) AS acquired').fetchone()['acquired'] is not True:
        raise SetupError('App model operation is in progress')
    control=conn.execute('SELECT *,now() AS db_now FROM model_control WHERE id=1 FOR UPDATE').fetchone()
    ledger=conn.execute('SELECT * FROM inference_allowance WHERE id=1 FOR UPDATE').fetchone()
    if not (app.get('configured') is True and app.get('operator') is True
            and app.get('state')=='off' and app.get('enabled') is False
            and control and control.get('phase')=='off' and control.get('enabled') is False
            and ledger and number(ledger['approved_total_usd'])==1
            and number(ledger['compute_reservation_limit_usd'])==Decimal('.70')
            and number(app.get('demo_inference_allowance_usd'))==1
            and number(app.get('compute_allowance_usd'))==Decimal('.70')
            and number(app.get('demo_compute_reserved_usd'))==number(ledger['compute_reserved_usd'])
            and abs((timestamp(app.get('started_at'))-timestamp(control.get('started_at'))).total_seconds())<1):
        raise SetupError('Live app, database, off state and unchanged allowances must match')
    if conn.execute("SELECT 1 FROM model_jobs WHERE state=ANY(%s) LIMIT 1",
                    (['pending','submitted','IN_QUEUE','IN_PROGRESS','uncertain'],)).fetchone():
        raise SetupError('Outstanding model jobs block settlement')
    if proposal.get('required_prior_audit_action') and not conn.execute(
            'SELECT id FROM events WHERE action=%s LIMIT 1',(proposal['required_prior_audit_action'],)).fetchone():
        raise SetupError('Previous settlement audit is missing from this database')
    action=audit_action(proposal)
    event=conn.execute('SELECT id FROM events WHERE action=%s LIMIT 1',(action,)).fetchone()
    if event:
        if not number(proposal['reserved_after_usd'])<=number(ledger['compute_reserved_usd'])<=Decimal('.70'):
            raise SetupError('Previously settled ledger no longer agrees with audit')
        idle_check()
        return {'already_applied':True,'audit_action':action,'database_update_prepared':False,
                'observed_reserved_usd':str(ledger['compute_reserved_usd'])}
    if number(ledger['compute_reserved_usd'])!=number(proposal['reserved_before_usd']):
        raise SetupError('Expected exact pre-settlement ledger; no settlement performed')
    ids=[]
    checked_rows=proposal['rows']+proposal.get('validation_only_rows',[])
    for row in checked_rows:
        began=timestamp(row['recorded_at'])
        jobs=conn.execute("SELECT id,provider_id,kind,state,case_id,generation,created_at,reserved_compute_usd, "
            "payload->>'task' AS task,payload->>'request_id' AS request_id, "
            "payload->>'artifact_revision' AS artifact_revision FROM model_jobs "
            "WHERE created_at>=%s AND created_at<=%s ORDER BY created_at FOR UPDATE",
            (began-timedelta(seconds=5),began+timedelta(seconds=120))).fetchall()
        if len(jobs)!=1:raise SetupError('Each closed warm-up must identify exactly one database job')
        job=jobs[0]
        if (job['state']!=row['required_job_state'] or job['kind']!='warmup' or job['case_id'] is not None
                or job['task']!='warmup' or job['request_id']!=str(job['id'])
                or job['artifact_revision']!=proposal['model_revision']
                or number(job['reserved_compute_usd'])!=number(row['original_reserved_usd'])
                or (row.get('require_no_provider_id') is True and job.get('provider_id') is not None)
                or (row.get('require_provider_id') is True and not job.get('provider_id'))
                or type(job['generation']) is not int or job['generation']>=control['generation']
                or timestamp(control['db_now'])<began+timedelta(seconds=row['padded_seconds']+row.get('minimum_age_seconds',900))):
            raise SetupError('Closed job identity, terminal state or safety interval mismatch')
        ids.append(str(job['id']))
    if len(set(ids))!=len(checked_rows):raise SetupError('Settlement jobs must be distinct')
    idle_check()  # Fresh zero-worker/zero-queue reads while holding the app lock.
    result={'already_applied':False,'audit_action':action,'database_update_prepared':False,
            'job_ids':ids,'observed_reserved_usd':proposal['reserved_before_usd']}
    if apply:
        updated=conn.execute('UPDATE inference_allowance SET compute_reserved_usd=%s '
            'WHERE id=1 AND compute_reserved_usd=%s RETURNING compute_reserved_usd',
            (number(proposal['reserved_after_usd']),number(proposal['reserved_before_usd']))).fetchone()
        if not updated or number(updated['compute_reserved_usd'])!=number(proposal['reserved_after_usd']):
            raise SetupError('Settlement update did not match; transaction must roll back')
        conn.execute('INSERT INTO events(case_id,action,actor) VALUES(NULL,%s,%s)',
                     (action,'operator-budget-settlement'))
        result.update(database_update_prepared=True,observed_reserved_usd=proposal['reserved_after_usd'])
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('origin');parser.add_argument('--apply',action='store_true')
    parser.add_argument('--paused-hold',action='store_true',help='Settle only the verified historical paused-rejection hold after the first diagnostic')
    args=parser.parse_args()
    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError:raise SetupError('Run inside the existing API Docker image for psycopg') from None
    if not sys.stdin.isatty():raise SetupError('Interactive hidden credential prompts required')
    state=json.loads((ROOT/'artifacts/runpod-disabled-setup.json').read_text())
    plan=json.loads((ROOT/'artifacts/runpod-connection-plan.json').read_text())
    private=credentials(ROOT/'deploy/cloud.env')
    expected=payload(plan,private['R2_ACCOUNT_ID'],state['registry_id'],state['endpoint_name'])
    proposal=paused_bounds(ROOT,state,expected) if args.paused_hold else bounds(ROOT,state,expected)
    total=sum((number(row['original_reserved_usd']) for row in proposal['rows']),Decimal(0))
    print('Closed holds: $'+str(total)+'; retained padded wall-time bounds: $'+
          str(total-number(proposal['released_unused_hold_usd'])))
    print('Ledger: $'+proposal['reserved_before_usd']+' -> $'+proposal['reserved_after_usd']+
          '. Limits remain $0.70 compute / $1 inference; no job reservations are erased.')
    web=Web(args.origin);report={'proposal':proposal,'recorded_at':datetime.now(timezone.utc).isoformat(),
        'endpoint_id':state['endpoint_id'],'result':'CHECK','database_committed':False,
        'provider_resources_changed':False,'jobs_submitted':0,'apply_requested':args.apply}
    destination=ROOT/'artifacts'/('runpod-paused-hold-settlement.json' if args.paused_hold else 'runpod-closed-warmup-settlement.json')
    try:
        username=input('Pilot username [reviewer]: ').strip() or 'reviewer'
        password=getpass.getpass('Pilot password (hidden): ');web.login(username,password);password=None
        app=web.call('/api/model/status')
        if app.get('model')!=expected['env']['MODEL_REPOSITORY']:raise SetupError('App model mismatch')
        inference=getpass.getpass('RUNPOD_INFERENCE_KEY from Render (hidden): ').strip()
        if not inference or inference==private['RUNPOD_API_KEY']:raise SetupError('Dedicated inference key required')
        dsn=getpass.getpass('Render database External Database URL (hidden): ').strip()
        parsed=urlsplit(dsn)
        if parsed.scheme not in ('postgres','postgresql') or not (parsed.hostname or '').endswith('.render.com'):
            raise SetupError('Use the Render external database URL')
        api=API(private['RUNPOD_API_KEY'])
        def idle():provider_idle(api,lambda:runtime_read(state['endpoint_id'],inference,'health'),state['endpoint_id'],expected)
        with (ROOT/'artifacts/runpod-disabled-setup.lock').open('a') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:raise SetupError('Another local operation is active') from None
            amount=billed_amount(api.call(BILLING))
            if not account_for_history(amount,state):raise SetupError('Account spend leaves insufficient total allowance')
            save(ROOT/'artifacts/runpod-disabled-setup.json',state)
            report['account_30day_reported_usd']=str(amount);save(destination,report)
            with psycopg.connect(dsn,row_factory=dict_row,connect_timeout=10,sslmode='require',
                    options='-c statement_timeout=15000 -c idle_in_transaction_session_timeout=180000') as conn:
                with conn.transaction():
                    report.update(settle(conn,app,proposal,idle,args.apply));save(destination,report)
            report['database_committed']=args.apply or report.get('already_applied') is True
            save(destination,report)
            idle();after=web.call('/api/model/status');report['app_after']=safe_app_state(after)
            if (after.get('state')!='off' or after.get('enabled') is not False
                    or number(after.get('demo_compute_reserved_usd'))!=number(report['observed_reserved_usd'])):
                raise SetupError('Post-settlement app read-back mismatch; do not start compute')
            report['result']='PASS';save(destination,report)
            if json.loads(destination.read_text())!=report:raise SetupError('Settlement artifact read-back mismatch')
            print('PASS: closed warm-ups verified; provider disabled and idle; no GPU job submitted.')
            print('Reserved compute: $'+report['observed_reserved_usd']+'. Budget limits unchanged.')
            print('Saved and verified:',destination)
            if not args.apply:print('Preview only; add --apply to release just the unused padded holds.')
    except Exception as exc:
        save(destination,report)
        if isinstance(exc,SetupError):raise
        raise SetupError('Settlement database/network check failed; details withheld. Rerun settlement to inspect its audit before paid work.') from None
    finally:
        try:web.call('/api/auth/logout','POST')
        except Exception:pass


if __name__=='__main__':
    try:main()
    except (SetupError,PreparationError) as exc:raise SystemExit('CHECK: '+str(exc)) from None
    except (OSError,ValueError,KeyError,TypeError,EOFError,KeyboardInterrupt):
        raise SystemExit('CHECK: settlement interrupted or local evidence invalid; details withheld. No paid retry.') from None
