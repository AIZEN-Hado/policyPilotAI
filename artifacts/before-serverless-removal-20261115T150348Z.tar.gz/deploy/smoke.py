"""External live test: authentication, CSRF, upload, OCR/model pipeline and persistence.
Run only against your own deployment. Password is read interactively, never via argv.
"""
import argparse
import base64
import getpass
import http.cookiejar
import json
from pathlib import Path
import time
import urllib.error
import urllib.parse
import urllib.request

parser=argparse.ArgumentParser()
parser.add_argument('origin',help='https://claims.your-domain.example')
parser.add_argument('--case',choices=['SYN-C001','SYN-C003'],default='SYN-C001')
parser.add_argument('--auth-mode',choices=['session','proxy'],default='session')
parser.add_argument('--run-inference',action='store_true',help='Explicitly invoke potentially billable inference; requires a separately verified budget')
args=parser.parse_args()
origin=args.origin.rstrip('/')
parsed=urllib.parse.urlsplit(origin)
if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment:
    raise SystemExit('An exact HTTPS origin is required')
user=input('Pilot username [reviewer]: ').strip() or 'reviewer'
password=getpass.getpass('Pilot password: ')
auth=base64.b64encode((user+':'+password).encode()).decode()
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): return None
cookies=http.cookiejar.CookieJar()
opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookies),NoRedirect())
anonymous=urllib.request.build_opener(NoRedirect())

def request(path,method='GET',body=None,content='application/json',authenticated=True,csrf=True,raw=False):
    headers={'Content-Type':content}
    if authenticated and args.auth_mode=='proxy': headers['Authorization']='Basic '+auth
    if csrf: headers['Origin']=origin
    req=urllib.request.Request(origin+path,data=body,headers=headers,method=method)
    with (opener if authenticated else anonymous).open(req,timeout=30) as r:
        data=r.read()
        return data if raw else json.loads(data) if data else None

try: request('/api/cases',authenticated=False)
except urllib.error.HTTPError as e:
    assert e.code==401,'Unauthenticated access was not denied'
else: raise AssertionError('Unauthenticated access succeeded')
if args.auth_mode=='session':
    request('/api/auth/login','POST',json.dumps({'username':user,'password':password}).encode())
    assert request('/api/auth/me')['username']==user,'Server-side identity did not match'
    password=None; auth=None
try: request('/api/cases','POST',b'{}',csrf=False)
except urllib.error.HTTPError as e: assert e.code==403,'Missing Origin was not denied'
else: raise AssertionError('CSRF boundary failed')
if args.run_inference:
    ready=request('/api/readiness')
    assert ready['inference'] in {'ready','model_registered_not_generation_tested'},'Private model not registered'
case=request('/api/cases','POST',json.dumps({'title':'Live verification '+args.case,'description':'Review this fictional hospitalization claim against its attached policy and identify missing or conflicting evidence.'}).encode())
cid=case['id']
root=Path(__file__).resolve().parents[1]/'data/synthetic/exemplars'/args.case
kinds={'01':'schedule','02':'policy','03':'endorsement','04':'other','05':'discharge','06':'bill','07':'receipt','08':'other','09':'other'}
pdfs=sorted(root.glob('*.pdf'))
assert pdfs,'Synthetic bundle is missing'
for pdf in pdfs:
    query=urllib.parse.urlencode({'kind':kinds[pdf.name[:2]],'filename':pdf.name})
    request(f'/api/cases/{cid}/documents?{query}','PUT',pdf.read_bytes(),'application/pdf')
if not args.run_inference:
    row=request('/api/cases/'+cid)
    assert len(row['documents'])==len(pdfs),'Uploaded documents missing'
    for doc in row['documents']:
        content=request(f'/api/cases/{cid}/documents/'+doc['id'],raw=True)
        assert content==(root/doc['filename']).read_bytes(),'Downloaded PDF differs'
    request('/api/cases/'+cid,'DELETE')
    try: request('/api/cases/'+cid)
    except urllib.error.HTTPError as exc: assert exc.code==404
    else: raise AssertionError('Deleted case is still accessible')
    if args.auth_mode=='session':
        request('/api/auth/logout','POST')
        try: request('/api/cases')
        except urllib.error.HTTPError as exc: assert exc.code==401
        else: raise AssertionError('Logged-out access succeeded')
    print('PASS: authentication, origin rejection, synthetic upload/download, case deletion and logout. No inference invoked.')
    print('File removal remains queued; verify worker cleanup and bucket deletion separately.')
    raise SystemExit(0)
request(f'/api/cases/{cid}/assess','POST')
print('Authentication and upload checks passed. Waiting for actual local processing…')
deadline=time.monotonic()+900
while time.monotonic()<deadline:
    row=request('/api/cases/'+cid)
    if row['state']=='failed': raise SystemExit('Live processing failed: '+row['error']+'; case retained for inspection')
    if row['state']=='ready': break
    time.sleep(5)
else: raise SystemExit('Processing exceeded 15 minutes; case retained for inspection')
assert row['result']['model'],'Missing model provenance'
assert row['result']['total_pages']>0,'No processed pages'
assert row['result']['findings'],'No source-backed findings; inspect the retained case'
if args.case=='SYN-C003': assert row['result']['ocr_pages']>=1,'Image-only PDF did not exercise OCR'
assert any(e['action']=='private_inference_started' for e in row['events'])
request(f'/api/cases/{cid}/review','POST')
row=request('/api/cases/'+cid)
assert any(e['action']=='draft_review_acknowledged_not_coverage_authorization' for e in row['events'])
print('Live pipeline passed. Case retained for browser inspection:',cid)
print('Also restart services and verify this case persists before release.')
