"""Read-only failed-attempt inspection. No jobs, scaling, cancellations or refunds."""
import argparse
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import getpass
import json
from pathlib import Path
import re
import sys
import time
import urllib.error
import urllib.request
from urllib.parse import urlencode

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'deploy'))
from create_runpod_disabled import API, SetupError, ProviderHTTPError, save, resource_id, billed_amount
from prepare_runpod import credentials, PreparationError, NoRedirect
sys.path.insert(0,str(ROOT))
from pilot.worker_diagnostics import safe_record


def runtime_read(endpoint, token, operation):
    if operation not in ('health','requests'): raise SetupError('Only read-only diagnostics are allowed')
    url = 'https://api.runpod.ai/v2/'+resource_id(endpoint)+'/'+operation
    request = urllib.request.Request(url, method='GET', headers={
        'Authorization':'Bearer '+token, 'Accept':'application/json'})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    try:
        with opener.open(request, timeout=20) as response:
            raw=response.read(4*1024*1024+1)
            if len(raw)>4*1024*1024: raise ValueError()
            data=json.loads(raw)
            if not isinstance(data,(dict,list)): raise ValueError()
            return data
    except urllib.error.HTTPError as exc:
        raise ProviderHTTPError('Runtime diagnostic read rejected; body withheld', exc.code) from None
    except (OSError, ValueError):
        raise SetupError('Runtime diagnostic read unavailable; details withheld') from None


def counts(data, groups):
    result={}
    if not isinstance(data,dict): return result
    for group, fields in groups.items():
        values=data.get(group)
        if not isinstance(values,dict): continue
        result[group]={key:values[key] for key in fields if type(values.get(key)) is int and values[key]>=0}
    return result


def request_summary(data, revision):
    # The list response can vary. Unknown/missing lists never become empty lists.
    rows=data if isinstance(data,list) else None
    if isinstance(data,dict):
        for key in ('requests','jobs','data'):
            if isinstance(data.get(key),list): rows=data[key]; break
    report={'history_completeness_verified':False, 'raw_inputs_outputs_errors_saved':False}
    if rows is None:
        report['list_shape_recognized']=False
        return report
    report.update(list_shape_recognized=True, returned_rows=len(rows), requests=[])
    for row in rows[:100]:
        if not isinstance(row,dict): continue
        item={}
        identifier=row.get('id')
        if isinstance(identifier,str) and re.fullmatch(r'(?:sync-)?[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}(?:-[a-z][0-9]+)?',identifier):
            item['id']=identifier
        if row.get('status') in ('IN_QUEUE','IN_PROGRESS','COMPLETED','FAILED','CANCELLED','TIMED_OUT'):
            item['status']=row['status']
        for key in ('delayTime','executionTime'):
            if type(row.get(key)) is int and row[key]>=0: item[key]=row[key]
        value=row.get('input')
        item['matches_pinned_warmup']=isinstance(value,dict) and value.get('task')=='warmup' and value.get('artifact_revision')==revision
        if isinstance(value,dict) and isinstance(value.get('request_id'),str) and re.fullmatch(
                r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}',value['request_id']):
            item['app_request_id']=value['request_id']
        if 'error' in row: item['error_present']=True
        report['requests'].append(item)
    return report


def inspect(api, runtime, state):
    endpoint=resource_id(state['endpoint_id'])
    report={'endpoint_id':endpoint, 'recorded_at':datetime.now(timezone.utc).isoformat(),
            'read_only':True, 'resources_changed':False, 'requests_submitted':0,
            'management_credential_role':'local_setup_key',
            'runtime_credential_role':'dedicated_inference_key_entered_at_hidden_prompt',
            'historical_absence_proven':False, 'dedicated_inference_key_permissions_verified':False}
    operations=(('configuration',lambda:api.call('/v2/serverless/'+endpoint)),
                ('allocated_workers',lambda:api.call('/v2/serverless/'+endpoint+'/workers')),
                ('billing',lambda:api.call('/v2/billing?lastN=30&bucketSize=day')),
                ('health',lambda:runtime('health')),
                ('request_history',lambda:runtime('requests')))
    for name, action in operations:
        try:
            data=action()
            if name=='configuration': report[name]=counts(data,{'workers':('min','max','idleTimeout')})
            elif name=='allocated_workers': report[name]=counts(data,{'summary':('running','idle','initializing','throttled','unhealthy','total')})
            elif name=='billing': report['reported_account_30day_usd']=str(billed_amount(data))
            elif name=='health': report[name]=counts(data,{
                'workers':('idle','initializing','ready','running','throttled','unhealthy'),
                'jobs':('completed','failed','inProgress','inQueue','retried')})
            else: report[name]=request_summary(data,state['model_revision'])
        except (SetupError,ValueError,TypeError,KeyError) as exc:
            report[name]={'read_verified':False}
            if isinstance(exc,ProviderHTTPError): report[name]['http_status']=exc.status
    return report


def conflict_audit(api,state,attempt):
    """Read the historical control changes; never recreate the failed request."""
    endpoint=resource_id(state['endpoint_id'])
    if (attempt.get('endpoint_id')!=endpoint or attempt.get('failure_stage')!='start_request'
            or attempt.get('provider_diagnostic')!='Runpod submit: HTTP 409; reconcile before retrying paid work'):
        raise SetupError('Expected the saved follow-up submission conflict for this endpoint')
    began=datetime.fromisoformat(attempt['recorded_at'])
    if began.tzinfo is None: raise SetupError('Attempt timestamp must include timezone')
    window={'startTime':(began-timedelta(minutes=2)).isoformat(),
            'endTime':(began+timedelta(minutes=10)).isoformat()}
    report={'endpoint_id':endpoint,'recorded_at':datetime.now(timezone.utc).isoformat(),
            'read_only':True,'resources_changed':False,'requests_submitted':0,
            'window':window,'audit_entries':[],'audit_complete':False,
            'original_rejection_reason_verified':False}
    query={**window,'search':endpoint,'limit':100}
    for _ in range(3):
        try:
            data=api.call('/v2/audit-logs?'+urlencode(query))
        except SetupError as exc:
            report['audit_read_verified']=False
            if isinstance(exc,ProviderHTTPError):report['audit_http_status']=exc.status
            return report
        rows=data.get('auditLogs')
        if not isinstance(rows,list):
            report['audit_shape_recognized']=False
            return report
        report['audit_read_verified']=True
        for row in rows:
            if not isinstance(row,dict) or row.get('resourceId')!=endpoint:continue
            item={}
            try:
                stamp=datetime.fromisoformat(row['timestamp'].replace('Z','+00:00'))
                if stamp.tzinfo is not None:item['timestamp']=stamp.isoformat()
            except (KeyError,ValueError,TypeError,AttributeError):pass
            if row.get('action') in ('create','update','delete','pause','resume','scale'):
                item['action']=row['action']
            value=row.get('value')
            if isinstance(value,str):
                try:value=json.loads(value)
                except ValueError:value=None
            if isinstance(value,dict):
                workers=value.get('workers')
                if isinstance(workers,dict):
                    item['workers']={key:workers[key] for key in ('min','max','idleTimeout')
                                     if type(workers.get(key)) is int and workers[key]>=0}
                # Some audit producers retain the legacy field names.
                for key in ('workersMin','workersMax','idleTimeout'):
                    if type(value.get(key)) is int and value[key]>=0:item[key]=value[key]
            report['audit_entries'].append(item)
        paging=data.get('pagination',{})
        if paging.get('hasNextPage') is False:
            report['audit_complete']=True
            break
        cursor=paging.get('nextCursor')
        if not isinstance(cursor,str) or not cursor or len(cursor)>4096:break
        query['cursor']=cursor
    return report


def routing_check(api,state):
    endpoint=resource_id(state['endpoint_id'])
    value=api.call('/v2/serverless/'+endpoint)
    if value.get('id')!=endpoint:raise SetupError('Endpoint identity mismatch')
    urls=value.get('requestUrls')
    advertised=isinstance(urls,dict)
    urls=urls if advertised else {}
    suffixes={'run':'/run','health':'/health','status':'/status/{job_id}','cancel':'/cancel/{job_id}'}
    comparisons={name:{'present':isinstance(urls.get(name),str),
                       'matches_client':urls.get(name)=='https://api.runpod.ai/v2/'+endpoint+suffix}
                 for name,suffix in suffixes.items()}
    return {'endpoint_id':endpoint,'recorded_at':datetime.now(timezone.utc).isoformat(),
            'read_only':True,'resources_changed':False,'requests_submitted':0,
            'provider_urls_present':advertised,'url_comparisons':comparisons,
            'all_client_routes_match':all(row['present'] and row['matches_client'] for row in comparisons.values()),
            'configuration':counts(value,{'workers':('min','max','idleTimeout')})}


LOG_SIGNALS={
    'sdk_start_banner':r'starting serverless worker',
    'image_pull_activity':r'pulling|downloading|extracting.*(?:layer|image)',
    'image_pull_failure':r'imagepullbackoff|errimagepull|failed to pull|pull access denied|manifest unknown',
    'access_rejection':r'unauthorized|forbidden|permission denied|authentication required',
    'disk_full':r'no space left on device|disk quota exceeded',
    'out_of_memory':r'out of memory|oomkilled|cuda.*out of memory',
    'cuda_driver_error':r'cuda.*(?:driver|not available|initialization error)|nvidia.*(?:not found|error)',
    'python_import_failure':r'modulenotfounderror|importerror|cannot import name',
    'network_failure':r'connection refused|name resolution|network is unreachable|connection timed out',
    'error_or_traceback':r'\berror\b|traceback|fatal|exception',
}


def log_signals(event):
    # Raw logs can contain URLs and injected worker credentials. Never save them.
    if not isinstance(event,dict) or not isinstance(event.get('line'),str):return None
    result={'signals':[label for label,pattern in LOG_SIGNALS.items()
                       if re.search(pattern,event['line'],re.IGNORECASE)]}
    diagnostic=safe_record(event['line'])
    if diagnostic is not None:
        result['worker_diagnostic']=diagnostic
        result['signals'].append('worker_diagnostic')
    if event.get('source') in ('container','system'):result['source']=event['source']
    try:
        stamp=datetime.fromisoformat(event.get('ts','').replace('Z','+00:00'))
        if stamp.tzinfo is not None:result['timestamp']=stamp.astimezone(timezone.utc).isoformat()
    except (ValueError,TypeError,AttributeError):pass
    return result


def worker_log_read(api,state,worker,source,clock=time.monotonic,duration=20):
    endpoint=resource_id(state['endpoint_id']);worker=resource_id(worker)
    if source not in ('system','container'):raise SetupError('Invalid fixed log source')
    request=urllib.request.Request('https://api.runpod.io/v2/serverless/'+endpoint+'/workers/'+worker+
        '/logs?source='+source+'&tail=200',method='GET',headers={'Authorization':'Bearer '+api.token,'Accept':'text/event-stream'})
    result={'source':source,'records_seen':0,'events':[],'raw_logs_saved':False,'read_complete':False}
    if type(duration) is not int or not 1<=duration<=20:raise SetupError('Invalid log read duration')
    end=clock()+duration;total=0
    try:
        with api.opener.open(request,timeout=min(10,duration)) as response:
            if response.headers.get('Content-Type','').split(';')[0].strip()!='text/event-stream':
                result.update(read_verified=False,stream_format_unrecognized=True)
                return result
            while clock()<end and result['records_seen']<200:
                raw=response.readline(65537);total+=len(raw)
                if not raw:
                    result['read_complete']=True
                    break
                if len(raw)>65536 or total>2*1024*1024:break
                if not raw.startswith(b'data:'):continue
                try:event=json.loads(raw[5:].strip())
                except (ValueError,UnicodeError):continue
                safe=log_signals(event)
                if safe is not None:
                    result['records_seen']+=1
                    if 'timestamp' in safe:
                        result.setdefault('first_observed_timestamp',safe['timestamp'])
                        result['last_observed_timestamp']=safe['timestamp']
                    if safe['signals']:result['events'].append(safe)
    except urllib.error.HTTPError as exc:
        result.update(read_verified=False,http_status=exc.code);exc.close()
        return result
    except TimeoutError:
        result['stream_timed_out']=True
        # A live stream may idle after the historical backfill. Keep observations.
    except (OSError,ValueError):
        result['read_verified']=False
        return result
    result['read_verified']=True
    return result


def billing_check(api,state):
    """Read reported charges only; never treat a lagging bill as a refund."""
    endpoint=resource_id(state['endpoint_id'])
    account=billed_amount(api.call('/v2/billing?lastN=30&bucketSize=day'))
    data=api.call('/v2/billing/serverless?'+urlencode({
        'serverlessId':endpoint,'lastN':120,'bucketSize':'hour'}))
    total=billed_amount(data)
    rows=data.get('records')
    if not isinstance(rows,list):raise SetupError('Endpoint billing records unavailable')
    selected=[];summed=Decimal('0')
    for row in rows:
        if not isinstance(row,dict) or row.get('serverlessId')!=endpoint:
            raise SetupError('Endpoint billing identity mismatch')
        amount=billed_amount({'metadata':{'totals':{'totalAmount':row.get('totalAmount')}}})
        summed+=amount
        if amount:
            stamp=datetime.fromisoformat(row['startTime'].replace('Z','+00:00'))
            if stamp.tzinfo is None:raise SetupError('Billing timestamp timezone missing')
            selected.append({'start_time_utc':stamp.astimezone(timezone.utc).isoformat(),
                             'total_usd':str(amount)})
    if abs(summed-total)>Decimal('0.000001'):
        raise SetupError('Endpoint billing totals disagree with records')
    return {'endpoint_id':endpoint,'recorded_at':datetime.now(timezone.utc).isoformat(),
            'read_only':True,'resources_changed':False,'requests_submitted':0,
            'reservations_changed':False,'billing_may_lag':True,
            'account_30day_reported_usd':str(account),
            'endpoint_last_120_hour_buckets_reported_usd':str(total),
            'nonzero_hour_buckets':selected,'automatic_refund_or_budget_reset':False}


def main(argv=()):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--conflict-audit',action='store_true',help='Read historical worker-limit changes for the saved HTTP 409; no credential prompts')
    parser.add_argument('--routing',action='store_true',help='Compare provider-advertised request URLs with the fixed client URLs; GET only, no prompts')
    parser.add_argument('--billing',action='store_true',help='Read account and endpoint charges without changing reservations; GET only, no prompts')
    parser.add_argument('--worker-logs',nargs='?',const='PROMPT',help='Read a known worker ID from historical logs; no allocation or job requests')
    args=parser.parse_args(argv)
    if sum((bool(args.worker_logs),args.routing,args.conflict_audit,args.billing))>1:raise SetupError('Select only one read-only inspection mode')
    state=json.loads((ROOT/'artifacts/runpod-disabled-setup.json').read_text())
    private=credentials(ROOT/'deploy/cloud.env')
    if args.billing:
        report=billing_check(API(private['RUNPOD_API_KEY']),state)
        destination=ROOT/'artifacts/runpod-billing-reconciliation-read.json'
        save(destination,report)
        if json.loads(destination.read_text())!=report:raise SetupError('Billing report read-back mismatch')
        print(json.dumps(report,indent=2))
        print('Saved and verified:',destination)
        print('No compute started, job submitted, reservation refunded or allowance changed. Billing may lag.')
        return
    if args.worker_logs:
        worker=input('Worker ID copied from the log entry (not a key): ').strip() if args.worker_logs=='PROMPT' else args.worker_logs
        worker=resource_id(worker)
        api=API(private['RUNPOD_API_KEY'])
        report={'endpoint_id':state['endpoint_id'],'worker_id':worker,
                'recorded_at':datetime.now(timezone.utc).isoformat(),'resources_changed':False,
                'requests_submitted':0,'raw_logs_saved':False,'log_sources':[]}
        for source in ('system','container'):
            result=worker_log_read(api,state,worker,source)
            report['log_sources'].append(result)
            if result.get('read_verified') is not True:break
        destination=ROOT/'artifacts'/('runpod-worker-log-signals-'+worker+'.json')
        save(destination,report)
        if json.loads(destination.read_text())!=report:raise SetupError('Worker log report read-back mismatch')
        print(json.dumps(report,indent=2))
        print('Saved and verified:',destination)
        print('Only fixed log-pattern labels/timestamps saved. No workers started or jobs submitted; patterns are not a confirmed diagnosis.')
        return
    if args.routing:
        report=routing_check(API(private['RUNPOD_API_KEY']),state)
        destination=ROOT/'artifacts/runpod-routing-verification.json'
        save(destination,report)
        if json.loads(destination.read_text())!=report:raise SetupError('Routing report read-back mismatch')
        print(json.dumps(report,indent=2))
        print('Saved and verified:',destination)
        print('No worker started, job submitted or reservation added. URL equality does not prove inference readiness.')
        return
    if args.conflict_audit:
        attempt=json.loads((ROOT/'artifacts/runpod-warmup-followup.json').read_text())
        report=conflict_audit(API(private['RUNPOD_API_KEY']),state,attempt)
        destination=ROOT/'artifacts/runpod-conflict-audit.json'
        save(destination,report)
        if json.loads(destination.read_text())!=report:raise SetupError('Audit artifact verification failed')
        print(json.dumps(report,indent=2))
        print('Saved and verified:',destination)
        print('No job submitted or resource changed. Audit settings do not prove runtime propagation or the original rejection reason.')
        return
    if not sys.stdin.isatty(): raise SetupError('Run in an interactive terminal for hidden inference-key entry')
    print('Paste the dedicated RUNPOD_INFERENCE_KEY used in Render, not the setup or control key.')
    inference_key=getpass.getpass('RUNPOD_INFERENCE_KEY (hidden): ').strip()
    if not inference_key or inference_key==private['RUNPOD_API_KEY']:
        raise SetupError('A dedicated inference key is required; no provider reads attempted')
    api=API(private['RUNPOD_API_KEY'])
    report=inspect(api,lambda operation:runtime_read(state['endpoint_id'],inference_key,operation),state)
    destination=ROOT/'artifacts/runpod-attempt-inspection.json'
    save(destination,report)
    print(json.dumps(report,indent=2))
    print('Saved safe read-only report:',destination)
    print('No job submitted or resource changed. An empty history is not proof the original request was never accepted.')


if __name__=='__main__':
    try: main(sys.argv[1:])
    except (SetupError,PreparationError) as exc: raise SystemExit('CHECK: '+str(exc)) from None
    except (OSError,ValueError,KeyError,TypeError,EOFError,KeyboardInterrupt):
        raise SystemExit('CHECK: local diagnostic data invalid; details withheld. No resources changed.') from None
