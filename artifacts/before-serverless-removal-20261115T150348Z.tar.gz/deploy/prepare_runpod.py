"""Read-only Runpod connection plan. No provisioning, jobs, or secret output."""
from datetime import datetime,timezone
import json
import math
import os
from pathlib import Path
import re
import shlex
import sys
import urllib.error
import urllib.request
import urllib.parse

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from deploy.preflight_live import candidates
MODEL='Qwen/Qwen2.5-7B-Instruct'


class PreparationError(Exception):pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None


class PublicModelRedirect(urllib.request.HTTPRedirectHandler):
    max_repeats=2
    max_redirections=3

    def redirect_request(self,req,fp,code,msg,headers,newurl):
        destination=urllib.parse.urlsplit(newurl)
        if (destination.scheme=='https' and destination.netloc=='huggingface.co'
                and not destination.fragment):
            return super().redirect_request(req,fp,code,msg,headers,newurl)
        return None


def credentials(path):
    """Parse only named assignments; never execute or expand shell content."""
    names=('RUNPOD_API_KEY','R2_ACCOUNT_ID')
    values={name:os.environ[name] for name in names if os.environ.get(name)}
    if path.exists():
        if path.stat().st_mode & 0o077:
            raise PreparationError('deploy/cloud.env must have owner-only permissions: chmod 600 deploy/cloud.env')
        for line in path.read_text().splitlines():
            line=line.strip().removeprefix('export ')
            name,separator,raw=line.partition('=')
            if separator and name in names and name not in values:
                tokens=shlex.split(raw,comments=True)
                if len(tokens)!=1:raise PreparationError('A required credential assignment has invalid syntax; values withheld.')
                values[name]=tokens[0]
    if not values.get('RUNPOD_API_KEY'):
        raise PreparationError('RUNPOD_API_KEY is missing from deploy/cloud.env and the environment.')
    if not re.fullmatch('[a-fA-F0-9]{32}',values.get('R2_ACCOUNT_ID','')):
        raise PreparationError('R2_ACCOUNT_ID is missing or invalid; value withheld.')
    return values


def get_json(url,label,token=None):
    if token and not url.startswith(('https://api.runpod.io/','https://rest.runpod.io/')):
        raise PreparationError('Refusing to send the Runpod credential to another host.')
    headers={'Accept':'application/json','User-Agent':'PolicyPilot-ConnectionPreparation'}
    if token:headers['Authorization']='Bearer '+token
    redirects=PublicModelRedirect() if token is None and url.startswith('https://huggingface.co/') else NoRedirect()
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),redirects)
    try:
        with opener.open(urllib.request.Request(url,headers=headers),timeout=30) as response:
            raw=response.read(8*1024*1024+1)
            if len(raw)>8*1024*1024:raise ValueError()
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        raise PreparationError(f'{label}: HTTP {exc.code}. Response body withheld. No resources changed.') from None
    except (OSError,ValueError):
        raise PreparationError(f'{label}: network or response error. No resources changed.') from None


def model_details(metadata,index):
    if (not isinstance(metadata,dict) or metadata.get('id')!=MODEL
            or metadata.get('gated') not in (False,None) or metadata.get('private') is not False
            or metadata.get('disabled') is True
            or not re.fullmatch('[a-f0-9]{40}',str(metadata.get('sha','')))):
        raise PreparationError('Public model identity, access or immutable revision could not be confirmed.')
    parameters=metadata.get('safetensors',{}).get('total')
    size=index.get('metadata',{}).get('total_size') if isinstance(index,dict) else None
    if type(parameters) is not int or not 7_000_000_000<=parameters<=9_000_000_000:
        raise PreparationError('Model parameter count is outside the requested 7–9B range.')
    if type(size) is not int or size<=0:raise PreparationError('Model weight size is not confirmed.')
    return {'repository':MODEL,'revision':metadata['sha'],'parameters':parameters,
            'weight_file_bytes':size,'quantized_weight_bytes_lower_bound':math.ceil(parameters/2),
            'format':'safetensors','load_format':'bitsandbytes NF4, 4-bit',
            'release_kind':'upstream_instruct_baseline_not_PolicyPilot_fine_tune',
            'model_process_ram_below_2000000000_bytes':'unverified; measurement required'}


def image_reference(report):
    for image in report.get('images',[]):
        if image.get('name')=='policypilot-gpu' and image.get('visibility')=='private':
            value=image.get('reference','')
            if re.fullmatch(r'ghcr\.io/aizen-hado/policypilot-gpu@sha256:[a-f0-9]{64}',value):return value
    raise PreparationError('Verified private GPU image reference is missing; no rebuild or upload was attempted.')


def main():
    private=credentials(ROOT/'deploy/cloud.env')
    counts={}
    # Access verification precedes all other provider work. Reads only.
    for kind in ('pods','endpoints'):
        data=get_json('https://rest.runpod.io/v1/'+kind,'Runpod '+kind,private['RUNPOD_API_KEY'])
        if not isinstance(data,list):raise PreparationError('Unexpected resource list; contents withheld.')
        counts[kind]=len(data)
        print(f'PASS: Runpod {kind} read access; {len(data)} existing resources.')
    catalog=get_json('https://api.runpod.io/v2/catalog/gpus?include=AVAILABILITY&product=SERVERLESS&cloud=SECURE&count=1&minCudaVersion=12.8',
                     'Serverless catalog',private['RUNPOD_API_KEY'])
    rows=[row for row in candidates(catalog) if row['pool']=='AMPERE_24']
    stocked=[row for row in rows if row['stock'] in ('LOW','MEDIUM','HIGH')]
    if not stocked:raise PreparationError('No confirmed AMPERE_24 stock at CUDA floor 12.8. No resource was created.')
    rate=max(row['serverless_usd_per_hour'] for row in rows)
    print(f'PASS: one AMPERE_24 worker candidate; conservative current GPU rate ${rate:.4f}/hour before storage/tax.')
    metadata=get_json('https://huggingface.co/api/models/'+MODEL,'Model metadata')
    revision=metadata.get('sha','') if isinstance(metadata,dict) else ''
    if not re.fullmatch('[a-f0-9]{40}',str(revision)):raise PreparationError('No immutable model revision returned.')
    index=get_json(f'https://huggingface.co/{MODEL}/resolve/{revision}/model.safetensors.index.json','Pinned weight index')
    model=model_details(metadata,index)
    image=image_reference(json.loads((ROOT/'artifacts/published-images.json').read_text()))
    print(f"PASS: upstream baseline {model['parameters']:,} parameters; weights {model['weight_file_bytes']/1e9:.2f} GB; revision {revision}.")
    # Capture the public schema for reviewing exact create fields before any write.
    schema=get_json('https://api.runpod.io/v2/openapi.json','Runpod public API schema')
    if not isinstance(schema,dict) or not isinstance(schema.get('paths'),dict):
        raise PreparationError('Provider schema could not be validated; no provisioning attempted.')
    folder=ROOT/'artifacts';folder.mkdir(exist_ok=True)
    (folder/'runpod-openapi.json').write_text(json.dumps(schema)+'\n')
    plan={'artifact_type':'read_only_connection_plan_not_deployed',
          'checked_at':datetime.now(timezone.utc).isoformat(),'resource_counts':counts,
          'image':image,'model':model,'gpu':{'pool':'AMPERE_24','count':1,'minCudaVersion':'12.8',
                    'conservative_serverless_usd_per_hour':rate,
                    'stock':[{k:row[k] for k in ('gpu','stock')} for row in stocked]},
          'proposed_disabled_settings':{'name':'policypilot-demo','workers':{'min':0,'max':0,'idleTimeout':300},
                    'timeout':180000,'flashboot':'OFF','network_volumes':[],'container_disk_gb':30},
          'worker_env':{'MODEL_REPOSITORY':MODEL,'MODEL_REVISION':revision,
                    'HF_HOME':'/tmp/huggingface','RUNPOD_INIT_TIMEOUT':'180',
                    'DOCUMENT_DOWNLOAD_HOST':private['R2_ACCOUNT_ID'].lower()+'.r2.cloudflarestorage.com'},
          'budget':{'inference_total_allowance_usd':1,'compute_reservations_usd':0.70,
                    'overhead_reserve_usd':0.30,'combined_experiment_ceiling_usd':1.99,
                    'provider_hard_dollar_cap_verified':False},
          'ready_for_paid_execution':False,
          'remaining_gates':['review provider schema and disabled endpoint configuration',
                    'verify initialization, retries, storage/tax, account billing and stop controls',
                    'verify private registry pull with a bounded supervised test',
                    'measure model-process RAM; no compliance claim before measurement',
                    'fine-tuning and trained artifact verification remain separate'],
          'compute_started':False,'resources_created':False}
    path=folder/'runpod-connection-plan.json';path.write_text(json.dumps(plan,indent=2)+'\n')
    print('Saved connection plan:',path)
    print('Saved public API schema:',folder/'runpod-openapi.json')
    print('Base model only: no PolicyPilot fine-tuning is claimed. GPU RAM/RSS remains unmeasured.')
    print('No compute started, jobs submitted, or resources changed. Keep ENABLE_MODEL_CONTROL=0 in Render.')


if __name__=='__main__':
    try:main()
    except PreparationError as exc:raise SystemExit('CHECK: '+str(exc)) from None
    except (OSError,ValueError,KeyError,TypeError):
        raise SystemExit('CHECK: local configuration or response validation failed; details withheld. No resources changed.') from None
