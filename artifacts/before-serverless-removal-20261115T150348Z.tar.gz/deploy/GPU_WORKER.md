# App-controlled GPU worker

## Active: compiler-fixed test with explicitly approved extra dollar

Compiler-fixed image 537c877f3c2fce36265cf360f4e9ff8e2ff92d19fe81680e5a55313672a105c2
was uploaded/applied, provider/local image receipts verified, at 14:37:46Z.
The user then explicitly approved USD 1 more. Keep all $0.678335 reservations.
No more closed-hold settlements are needed. New limits: $2.99 total planning
ceiling, $2 inference total, $1.70 compute and the original $0.30 overhead provision.
Admission accounting is not a provider-enforced spending cap; reported billing
can lag. Latest report is $0.6198162269574823 at 14:38:54Z.

In the existing Render service Environment, set and save/deploy:

```text
RUNPOD_SESSION_COMPUTE_LIMIT_USD=1.70
ENABLE_MODEL_CONTROL=1
RUNPOD_INFERENCE_BUDGET_APPROVED=1
```

Do not click Start while applying the allowance. No API/GPU image build is needed
for these environment/helper changes. From the repository directory, run:

```sh
docker run --rm -it --user "$(id -u):$(id -g)" \
  -v "$PWD:/work:ro" -v "$PWD/artifacts:/work/artifacts:rw" \
  -w /work --entrypoint python policypilot-api:demo \
  deploy/extend_inference_budget.py https://policypilot-demo.onrender.com --apply
```

Hidden prompts use the same app password, dedicated inference key and Render
external database URL; no new keys. The setup key is read locally. Without --apply,
the helper previews after the same live checks. It checks prior audit, exact
original limits and retained holds, matched FAILED compiler job with provider ID,
no outstanding jobs, app/DB session match, current billing and zero workers/jobs
under the shared advisory lock. It sets only approved_total_usd=2 and
compute_reservation_limit_usd=1.70, preserves every hold/job, and adds a unique
audit. A repeated/lost-response invocation verifies the audit without granting
another dollar. Receipt: artifacts/runpod-extra-dollar-authorization.json.
The setup authorization marker is saved only after confirmed database commit.

Only after PASS, run:

```sh
python deploy/rehearse_model.py https://policypilot-demo.onrender.com \
  --run-warmup --compiler-fix
```

This requires the exact reviewed compiler-fixed digest and committed extension
receipt. It submits one synthetic warm-up and reserves $0.118750, cumulative
$0.797085 under $1.70. Existing six-minute watchdog, app Stop and independent
provider zero-worker read-back remain in force. Keep the terminal/network open
through shutdown. It cannot repeat runpod-warmup-compiler-fix.json once Start
was attempted. Safe logs: runpod-compiler-fix-workers.json; sanitized failures
print as Worker diagnostic and are embedded in the report. Do not run the old
rehearsal flags or old settlement commands below. Failure means stop without a
paid retry. No generation, fine-tune or final RAM claim is established yet.

## Compiler repair reopened by user — 2026-11-15

The user subsequently requests one last repair of the captured C compiler error.
This narrow current instruction supersedes the retirement history below. The GPU
Dockerfile now installs gcc/libc6-dev after the cached pip layer, sets
CC=/usr/bin/gcc and runs python -m pilot.compiler_check as the non-root worker.
That probe uses Triton's own C builder to compile/load a tiny synthetic Python
extension and checks that it returns 42. It needs no GPU, model weights or network.
The same compiler probe runs before bitsandbytes imports during GPU warm-up.

Run one command at a time and stop on failure:

```sh
docker buildx build --platform linux/amd64 --load -f deploy/gpu.Dockerfile -t policypilot-gpu:demo .
docker run --rm --network none --entrypoint python policypilot-gpu:demo -m pilot.compiler_check
python deploy/publish_images.py AIZEN-Hado --only gpu --version v0.1.0-demo.20261110T202218Z
python deploy/create_runpod_disabled.py --update-image --apply
```

These steps do not start a GPU or submit jobs. A successful build/runtime compiler
check establishes the repaired C compiler/header/extension-loading path, not GPU
quantization, generation, fine-tuning or model memory. The authoring session
cannot build because its Docker daemon socket is denied. No dependency versions,
Render settings or budget limits changed. Retained reservations are $0.678335,
leaving only $0.021665 under the $0.70 compute cap. A standard $0.118750 warm-up
must not be run yet. Review current spend and audit closed holds before preparing
any paid test; preserve all old run-once reports.

Upstream C builder reference:
https://github.com/triton-lang/triton/blob/v3.3.1/python/triton/runtime/build.py

## Historical retirement decision — superseded for the compiler repair

The final loader-diagnostic attempt failed at check_quantizer: the
bitsandbytes/Triton path could not find a C compiler. Provider and app shutdown
were both verified. The user explicitly abandoned Serverless. The setup/build/
settlement/rehearsal commands below are historical; do not execute them again.
No further Serverless image repair, paid retry or replacement endpoint is
authorized. Keep the evidence and original budget history.

Set ENABLE_MODEL_CONTROL=0 in the existing Render service and save/deploy to
retire browser Start controls. That live configuration change remains unverified.
The active next direction is synthetic-data fine-tuning with held-out evaluation;
see docs/IMPLEMENTATION_PLAN.md. No trained artifact or successful inference exists.

Status: user reports local API/GPU builds and a GPU-handler import check completed;
both private images were published and digest references saved. The user also
reports the live Render web smoke passed for authentication and synthetic storage.
The latest warm-up reached the handler, then failed behind the old generic error
wrapper. Provider/app shutdown was verified. Successful generation, CUDA model
loading and process RAM remain unverified. No fine-tuned artifact exists yet.
Use synthetic documents only. Do not enable paid controls before verifying budget
and access. See `docs/IMPLEMENTATION_PLAN.md` for the full sequence.

## Diagnostic worker update — 2026-11-15

The local handler emits allowlisted stages and failure categories. RuntimeError
from model loading or the synthetic quantizer check additionally includes a
bounded reason with environment secrets, credentials, URLs and private paths
redacted, plus library file/line locations without locals or source lines. No
document/prompt/generation error text qualifies. This requires a new
GPU image; it cannot recover the underlying cause of an earlier generic error.
Run these commands in order, proceeding only when each succeeds:

```sh
cd /home/aizen/Downloads/PolicyPilotAI_ollama
docker buildx build --platform linux/amd64 --load -f deploy/gpu.Dockerfile -t policypilot-gpu:demo .
docker run --rm --network none --entrypoint python policypilot-gpu:demo -m unittest pilot.tests.test_worker_diagnostics -q
python deploy/publish_images.py AIZEN-Hado --only gpu --version v0.1.0-demo.20261110T202218Z
python deploy/create_runpod_disabled.py --update-image --apply
```

The build can reuse cached dependency layers; do not clear the cache. The test
has no GPU or network and does not download/load model weights. The publisher
prompts for a GitHub classic token with read:packages and write:packages; never
paste that token in chat. It preserves the API reference for the same version.

The latest worker also runs a tiny 64x64 synthetic NF4 CUDA layer and finite-output
check before downloading full model weights. It checks that bitsandbytes loaded
its CUDA native backend. This is part of an explicitly budgeted warm-up only,
never a read-only health check. No actual GPU kernel execution has yet been
verified. Dependency versions remain pinned; no speculative upgrade was made.
Offline CPU checks passed for tiny Qwen2 checkpoint reload and opening the
installed libbitsandbytes_cuda126.so; those checks cannot establish GPU behavior.

The image updater uses the published GPU digest automatically, validates the
owned endpoint's complete stopped configuration and zero allocated workers,
PATCHes only image, then freshly verifies configuration/workers before updating
the local connection-plan and setup image receipts. A saved intent permits
reconciliation of an uncertain PATCH without resubmitting jobs. No worker is
started, no job submitted, no model revision changed and no budget refunded.
The report is artifacts/runpod-image-update.json. Without --apply it previews
after provider reads; it still requires a newly published GPU digest.

No Render image/environment update is needed for this worker-only change.
Do not run Start or another rehearsal as part of this image update: the current
$0.70 compute reservation must first be settled as described below. The user-reported billing read at
2026-11-15T13:34:19Z shows account $0.6084335183986695 and target endpoint
$0.05193229205906391 (one nonzero 21:00 UTC bucket on November 14). Billing can
lag; this does not establish zero cost for November 15 or justify a ledger reset.
Keep the existing $1 inference and under-$2 total limits.

### Loader-reason worker deployed; settle paused hold, then one diagnostic

User verified the newer GPU image at 2026-11-15T14:06:50Z, digest
5c4c20537587ab0317ac7515b7fcf94f9d5e1cd0abfa983c52783ed10f7e733e,
with min=max=0 and zero workers. It contains the redacted loader RuntimeError
reason and the pre-download synthetic NF4 probe. The first diagnostic warm-up
failed during load_model with no original reason retained; its shutdown is
verified. The ledger is now $0.648126, which cannot admit another standard hold.

The historical startup-fix attempt ended in 24.08 seconds with explicit
ENDPOINT_PAUSED rejection and verified provider/app shutdown. Round to 25 seconds
and add the same 60-second control margin: 85 seconds at $0.75/hour retains
$0.017709, rounded up. Release only $0.088541 of that original $0.106250 hold.
Original job records remain unchanged; the latest diagnostic's full hold is
retained. No inference/compute/total dollar limit changes. Run:

```sh
docker run --rm -it --user "$(id -u):$(id -g)" \
  -v "$PWD:/work:ro" -v "$PWD/artifacts:/work/artifacts:rw" \
  -w /work --entrypoint python policypilot-api:demo \
  deploy/settle_closed_warmups.py https://policypilot-demo.onrender.com --paused-hold --apply
```

This mode requires the first settlement receipt and its matching database audit,
the exact current ledger, the matched REJECTED_PAUSED job with no provider ID,
and the latest FAILED diagnostic with its known provider ID. It checks fresh
zero workers/queued/running jobs and validates app/database state under the app
lock. Its separate idempotent audit prevents duplicate credits. Evidence is
saved/read-back verified in artifacts/runpod-paused-hold-settlement.json.
Without --apply this previews the same verified proposal. The expected balance
is $0.559585. Only after PASS, run:

```sh
python deploy/rehearse_model.py https://policypilot-demo.onrender.com \
  --run-warmup --loader-diagnostic
```

Requires the reviewed 5c4c2053... digest and committed paused-hold receipt before
any paid action. One synthetic warm-up reserves $0.118750 (total $0.678335,
under $0.70). Uses the existing six-minute watchdog and verified shutdown.
Keep the terminal/network open. Never use the old diagnostic flags for this run.
It refuses to repeat artifacts/runpod-warmup-loader-diagnostic.json once Start
has been attempted. Safe worker logs go to runpod-loader-diagnostic-workers.json.
Collected failure diagnostics, including the sanitized reason when present,
are printed in the terminal and embedded in the attempt report. No new keys,
Render deployment or GPU image build is required for these helper commands.

### Historical: two closed holds before the first diagnostic warm-up

The worker update was user-verified at 13:39:02Z with GPU digest
ae9aa4b8c0a6d84a3439c3d78e16198161efeaa7a468707ba041de792d077b29.
Only the two newest fully closed attempts qualify for settlement. Their recorded
wall times, 97.52 and 102.27 seconds, include initialization, execution and
verified shutdown. Round up each to the next second, add 60 seconds, and price
at the recorded $0.75/hour. Retain $0.032917 and $0.033959, rounded up to six
decimal places, instead of their original $0.118750 holds each. This is a
conservative accounting bound, not an invoice. Runpod bills worker running time
even when a request fails (https://www.runpod.io/blog/failed-requests-real-charges-how-runpod-serverless-billing-works-when-workers-fail).
The separate 30-cent inference overhead provision remains intact.

Run in the normal terminal, from the repository directory:

```sh
docker run --rm -it --user "$(id -u):$(id -g)" \
  -v "$PWD:/work:ro" -v "$PWD/artifacts:/work/artifacts:rw" \
  -w /work --entrypoint python policypilot-api:demo \
  deploy/settle_closed_warmups.py https://policypilot-demo.onrender.com --apply
```

Hidden prompts request the app password, dedicated Render inference key and
Render external database URL. The setup key is read locally without printing.
There is no key rotation, new container build or Render environment change.
Without --apply, the same command previews after all live read checks.

The helper validates every earlier receipt, matches the two original database
jobs and their terminal states (STARTUP_FAILED and FAILED), waits at least 15
minutes beyond each padded shutdown bound, requires the live app/database to
agree and be off, and checks fresh zero workers/zero queued or running jobs under
the app's advisory lock. It reads current account billing and preserves the
highest observed spend. It changes only compute_reserved_usd and inserts an
audit event; original job records and holds remain as historical evidence.
The idempotent audit prevents double release after a lost database response.
No allowance, provider setting or job state changes. Any failed check blocks it.

Expected ledger: $0.700000 -> $0.529376; unused-hold release $0.170624. Receipt:
artifacts/runpod-closed-warmup-settlement.json, saved/read-back verified, with
source-report hashes, before/after amounts and live app confirmation. Only after
its PASS result, run:

```sh
python deploy/rehearse_model.py https://policypilot-demo.onrender.com \
  --run-warmup --diagnostic-worker
```

This uses a distinct no-repeat runpod-warmup-diagnostic.json, validates the
committed settlement and verified GPU image, retains all earlier reports, and
reserves another $0.118750 (total $0.648126, below $0.70). It submits one synthetic
warm-up through the app, collects safe logs into runpod-diagnostic-workers.json,
and applies the existing six-minute shutdown watchdog and zero-worker verification.
Keep the terminal/network open. Do not repeat a failed attempt or press Start in
another browser tab. Success still does not prove fine-tuning or the RAM target.

## Architecture

`render-demo.yaml` is the proposed free UI/API and temporary free PostgreSQL
topology. The original `render.yaml` includes paid services; do not apply it for
this demonstration. The demo has no always-on OCR worker: Runpod does bounded
document processing and model inference through a custom queue handler. An ordinary
vLLM/OpenAI endpoint will NOT implement this handler contract.

API routes: `/api/model/status`, `/api/model/start`, `/api/model/stop`, and
`/api/cases/{id}/messages`. Mutations require the session-authenticated
`MODEL_OPERATOR`. Proxy headers cannot grant operator access. Model polling reads
provider state and known job results, never submits an inference request.

Model controls and chat use PostgreSQL session advisory locking. Intent is committed
before submitting a job. A response lost after submission creates an `uncertain`
job, blocks another start/submission and requires operator reconciliation. Do not
delete that record to blindly retry; a billable job may still be running. Pending
provider IDs remain tracked even if a case is deleted. Duplicate provider execution
after infrastructure retries is not proven impossible; configure/verify retries
before release. There is no automatic generation retry in our transport.

## Published images and pending Runpod verification

Start with the read-only connection preparation in the ordinary terminal:

```sh
python deploy/prepare_runpod.py
```

It safely parses the required fields from owner-only `deploy/cloud.env` without
executing shell content, verifies Pods/endpoints access first, reads current
AMPERE_24 serverless stock/rates, pins public Qwen2.5-7B-Instruct metadata and its
weight size, and saves a connection plan plus the public API schema. It does not
create resources, submit jobs or enable Render controls. The plan is an upstream
instruct baseline, not a PolicyPilot fine-tune. A 24 GB worker is proposed for
4-bit inference; process RSS below 2,000,000,000 bytes is still unverified.

Review `artifacts/runpod-connection-plan.json` and `artifacts/runpod-openapi.json`
before any create. The disabled draft has min/max workers both zero, an explicit
180-second execution timeout, CUDA floor 12.8, no network volumes and 30 GB
container disk. Runtime-optional HF_TOKEN is unnecessary for this public model.
Initialization, storage/tax, billing visibility and stop behavior still require
validation before paid execution. A reservation ledger is not a provider dollar
cap. Do not treat saving this plan as a deployed or working connection.

Private images are already published; do not rebuild or upload them merely to
continue setup. Exact references are in `artifacts/published-images.json`:

```text
ghcr.io/aizen-hado/policypilot-api@sha256:c2c5f3460fbd743943473c17510ab6d5e1ec0a4a4d050c1c8263b0a450232b7a
ghcr.io/aizen-hado/policypilot-gpu@sha256:a5b02a0ccf1d4cdb9e2f90bf8f148acddc853095a41924fab7e937b0f21f514b
```

Keep local images until an actual Runpod pull succeeds. Use a separate read-only
GHCR registry token there, never the broad Runpod API key as a registry password.
Publishing proves registry storage, not GPU/model readiness. The web deployment
uses `deploy/RENDER_IMAGE_DEMO.md`; do not apply the paid historical Blueprint.

### Create only the disabled endpoint

After the read-only preparation succeeds, review the local request preview:

```sh
python deploy/create_runpod_disabled.py
```

This writes `artifacts/runpod-disabled-request.json`, using fields reviewed against
the saved current provider schema. It makes no provider request. A separate full
JSON Schema validator was unavailable in the authoring environment; the actual
provider still validates the request.

Then run in an interactive ordinary terminal:

```sh
python deploy/create_runpod_disabled.py --apply
```

At the hidden prompt, enter a dedicated GitHub classic token with read:packages
for aizen-hado. It is sent to GitHub to confirm owner/private package access and
stored as a write-only registry credential on Runpod. It is never written to the
local journal or printed. The existing setup key stays in deploy/cloud.env.

The helper first inventories registries, endpoints and templates, then reads recent account billing.
Endpoint rollback does not establish that its generated template name is reusable.
After a confirmed removal or the provider's explicit duplicate-template rejection,
the next invocation journals a fresh name checked against both inventories while
reusing the registry credential. Existing templates are left unchanged; matching
template IDs are recorded without environment values. An unowned endpoint with
the planned name or an uncertain create outcome still blocks a repeated create.
It counts all reported 30-day account spend against the demo, without excluding
historical charges, and persists the highest observed amount so a rolling billing
window cannot reset it. The $1 inference reserve must still fit inside the $1.99
planning ceiling; otherwise creates are blocked. A read-only billing breakdown
by type/resource is saved as `artifacts/runpod-billing-audit.json`. No old resource
is stopped, changed or deleted by that audit. Missing/inconsistent billing data
blocks creates. It refreshes the selected pool rate and
stock, creates a uniquely named registry credential and inline QUEUE endpoint,
and reads both back. Scaling is QUEUE_DELAY because idleTimeout is incompatible
with REQUEST_COUNT in the saved API schema. It requires min=max=0, explicit
180000ms execution timeout, 300s idle timeout, 30 GB disk specification, no public
ports, no persistent volumes, the pinned image/model and zero allocated workers.
No model job is submitted and the image has not been proven to pull at this stage.

The allocated GPU rate is currently quoted at $0.75/hour before storage/tax; the
helper refuses a rate increase over the saved plan. Container disk is a worker
specification, not a new network volume. A min=max=0 endpoint is intended to
allocate no workers; billing read-back can lag and is not an invoice guarantee.
Paid execution remains disabled. The original under-$2 total and $1 inference
allowance remain unchanged; no provider-enforced dollar cap is claimed.

The first user-terminal attempt found $0.5064673366287025 in the account's prior
30-day billing and stopped before any create. The original guard incorrectly
required an entirely zero account history. With the corrected conservative
accounting, that full amount counts toward the ceiling, leaving
$1.4835326633712975 in total: $1 reserved for inference and
$0.4835326633712975 for remaining training/other overhead. These figures will be
refreshed from billing on the next run; the historical charge's source has not yet
been observed by this agent.

The protected journal `artifacts/runpod-disabled-setup.json` records IDs and
write intent before each create. An uncertain create is not automatically
repeated. A just-created endpoint whose safe settings/zero workers cannot be
confirmed is removed, then absence is verified. Existing endpoints are never
changed or deleted during resume. Definite request/permission errors can be fixed
and retried without recreating a confirmed registry credential.

On verification failure, the specific safe error and stage are now printed and
recorded. `artifacts/runpod-disabled-verification.json` contains field presence,
types and match booleans plus known integer worker counts; it never saves raw
provider env or arbitrary returned strings. Missing worker bounds/counts still
fail closed. Only documented representation equivalences are normalized: an
omitted GPU exclusion list means the whole selected pool, and a missing decoded
CMD may be verified from the canonical args representation. Different commands,
entrypoints, GPU pools or worker settings are rejected.

The live provider also omits the optional ports field for our queue worker's
requested empty list. That observed omission is accepted; the pinned image has
no EXPOSE instructions. Explicit null/malformed ports or actual exposed ports
are rejected. Canonical empty network/global mounts can omit the deprecated
networkVolumes alias, but a conflicting alias or any attached volume fails.
Worker limits/counts are never normalized from missing values to zero.

An explicit rerun after `unsafe_endpoint_removed` first rechecks the recorded
endpoint ID returns 404, preserves that removed ID in history, and reuses the
confirmed owned registry credential. It does not require entering a token again.
Uncertain creates still cannot be blindly repeated. The first old-format failure
message hid its specific cause; do not assert which field failed in that attempt.

HTTP request rejections now show bounded allowlisted JSON validation fields
(title/detail/message/error/errors), with the supplied Runpod key, registry token,
registry username, worker env values, authorization values and URLs redacted.
Unknown/oversized/non-JSON bodies are withheld. Safe request errors are recorded
in `artifacts/runpod-request-error.json`. A definite endpoint rejection preserves
the verified registry credential; the helper does not change the request or
automatically retry it. Obtain the specific provider reason before changing GPU,
worker bounds or other settings. HTTP 400 alone is not a diagnosed cause.

On success, `artifacts/runpod-render-settings.json` contains non-secret settings
only. Separate endpoint invocation/control credentials and runtime verification
are still required. Keep ENABLE_MODEL_CONTROL=0 and the execution approval flag
off in Render until those are resolved. No additional image upload is needed.

Build from the repository root with `deploy/gpu.Dockerfile`, then publish to a
private registry accessible to Runpod. The candidate pinned environment is
`deploy/gpu-requirements.txt`; it still needs clean-install and CUDA validation.
Use a queue-based Serverless endpoint and one 24 GB GPU after reading available
stock and current price. Minimum workers zero, maximum initially zero, idle timeout
300 seconds, compatible CUDA floor 12.8. Check whether the live API accepts the
max-zero configuration and sparse PATCH fields before enabling application controls.
Read every setting back and test cancellation/draining with one synthetic job.

The handler downloads a revision-pinned safetensors model on first use. This is a
simple initial delivery path, not a cold-start optimization claim. Use provider
model caching/a tested pinned model layer after measuring startup. A private model
repository can contain merged fine-tuned weights; adapters alone are not loaded by
this first implementation. No fine-tuned model has been created or promoted.

Worker secrets/configuration:
- `MODEL_REPOSITORY`: authorized model repository containing complete merged/base
  weights, tokenizer and configuration. A 7–9B model is a candidate only.
- `MODEL_REVISION`: full immutable 40-character repository commit.
- `HF_TOKEN`: optional scoped read credential for a private/gated model repository.
- `DOCUMENT_DOWNLOAD_HOST`: exact standard R2 account hostname generated by the
  existing adapter. The handler accepts HTTPS on port 443 only, with no redirects.

Do not give the model worker broad R2/Runpod management credentials. Document jobs
carry bounded short-lived signed downloads and hashes. A queued URL can expire;
retry requires an explicit new request after reconciling the old job.

API secrets/configuration, in addition to storage/database/session settings:
- `MODEL_OPERATOR`: the server-authenticated shared account allowed to spend.
- `PROCESSING_BACKEND=runpod` and `INFERENCE_BACKEND=runpod`.
- `RUNPOD_ENDPOINT_ID`: the one dedicated queue endpoint controlled by this app.
- `RUNPOD_CONTROL_KEY`: server-side permission to read/patch only the dedicated
  endpoint where provider scope permits; code never accepts a browser endpoint ID.
- `RUNPOD_INFERENCE_KEY`: invocation/status/cancellation credential.
- `RUNPOD_ARTIFACT_REVISION`: identical to the worker's `MODEL_REVISION`.
- `RUNPOD_MODEL`: human-readable actual repository/model label.
- `ENABLE_MODEL_CONTROL=1` and `RUNPOD_INFERENCE_BUDGET_APPROVED=1` only after live
  compatibility and cost review. These flags are authorization gates, not dollar caps.
- `RUNPOD_VERIFIED_HOURLY_RATE_USD`: the selected endpoint's freshly verified rate.
  No rate is guessed or hardcoded into the app.
- `RUNPOD_SESSION_COMPUTE_LIMIT_USD`: the operator-approved compute allowance for
  one session. Each admission reserves 180 seconds of execution, 300 seconds of
  idle time and 30 seconds of margin at the configured rate. This is a conservative
  admission check, not a provider-enforced ceiling; startup delays, retries,
  shutdown lag, storage and taxes can exceed those assumptions. It is not a global
  experiment allowance. Until a new total is approved, retain the original strictly
  under-USD-2 combined ceiling for all GPU experiments and overhead.

The user has now approved USD 1 total demo inference within the original combined
ceiling. Migration 006 creates a cumulative USD 0.70 compute-reservation ledger,
leaving USD 0.30 for inference overhead. Stop/Start does not reset this ledger and
uncertain jobs are never automatically refunded. Each reservation is also recorded
on its job. If the full inference allowance is used, training and its overhead
must stay within USD 0.99 for a combined planning maximum of USD 1.99. These are
authorization/admission limits, not proof that provider charges cannot exceed them.
Provisioning still requires verified price, overhead and cleanup controls.

## Billing and shutdown limitations

Start sets min/max to 0/1 and verifies them, then submits a warm-up generation.
Worker readiness requires matching artifact identity and successful generation.
Stop closes local admission first, requests job cancellation, sets min/max to zero,
reads configuration back, and checks provider health. It never deletes the endpoint
or artifacts. A provider error or ambiguous submission must show unconfirmed status.
Minimum zero and native idle timeout remain the fallback when the browser/API dies.

The display reports a wall-time compute estimate at the configured verified rate,
or unavailable if no valid rate/allowance is set. It counts the entire enabled
session even if native scale-down has already released the worker, so it can
overestimate GPU use. Verified stop freezes the estimate. Actual invoice attribution
and an independently enforceable inference dollar cutoff are NOT implemented. Do
not mistake admission checks, worker limits or request timeouts for a financial cap.
Provider schema and health fields must match the strict parser; otherwise it fails
closed. Keep-warm minimum-one mode is not implemented.

On the free topology there is no continuous object-cleanup process. Case deletion,
case listing and model-status polling schedule one best-effort cleanup attempt.
Deletion intent remains in PostgreSQL across interruptions; later app activity
retries eligible entries. Operator controls in Deployment details show the pending
and eligible counts and retry one entry. Failed deletes back off for five minutes.
Nothing retries while the app is asleep; this is activity-driven recovery, not an
independent scheduler. Do not claim R2 files are physically removed just because a
case vanished. Verify the queue and bucket during the release rehearsal.

## Acceptance

### One explicitly requested longer-startup retry

The user requested another attempt after the 60-second activation timeout.
Deploy the new API image with startup_protocol=invoke-worker-v2. It allows
180 seconds for activation and returns min=0/max=1 with idleTimeout=180 after
accepted warm-up. Stop still restores min=max=0/idleTimeout=300. The longer
startup trades against a shorter idle hold, retaining the $0.11875 reservation.

```sh
python deploy/rehearse_model.py https://policypilot-demo.onrender.com --run-warmup --retry-long-startup
```

It validates the prior $0.58125 ledger chain, current spend/price/stock/routes and
the new deployment version. No old report is removed and no reservation refunded.
If admitted, cumulative reservations reach $0.70. A separate no-repeat report
and worker-observation file capture this attempt. Worker IDs are sampled while
active; safe log-pattern capture is attempted before shutdown, without saving
raw SDK URLs/credentials. Keep the terminal open for the six-minute watchdog.
Budget approval may remain 1 by user preference. This is a supervised test of
the startup-time hypothesis; generation remains unverified until it passes.

### Runtime-observed startup verification after the manual worker test

Current Start reserves before allocation, temporarily requests min=max=1, and
waits up to 60 seconds for worker allocation to appear in the inference API's
health response. It does not confuse allocation with model readiness. Only then
does it submit one synthetic warm-up. Once the provider ID is committed, it
restores min=0/max=1 for normal idle scale-down. Failure requests zero workers;
no permanent minimum-one worker is left by this startup flow.

Rebuild/publish only the API image, update Render to its new digest and wait for
Live. RUNPOD_INFERENCE_BUDGET_APPROVED may stay 1 as requested. Run:

```sh
python deploy/rehearse_model.py https://policypilot-demo.onrender.com --run-warmup --after-worker-start
```

Before starting, it verifies the deployment protocol, advertised invocation URLs,
provider state/price/stock/spend and the full $0.4625 prior reservation chain.
Warm-up now reserves $0.11875 at $0.75/hour including startup margin. It preserves
old reports and writes a separate no-repeat runpod-warmup-activation.json. Keep
the terminal connected for the six-minute watchdog and verified shutdown. No
live generation is claimed until this test passes.

### Verify the deployed paused-endpoint startup fix

Rebuild and publish only the API image, then update Render's image reference to
the publisher's new API digest. Keep budget approval zero until the new deploy
is Live. The code handles only an explicit HTTP 409/ENDPOINT_PAUSED refusal:
up to three submissions with the same request and reservation, five seconds
between refusals and a management min=0/max=1 read before each repeat. It never
repeats a timeout, unknown conflict, invalid acknowledgement or accepted job.
Persistent known refusal becomes REJECTED_PAUSED; failed Start requests shutdown
and records off only with idle health and no unresolved jobs. No refunds occur.

After both previous recovery reports are PASS, enable the inference budget flag,
save/deploy, and run one supervised verification:

```sh
python deploy/rehearse_model.py https://policypilot-demo.onrender.com --run-warmup --after-startup-fix
```

This requires the prior $0.2125 reservation and saves a distinct no-repeat report
at artifacts/runpod-warmup-startup-fix.json. Keep the terminal open. The independent
six-minute watchdog and provider/app shutdown verification remain active. Restore
the budget flag to zero and save/deploy after the run. Current price/spend/stock
are checked by the helper before Start. The original 409 reason remains unknown;
this is a test of the explicit paused-rejection handling, not proof of its cause.

### One supervised follow-up after the verified first-attempt recovery

The original paid-attempt report and $0.106250 reservation must remain intact.
After deploying the API transport diagnostics, set
`RUNPOD_INFERENCE_BUDGET_APPROVED=1` in Render and save/deploy. Keep the terminal
open and run:

```sh
python deploy/rehearse_model.py https://policypilot-demo.onrender.com --run-warmup --after-reconciliation
```

This mode requires the original failed rehearsal and a matching committed PASS
recovery report. It checks current provider settings, zero workers, billing,
catalog rate/stock and the live app's unchanged reservation before Start. It
submits one synthetic warm-up through the app, retains the independent six-minute
shutdown timer, saves evidence and verifies shutdown. Its separate
`artifacts/runpod-warmup-followup.json` prevents another automatic paid attempt;
do not delete it to retry. No training or model-RSS claim follows from this test.

The helper waits up to 100 seconds for Start/Stop responses because these routes
perform several sequential provider calls; the watchdog remains independent.
Only fixed operation/error labels and HTTP status from the updated API are saved,
never arbitrary response bodies. After the run, set
`RUNPOD_INFERENCE_BUDGET_APPROVED=0` and save/deploy. Provider billing can lag;
the timer and app ledger are not a provider-enforced dollar cap.

### Recover the expired first uncertain warm-up without refund

After current disabled settings, zero workers and zero runtime jobs have been
observed, keep ENABLE_MODEL_CONTROL=1 and deploy
RUNPOD_INFERENCE_BUDGET_APPROVED=0. The following narrow helper uses the existing
API image's PostgreSQL driver; it does not rebuild an image or start a GPU:

```sh
cd /home/aizen/Downloads/PolicyPilotAI_ollama
docker run --rm -it --user "$(id -u):$(id -g)" \
  -v "$PWD:/work:ro" -v "$PWD/artifacts:/work/artifacts:rw" \
  -w /work --entrypoint python policypilot-api:demo \
  deploy/reconcile_warmup.py https://policypilot-demo.onrender.com --apply
```

Prompts: app username, app password, dedicated RUNPOD_INFERENCE_KEY and the Render
database's External Database URL (database Info page). Password/key/URL prompts
are hidden; values are never printed or saved. Database transport requires TLS.
Omit --apply for a check-only preview. This takes the app advisory lock, checks
the exact first rehearsal and app/database session against the single recorded
warm-up, requires its submitted ten-minute TTL plus five-minute margin to have
elapsed, and freshly verifies disabled/empty provider state. --apply records
RECONCILED_EXPIRED, preserves reserved_compute_usd and the allowance ledger,
adds an audit event, and verifies live app off with can_start=false. The wall-time
estimate is bounded using saved provider shutdown evidence plus a minute margin.
Original execution outcome remains unverified. Report:
artifacts/runpod-warmup-reconciliation.json. Do not remove the original rehearsal
artifact or start another paid request merely because recovery passes.

If the first warm-up ends with a reserved uncertain job, retain its report and
disable RUNPOD_INFERENCE_BUDGET_APPROVED in Render before further diagnosis. Run:

```sh
python deploy/inspect_runpod_attempt.py
```

This reads only provider settings, worker counts, billing, health and available
request history. Settings/workers/billing use the setup credential locally;
health/history use the dedicated RUNPOD_INFERENCE_KEY from a hidden prompt. Paste
the same inference key used in Render, never the control/setup key. The first
inspector incorrectly reused the setup key for runtime reads and got HTTP 403;
that did not diagnose Render's inference credential. The corrected helper saves safe metadata in
artifacts/runpod-attempt-inspection.json; no key or raw job input/output/error is
printed or saved. Runtime history can expire or be unavailable: an empty/missing
list does not prove a request was rejected. Do not reset the reservation ledger
or rerun the warm-up merely because workers are zero.

For the first supervised paid test, the live app's disabled connection has now
been confirmed by the user. Set `RUNPOD_INFERENCE_BUDGET_APPROVED=1` in Render
with `ENABLE_MODEL_CONTROL=1`, save/deploy, and run once:

```sh
python deploy/rehearse_model.py https://policypilot-demo.onrender.com --run-warmup
```

Enter the app username/password at the prompts. Local cloud.env supplies billing
and emergency zero-worker control credentials; these are never sent to Render.
Keep the terminal/network running and avoid simultaneous browser Start/assessment
requests. The script checks current account billing, GPU rate/stock, zero workers
and the untouched $1/$0.70 app allowance. It calls Start once, polls up to six
minutes, saves a verified model revision on success and calls Stop on every
attempted-run exit. A separate timer requests max=0 at six minutes. Provider
worker absence and app-off state are checked before declaring shutdown complete.
It never retries a paid request; an existing attempt report blocks another run.

This is a best-effort watchdog, not a provider financial cap; killing the process
or losing connectivity prevents its shutdown requests. Native job TTL/idle timeout
remain fallback controls. Shutdown verification may take another three minutes
plus request timeouts. At $0.75/hour, six minutes of GPU runtime is $0.075 before
storage/tax and shutdown delays. No fresh rate is assumed; the script reads it.
The warm-up reservation is recorded in the app's original inference ledger.
After it finishes, set the budget approval flag back to zero, retain
`artifacts/runpod-warmup-rehearsal.json`, and reconcile billed spend before more
work. A successful warm-up proves baseline generation, not model quality,
fine-tuning or the process RSS target. If shutdown is unconfirmed, immediately
inspect this endpoint in Runpod and set min/max=0; do not retry Start.

The user's dedicated-key check passed on 2026-11-11 for endpoint
`tjkkm5pkp7lrej`, including the zero-worker PATCH and read-back. The console's
management Read/Write permission resolved REST access, but the screenshot did
not provide management restrictions per endpoint. Treat that control key as
broader management access; the app's fixed endpoint is not a provider key scope.

To verify the credentials actually deployed in Render, set
`ENABLE_MODEL_CONTROL=1` while retaining `RUNPOD_INFERENCE_BUDGET_APPROVED=0`.
Save and deploy, then read `/api/model/status` as the signed-in operator. Expected
fields are configured=true, enabled=false, state=off, operator=true and
can_start=false. Start rejects the zero budget flag before any scaling/submission.
Status reads may also advance object cleanup. A local helper PASS alone does not
verify these deployed settings. Do not proceed to paid warm-up on a 503 or
unknown/error/stopping state.

Before any paid execution, verify the dedicated keys from an ordinary terminal:

```sh
python deploy/verify_runpod_connection.py --verify-control-write
```

Paste the same RUNPOD_CONTROL_KEY and RUNPOD_INFERENCE_KEY used in Render at the
hidden prompts. Keys are not saved. This checks the pinned disabled configuration,
worker list and inference health, then tests a control PATCH keeping min=max=0
and repeats the reads. Without the flag it performs only reads. Unexpected or
active state blocks the PATCH. No inference job is sent. A safe report is saved
to artifacts/runpod-connection-verification.json. This verifies the supplied keys,
not that Render has those exact values or that they are denied access elsewhere.
It does not prove invocation permission, image pull or model readiness. Keep both
Render enable flags zero pending the supervised GPU rehearsal.

Run the zero-skip HTTP test gate and build the images. Verify login, both control
buttons, a native PDF case, the SYN-C003 OCR case, evidence citations, chat,
refresh recovery, multiple tabs, provider outages, uncertain submissions and
shutdown/idle scale-down. Record actual memory, latency and provider billing.
No control should show Off when job/worker state is unknown. Browser visual QA
and reduced-motion/mobile checks are still required.
