# Cloud configuration handoff — 2026-11-10

Target: Render UI/API + OCR worker + PostgreSQL, Cloudflare R2 documents,
Runpod open-weight inference. No Render Ollama service is needed if Runpod is used.
This is hosted processing, not fully local or guaranteed India-resident processing.
Use synthetic data until regions, retention and access controls are verified.

## 1. Cloudflare R2

In the existing Cloudflare account, create a dedicated `policypilot-staging` bucket
(or another available name). Keep both r2.dev access and public custom domains
disabled. Do not connect the company domain to this bucket. Browser downloads go
through our authenticated API; bucket CORS is unnecessary for this architecture.

Create an R2 API token with Object Read & Write permission limited to that bucket.
Save its Access Key ID and Secret Access Key in the local prompt below, not chat.
Use the standard account endpoint for this configuration; jurisdiction-specific
buckets require an explicit endpoint adaptation before use.

```bash
python3 deploy/configure_cloud.py
source deploy/cloud.env
python3 deploy/check_r2.py
python3 deploy/check_runpod.py
```

The setup prompt writes an ignored, owner-readable `deploy/cloud.env` and refuses
to overwrite it. It does not install software, contact providers or create resources.
The probe needs the dependencies in `pilot/requirements.txt` installed in its Python
environment. It creates only a synthetic UUID object, verifies bytes and requests
deletion. It does not certify that the bucket is private: check dashboard settings.
Do not use shell tracing (`set -x`) when loading credentials.

R2 uses `DOCUMENT_STORAGE=r2`, `R2_ACCOUNT_ID`, `S3_BUCKET`, `AWS_ACCESS_KEY_ID`
and `AWS_SECRET_ACCESS_KEY`. These AWS-named variables contain **R2** credentials;
no AWS account is required. Region is `auto`. R2 encrypts objects at rest; the
adapter omits the unsupported AWS SSE-S3 request parameter.

## 2. Runpod access before inference provisioning

No Runpod CLI, MCP connection or environment API key was available in the authoring
session. Configure a Runpod API key locally through the same hidden prompt, or
connect the Runpod plugin. Do not paste the key into chat. The local key is for
setup; do not copy a broad account-management credential into the browser or app.

Once access is available: inspect existing endpoints/pods read-only first, select
the region and model runtime, record hourly cost and resource limits, then prepare
a concrete inference deployment. Start with one concurrent inference worker and
synthetic inputs. Verify endpoint authentication and a real external request.

The existing app speaks the local Ollama API. Runpod serverless/vLLM is not a
drop-in URL replacement. Before starting compute, implement and test the selected
transport, timeout/retry behavior, structured output, readiness and credential
handling. Never expose an unauthenticated Ollama port as a shortcut. Raw PDFs and
R2 credentials should stay with the Render API/worker; only selected text excerpts
and the claim description need to reach inference. Review provider request/log
retention before real claims. This setup does not establish a private network
between Render and Runpod; hosted calls require authenticated HTTPS.

## 3. Render and code deployment

Prepare a Render account and a private GitHub repository. Account access is not
yet connected here. The workspace's Git metadata was not usable in the authoring
session, so no push or repository creation has been performed.

Prepare the public web service, OCR background worker and managed PostgreSQL only
after hosted authentication and deployment configuration are ready. R2 values go
into API/worker secret settings; inference credentials only into services that
need them. Database URLs and session secrets never go into frontend code.

## Acceptance checklist

- R2 synthetic write/read/delete verified and bucket privacy checked.
- Runpod account access verified without printing secrets.
- Exact inference runtime, region, price and credential scope reviewed.
- Inference adapter and login implemented before an externally available app.
- Real inference, API/OCR/browser flows, deletion, outages and restore tested.

References:
- https://developers.cloudflare.com/r2/examples/aws/boto3/
- https://developers.cloudflare.com/r2/api/s3/api/
- https://developers.cloudflare.com/r2/reference/data-security/

Status: R2 adapter and local setup/probe implemented; provider credentials absent,
so no live connection test, Runpod configuration or paid provisioning completed.

Latest local check: credentials are now present with mode 0600 and all expected
fields populated. External DNS is unavailable in the authoring shell and boto3
cannot be installed there, so credential validity remains unverified. Run the
checks from an ordinary network-connected terminal. On NixOS, a temporary tool
shell suffices: `nix-shell -p python3Packages.boto3`. No system changes are needed.
