"""One synthetic app warm-up with deadline shutdown; no automatic paid retry."""
import argparse
from datetime import datetime, timezone
from decimal import Decimal
import fcntl
import getpass
import http.cookiejar
import json
import re
import ssl
from pathlib import Path
import sys
import threading
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT/'deploy'))
from create_runpod_disabled import API, SetupError, save, payload, resource_id, verify_disabled, verify_no_workers, billed_amount, account_for_history, budget_policy, EXTRA_DOLLAR_AUTHORIZATION
from prepare_runpod import credentials, candidates, PreparationError, NoRedirect
from diagnose_login import validate_origin, DiagnosticError
from pilot.auth import COOKIE

DEADLINE = 360
BILLING = '/v2/billing?lastN=30&bucketSize=day'


class AppRequestError(SetupError):
    def __init__(self, status=None, diagnostic=None, operation='request', category=None):
        self.status = status
        self.diagnostic = safe_diagnostic(diagnostic)
        self.operation=operation if operation in ('request','health check','login','session check','model status','model start','model stop','logout') else 'request'
        self.category=category if category in ('timeout','network failure','TLS failure','invalid response') else None
        super().__init__('App '+self.operation+' failed'+(' (HTTP '+str(status)+')' if status else '')+
                         (': '+self.category if self.category else '')+
                         '; response and exception details withheld. No automatic paid retry.')


def safe_diagnostic(value):
    """Accept only the API's fixed transport messages, never arbitrary detail."""
    if isinstance(value,str) and value in (
        'Temporary worker settings were not confirmed',
        'Runtime jobs or worker health are not clear for warm-up',
        'Invoke API did not observe worker activation within 60 seconds; no job submitted',
        'Invoke API did not observe worker activation within 180 seconds; no job submitted',
    ):return value
    pattern = (r'Runpod (?:control_update|control_read|submit|health|inference_read|job_status|job_cancel): '
               r'(?:HTTP (?:[1-5][0-9]{2}|unknown)(?: \(ENDPOINT_PAUSED\))?|timeout|network failure|invalid response|transport failure)'
               r'; reconcile before retrying paid work')
    return value if isinstance(value,str) and re.fullmatch(pattern,value) else None


def reconciled_reservation(root, state, expected):
    """Allow exactly one follow-up linked to the retained first-attempt recovery."""
    previous=json.loads((root/'artifacts/runpod-warmup-rehearsal.json').read_text())
    recovery=json.loads((root/'artifacts/runpod-warmup-reconciliation.json').read_text())
    if (previous.get('endpoint_id')!=state['endpoint_id']
            or previous.get('start_attempted') is not True
            or previous.get('generation_verified') is not False
            or previous.get('provider_shutdown_verified') is not True
            or previous.get('model_revision')!=expected['env']['MODEL_REVISION']
            or recovery.get('endpoint_id')!=state['endpoint_id']
            or recovery.get('result')!='PASS'
            or recovery.get('database_committed') is not True
            or recovery.get('provider_disabled_and_idle_verified') is not True
            or recovery.get('past_submitted_ttl_and_margin') is not True
            or recovery.get('new_jobs_submitted')!=0
            or number(recovery.get('refund_usd'))!=0):
        raise SetupError('Original warm-up and verified recovery must match this endpoint and model')
    app=recovery.get('app_after',{})
    reserved=number(recovery.get('reserved_compute_usd'))
    if (app.get('state')!='off' or app.get('enabled') is not False
            or app.get('can_start') is not False or reserved!=Decimal('0.106250')
            or number(app.get('demo_compute_reserved_usd'))!=reserved):
        raise SetupError('Recovery must preserve the original reservation and confirm app off')
    return reserved


def startup_fix_reservation(root,state,expected):
    prior=reconciled_reservation(root,state,expected)
    followup=json.loads((root/'artifacts/runpod-warmup-followup.json').read_text())
    recovery=json.loads((root/'artifacts/runpod-warmup-followup-reconciliation.json').read_text())
    if (followup.get('endpoint_id')!=state['endpoint_id']
            or followup.get('model_revision')!=expected['env']['MODEL_REVISION']
            or followup.get('start_attempted') is not True
            or followup.get('generation_verified') is not False
            or followup.get('provider_shutdown_verified') is not True
            or number(followup.get('prior_compute_reserved_usd'))!=prior
            or recovery.get('endpoint_id')!=state['endpoint_id']
            or recovery.get('database_committed') is not True or recovery.get('result')!='PASS'
            or recovery.get('provider_disabled_and_idle_verified') is not True
            or recovery.get('new_jobs_submitted')!=0 or number(recovery.get('refund_usd'))!=0
            or number(recovery.get('reserved_compute_usd'))!=Decimal('.2125')
            or recovery.get('app_after',{}).get('state')!='off'
            or recovery.get('app_after',{}).get('can_start') is not False):
        raise SetupError('Both recovered attempts and the preserved $0.2125 must match before testing the startup fix')
    return Decimal('.2125')


def worker_start_reservation(root,state,expected):
    previous=startup_fix_reservation(root,state,expected)
    attempt=json.loads((root/'artifacts/runpod-warmup-startup-fix.json').read_text())
    manual=json.loads((root/'artifacts/runpod-existing-worker-start.json').read_text())
    if (attempt.get('endpoint_id')!=state['endpoint_id']
            or attempt.get('model_revision')!=expected['env']['MODEL_REVISION']
            or number(attempt.get('prior_compute_reserved_usd'))!=previous
            or attempt.get('generation_verified') is not False
            or attempt.get('provider_shutdown_verified') is not True or attempt.get('app_shutdown_verified') is not True
            or number(attempt.get('shutdown_app_status',{}).get('demo_compute_reserved_usd'))!=Decimal('.31875')
            or manual.get('endpoint_id')!=state['endpoint_id'] or manual.get('start_attempted') is not True
            or manual.get('reservation_committed') is not True or manual.get('provider_shutdown_recheck_verified') is not True
            or manual.get('app_off_verified') is not True or manual.get('requests_submitted')!=0
            or number(manual.get('prior_compute_reserved_usd'))!=Decimal('.31875')
            or number(manual.get('reserved_compute_usd'))!=Decimal('.14375')
            or number(manual.get('total_compute_reserved_usd'))!=Decimal('.4625')):
        raise SetupError('Recorded worker shutdown and all $0.4625 prior reservations must match')
    return Decimal('.4625')


def long_startup_reservation(root,state,expected):
    previous=worker_start_reservation(root,state,expected)
    attempt=json.loads((root/'artifacts/runpod-warmup-activation.json').read_text())
    if (attempt.get('endpoint_id')!=state['endpoint_id']
            or attempt.get('model_revision')!=expected['env']['MODEL_REVISION']
            or number(attempt.get('prior_compute_reserved_usd'))!=previous
            or attempt.get('start_attempted') is not True or attempt.get('generation_verified') is not False
            or attempt.get('provider_shutdown_verified') is not True or attempt.get('app_shutdown_verified') is not True
            or attempt.get('provider_diagnostic')!='Invoke API did not observe worker activation within 60 seconds; no job submitted'
            or number(attempt.get('shutdown_app_status',{}).get('demo_compute_reserved_usd'))!=Decimal('.58125')):
        raise SetupError('Previous activation timeout and preserved $0.58125 must match before retry')
    return Decimal('.58125')


def diagnostic_reservation(root,state,expected):
    from settle_closed_warmups import bounds
    proposal=bounds(root,state,expected)
    settled=json.loads((root/'artifacts/runpod-closed-warmup-settlement.json').read_text())
    image=json.loads((root/'artifacts/runpod-image-update.json').read_text())
    if (settled.get('endpoint_id')!=state['endpoint_id'] or settled.get('result')!='PASS'
            or settled.get('database_committed') is not True or settled.get('proposal')!=proposal
            or number(settled.get('observed_reserved_usd'))!=number(proposal['reserved_after_usd'])
            or image.get('endpoint_id')!=state['endpoint_id']
            or image.get('provider_verified') is not True or image.get('local_receipts_verified') is not True
            or image.get('desired_image')!=expected['image'] or image.get('before_image')==expected['image']):
        raise SetupError('Verified diagnostic image and audited closed-hold settlement required')
    return number(proposal['reserved_after_usd'])


def loader_reservation(root,state,expected):
    from settle_closed_warmups import paused_bounds
    proposal=paused_bounds(root,state,expected)
    settled=json.loads((root/'artifacts/runpod-paused-hold-settlement.json').read_text())
    image=json.loads((root/'artifacts/runpod-image-update.json').read_text())
    # This reviewed digest contains redacted loader reasons and the NF4 probe.
    reviewed='ghcr.io/aizen-hado/policypilot-gpu@sha256:5c4c20537587ab0317ac7515b7fcf94f9d5e1cd0abfa983c52783ed10f7e733e'
    if (settled.get('endpoint_id')!=state['endpoint_id'] or settled.get('result')!='PASS'
            or settled.get('database_committed') is not True or settled.get('proposal')!=proposal
            or number(settled.get('observed_reserved_usd'))!=number(proposal['reserved_after_usd'])
            or image.get('endpoint_id')!=state['endpoint_id']
            or image.get('provider_verified') is not True or image.get('local_receipts_verified') is not True
            or image.get('desired_image')!=reviewed or expected['image']!=reviewed
            or image.get('before_image')==reviewed):
        raise SetupError('Reviewed loader-diagnostic image and committed paused-hold settlement required')
    return number(proposal['reserved_after_usd'])


COMPILER_FIXED_IMAGE='ghcr.io/aizen-hado/policypilot-gpu@sha256:537c877f3c2fce36265cf360f4e9ff8e2ff92d19fe81680e5a55313672a105c2'


def compiler_ready(root,state,expected):
    from settle_closed_warmups import paused_bounds,audit_action
    proposal=paused_bounds(root,state,expected)
    prior=json.loads((root/'artifacts/runpod-paused-hold-settlement.json').read_text())
    attempt=json.loads((root/'artifacts/runpod-warmup-loader-diagnostic.json').read_text())
    image=json.loads((root/'artifacts/runpod-image-update.json').read_text())
    reserved=number(proposal['reserved_after_usd'])+Decimal('.11875')
    failures=attempt.get('worker_failure_diagnostics',[])
    known_failure=any(isinstance(item,dict) and item.get('stage')=='check_quantizer'
        and item.get('exception_type')=='RuntimeError'
        and item.get('model_loader_reason')=='Failed to find C compiler. Please specify via CC environment variable.'
        for item in failures) if isinstance(failures,list) else False
    if (prior.get('endpoint_id')!=state['endpoint_id'] or prior.get('result')!='PASS'
            or prior.get('database_committed') is not True or prior.get('proposal')!=proposal
            or prior.get('audit_action')!=audit_action(proposal)
            or number(prior.get('observed_reserved_usd'))!=number(proposal['reserved_after_usd'])
            or attempt.get('endpoint_id')!=state['endpoint_id'] or attempt.get('start_attempted') is not True
            or attempt.get('model_revision')!=expected['env']['MODEL_REVISION']
            or attempt.get('generation_verified') is not False or not known_failure
            or attempt.get('provider_shutdown_verified') is not True or attempt.get('app_shutdown_verified') is not True
            or number(attempt.get('prior_compute_reserved_usd'))!=number(proposal['reserved_after_usd'])
            or number(attempt.get('shutdown_app_status',{}).get('demo_compute_reserved_usd'))!=reserved
            or image.get('endpoint_id')!=state['endpoint_id']
            or image.get('provider_verified') is not True or image.get('local_receipts_verified') is not True
            or image.get('desired_image')!=COMPILER_FIXED_IMAGE or expected['image']!=COMPILER_FIXED_IMAGE
            or image.get('before_image')!=attempt.get('worker_image')):
        raise SetupError('Compiler-fixed image and complete preserved failure/settlement history required')
    return reserved,prior['audit_action']


def compiler_reservation(root,state,expected):
    reserved,_=compiler_ready(root,state,expected)
    extension=json.loads((root/'artifacts/runpod-extra-dollar-authorization.json').read_text())
    if (state.get('budget_authorization')!=EXTRA_DOLLAR_AUTHORIZATION
            or extension.get('authorization')!=EXTRA_DOLLAR_AUTHORIZATION
            or extension.get('endpoint_id')!=state['endpoint_id'] or extension.get('result')!='PASS'
            or extension.get('database_committed') is not True
            or number(extension.get('reserved_compute_usd'))!=reserved
            or extension.get('compiler_image')!=COMPILER_FIXED_IMAGE):
        raise SetupError('Committed one-dollar budget extension and preserved reservations required')
    return reserved


def safe_app_state(status):
    """Keep useful state without arbitrary response strings, cookies or content."""
    result = {key: status[key] for key in ('configured','enabled','can_start','operator')
              if type(status.get(key)) is bool}
    phase = status.get('state')
    if phase in ('starting','loading','ready','idle','error','off','stopping','unavailable','processing'):
        result['state'] = phase
    if status.get('startup_protocol') in ('invoke-worker-v1','invoke-worker-v2'):
        result['startup_protocol']=status['startup_protocol']
    for key in ('compute_allowance_usd','demo_inference_allowance_usd','demo_compute_reserved_usd'):
        value = status.get(key)
        if type(value) in (int,float):
            try: result[key] = str(number(value))
            except SetupError: pass
    return result


class Web:
    def __init__(self, origin):
        self.origin = validate_origin(origin)
        self.cookies = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
                         urllib.request.HTTPCookieProcessor(self.cookies))

    def call(self, path, method='GET', body=None):
        operation={'/healthz':'health check','/api/auth/login':'login','/api/auth/me':'session check',
                   '/api/auth/logout':'logout','/api/model/status':'model status',
                   '/api/model/start':'model start','/api/model/stop':'model stop'}.get(path,'request')
        req = urllib.request.Request(self.origin+path, method=method,
              data=None if body is None else json.dumps(body).encode(),
              headers={'Origin': self.origin, 'Content-Type': 'application/json', 'Accept': 'application/json'})
        try:
            # Start performs multiple bounded provider calls. The independent
            # watchdog still enforces the overall deadline while this waits.
            timeout=360 if path=='/api/model/start' else (180 if path=='/api/model/stop' else (90 if path=='/healthz' else 20))
            with self.opener.open(req, timeout=timeout) as response:
                if response.code == 204: return {}
                raw = response.read(16385)
                if len(raw)>16384: raise ValueError()
                data = json.loads(raw)
                if not isinstance(data, dict): raise ValueError()
                return data
        except urllib.error.HTTPError as exc:
            diagnostic=None
            try:
                raw=exc.read(16385)
                if len(raw)<=16384:
                    value=json.loads(raw)
                    if isinstance(value,dict): diagnostic=safe_diagnostic(value.get('detail'))
            except (OSError,ValueError): pass
            finally: exc.close()
            raise AppRequestError(exc.code,diagnostic,operation) from None
        except TimeoutError:
            raise AppRequestError(operation=operation,category='timeout') from None
        except ssl.SSLError:
            raise AppRequestError(operation=operation,category='TLS failure') from None
        except urllib.error.URLError as exc:
            category='timeout' if isinstance(exc.reason,TimeoutError) else ('TLS failure' if isinstance(exc.reason,ssl.SSLError) else 'network failure')
            raise AppRequestError(operation=operation,category=category) from None
        except OSError:
            raise AppRequestError(operation=operation,category='network failure') from None
        except (ValueError,UnicodeError):
            raise AppRequestError(operation=operation,category='invalid response') from None

    def login(self, username, password):
        self.call('/healthz')
        self.call('/api/auth/login', 'POST', {'username': username, 'password': password})
        if not any(c.name==COOKIE and c.secure for c in self.cookies):
            raise SetupError('Secure session cookie missing')
        me = self.call('/api/auth/me')
        if me.get('username')!=username or me.get('auth_mode')!='session' or me.get('model_operator') is not True:
            raise SetupError('Authenticated model operator was not confirmed')


def number(value):
    try:
        result = Decimal(str(value))
        if not result.is_finite() or result<0: raise ValueError()
        return result
    except (ValueError, ArithmeticError): raise SetupError('Invalid or missing budget figure') from None


def preflight(api, web, state, expected, journal, prior_reserved=Decimal('0'),required_protocol=None):
    route = '/v2/serverless/'+resource_id(state['endpoint_id'])
    verify_disabled(api.call(route), expected)
    verify_no_workers(api.call(route+'/workers'))
    before = billed_amount(api.call(BILLING))
    covered = account_for_history(before, state); save(journal, state)
    ceiling,approved_total,compute_limit=budget_policy(state)
    if not covered: raise SetupError('Current billing cannot cover the approved inference reserve within the total planning ceiling')
    catalog = api.call('/v2/catalog/gpus?include=AVAILABILITY&product=SERVERLESS&cloud=SECURE&count=1&minCudaVersion=12.8')
    rows = [row for row in candidates(catalog) if row['pool']=='AMPERE_24']
    if not rows or not any(row['stock'] in ('LOW','MEDIUM','HIGH') for row in rows):
        raise SetupError('Selected GPU pool has no confirmed stock')
    rate = max(number(row['serverless_usd_per_hour']) for row in rows)
    if rate>number(state['conservative_serverless_usd_per_hour']):
        raise SetupError('GPU rate increased; refresh budget before execution')
    app = web.call('/api/model/status')
    if required_protocol is not None and app.get('startup_protocol')!=required_protocol:
        raise SetupError('Render is not running the worker-activation startup release; deploy the new API image first')
    if required_protocol is not None:
        from inspect_runpod_attempt import routing_check
        if not routing_check(api,state)['all_client_routes_match']:
            raise SetupError('Provider-advertised inference URLs do not match the client; no compute started')
        print('PASS: deployed startup version and provider-advertised inference routes match.',flush=True)
    if not (app.get('configured') is True and app.get('operator') is True and app.get('enabled') is False
            and app.get('state')=='off' and app.get('can_start') is True):
        raise SetupError('App must be configured, off, operator-accessible and budget-enabled before this test')
    if app.get('model')!=expected['env']['MODEL_REPOSITORY']:
        raise SetupError('App model does not match the pinned baseline')
    total = number(app.get('demo_inference_allowance_usd'))
    limit = number(app.get('compute_allowance_usd'))
    reserved = number(app.get('demo_compute_reserved_usd'))
    if total!=approved_total or limit!=compute_limit or reserved!=prior_reserved:
        raise SetupError('App allowance or reservation does not match the verified attempt history')
    next_reservation=rate*Decimal(570)/Decimal(3600)
    if reserved+next_reservation>limit:
        raise SetupError('Remaining compute allowance cannot cover another bounded request')
    print(f'PASS: retaining ${reserved} in previous reservations; next request reserves about ${next_reservation}.',flush=True)
    print(f'PASS: current reported account spend ${before}; GPU rate ${rate}/hour before storage/tax.', flush=True)
    print(f'One synthetic app warm-up; shutdown deadline {DEADLINE} seconds. Six-minute compute estimate ${rate/10}.', flush=True)
    print('Keep this terminal and its network connection open. This is not a provider-enforced dollar cap.', flush=True)
    return before, rate


def rehearse(api, web, state, expected, destination, before, rate,
             clock=time.monotonic, sleep=time.sleep, timer_factory=threading.Timer,
             prior_reserved=Decimal('0'),observer=None):
    if destination.exists() and json.loads(destination.read_text()).get('start_attempted'):
        raise SetupError('A paid rehearsal was already attempted. Reconcile its saved report before another attempt.')
    route = '/v2/serverless/'+resource_id(state['endpoint_id'])
    report = {'endpoint_id': state['endpoint_id'], 'recorded_at': datetime.now(timezone.utc).isoformat(),
              'model_kind': 'upstream_baseline_not_fine_tuned', 'model_revision': expected['env']['MODEL_REVISION'],
              'start_attempted': False, 'generation_verified': False, 'provider_shutdown_verified': False,
              'app_shutdown_verified': False, 'rss_bytes': None, 'result': 'CHECK',
              'account_billing_before_usd': str(before), 'gpu_rate_usd_per_hour': str(rate),
              'deadline_seconds': DEADLINE, 'financial_hard_cap': False,'worker_image':expected['image']}
    report['prior_compute_reserved_usd']=str(prior_reserved)
    save(destination, report)
    watchdog_result = {}

    def disable():
        api.call(route, 'PATCH', {'workers': {'min': 0, 'max': 0, 'idleTimeout': 300}})

    def watchdog():
        print('NOTICE: warm-up deadline reached; requesting zero workers directly from Runpod.', flush=True)
        try: disable(); watchdog_result['patch_accepted'] = True
        except Exception: watchdog_result['patch_accepted'] = False

    timer = timer_factory(DEADLINE, watchdog)
    timer.daemon = True
    start = clock()
    stage = 'start_request'
    try:
        # Persist intent before sending. A lost POST response must never trigger another Start.
        report['start_attempted'] = True; save(destination, report)
        timer.start()
        if observer:observer.start()
        web.call('/api/model/start', 'POST')
        while clock()-start<DEADLINE:
            stage = 'warmup_status_read'
            status = web.call('/api/model/status')
            report['last_app_status'] = safe_app_state(status)
            phase = status.get('state')
            if phase not in ('starting','loading','ready','idle','error','off','stopping','unavailable','processing'):
                raise SetupError('App returned an unknown model state')
            print('Model state:', phase, flush=True)
            report['last_app_state'] = phase
            if phase in ('ready','idle'):
                if status.get('artifact_revision')!=expected['env']['MODEL_REVISION']:
                    raise SetupError('Warm-up artifact revision mismatch')
                reserved = number(status.get('demo_compute_reserved_usd'))
                if reserved<=prior_reserved or reserved>budget_policy(state)[2]:
                    raise SetupError('Warm-up reservation was not confirmed')
                report.update(generation_verified=True, compute_reserved_usd=str(reserved))
                save(destination, report)
                print('PASS: app verified warm-up generation and pinned model revision.', flush=True)
                break
            if phase not in ('starting','loading'):
                raise SetupError('Warm-up did not reach ready; stopping without retry')
            sleep(5)
        if not report['generation_verified']: raise SetupError('Warm-up exceeded six minutes')
    except (Exception, KeyboardInterrupt) as exc:
        # Save only our static failure category, never provider/model contents.
        report['failure'] = 'interrupted' if isinstance(exc, KeyboardInterrupt) else 'warmup_failed_or_uncertain'
        report['failure_stage'] = stage
        if isinstance(exc, AppRequestError):
            report['app_http_status'] = exc.status
            if exc.diagnostic:
                report['provider_diagnostic']=exc.diagnostic
                print('Provider diagnostic: '+exc.diagnostic,flush=True)
        print('CHECK: warm-up failed at '+stage+
              ('; HTTP '+str(exc.status) if isinstance(exc, AppRequestError) and exc.status else '')+
              '. Stopping without a paid retry.', flush=True)
    finally:
        if observer:
            try:
                report['observed_worker_ids']=observer.capture()
                report['worker_observation_file']=observer.destination.name
                from pilot.worker_diagnostics import PREFIX,safe_record
                diagnostics=[]
                for source in getattr(observer,'report',{}).get('log_sources',[]):
                    for event in source.get('events',[]):
                        value=event.get('worker_diagnostic')
                        safe=safe_record(PREFIX+json.dumps(value)) if isinstance(value,dict) else None
                        if safe and safe['event']=='failure':diagnostics.append(safe)
                if diagnostics:
                    report['worker_failure_diagnostics']=diagnostics[-8:]
                    for value in diagnostics[-8:]:print('Worker diagnostic: '+json.dumps(value),flush=True)
            except Exception:report['worker_log_capture_unconfirmed']=True
        print('Stopping the model through the app and verifying Runpod shutdown…', flush=True)
        try: web.call('/api/model/stop', 'POST')
        except Exception as exc:
            report['app_stop_request_unconfirmed'] = True
            if isinstance(exc, AppRequestError): report['app_stop_http_status'] = exc.status
        # Also request zero directly if Render failed or returned before the workers exited.
        for _ in range(3):
            try: disable(); break
            except Exception: sleep(2)
        end = clock()+180
        while clock()<end:
            try:
                verify_disabled(api.call(route), expected)
                verify_no_workers(api.call(route+'/workers'))
                report['provider_shutdown_verified'] = True
            except Exception: report['provider_shutdown_verified'] = False
            try:
                status = web.call('/api/model/status')
                report['shutdown_app_status'] = safe_app_state(status)
                report['app_shutdown_verified'] = status.get('state')=='off' and status.get('enabled') is False
            except Exception as exc:
                report['app_shutdown_verified'] = False
                if isinstance(exc, AppRequestError): report['shutdown_status_http_status'] = exc.status
            if report['provider_shutdown_verified'] and report['app_shutdown_verified']: break
            sleep(5)
        timer.cancel()
        if timer.is_alive(): timer.join(timeout=35)
        report['watchdog'] = watchdog_result
        report['elapsed_seconds'] = round(clock()-start, 2)
        try:
            after = billed_amount(api.call(BILLING))
            report['account_billing_after_usd'] = str(after)
            report['reported_billing_delta_usd'] = str(max(Decimal(0), after-before))
            ceiling,approved_total,_=budget_policy(state)
            report['reported_billing_within_allowance'] = after<ceiling and after-before<=approved_total
        except Exception: report['billing_after_unverified'] = True
        report['billing_may_lag'] = True
        if (all(report[k] for k in ('generation_verified','provider_shutdown_verified','app_shutdown_verified'))
                and report.get('reported_billing_within_allowance') is True):
            report['result'] = 'PASS'
        save(destination, report)
        # Read back the result artifact before returning; it is evidence, not model weights.
        if json.loads(destination.read_text())!=report: raise SetupError('Saved rehearsal report verification failed')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('origin')
    parser.add_argument('--run-warmup', action='store_true', help='Submit exactly one potentially billable app warm-up')
    parser.add_argument('--after-reconciliation',action='store_true',
                        help='One follow-up after the verified original recovery; preserves both reports and reservation')
    parser.add_argument('--after-startup-fix',action='store_true',
                        help='One verification of the deployed paused-rejection fix after both recoveries')
    parser.add_argument('--after-worker-start',action='store_true',
                        help='Verify the invoke-worker startup release after the manual worker test and clean shutdown')
    parser.add_argument('--retry-long-startup',action='store_true',
                        help='One explicitly requested retry with 180-second startup, retained reservations and live worker-ID capture')
    parser.add_argument('--diagnostic-worker',action='store_true',help='One attempt with the updated diagnostic image after audited closed-hold settlement')
    parser.add_argument('--loader-diagnostic',action='store_true',help='One attempt with redacted loader reasons after the audited paused-hold settlement')
    parser.add_argument('--compiler-fix',action='store_true',help='One test of the reviewed compiler-fixed image with the committed extra-dollar allowance')
    args = parser.parse_args()
    if sum((args.after_reconciliation,args.after_startup_fix,args.after_worker_start,args.retry_long_startup,args.diagnostic_worker,args.loader_diagnostic,args.compiler_fix))>1:
        raise SetupError('Select only one attempt mode')
    origin = validate_origin(args.origin)
    if not args.run_warmup:
        print('Preview: one app warm-up, six-minute shutdown timer, no paid retry. Add --run-warmup to execute.')
        return
    if not sys.stdin.isatty(): raise SetupError('Run in an interactive terminal for hidden app password entry')
    destination = ROOT/'artifacts/runpod-warmup-rehearsal.json'
    if args.after_reconciliation:
        destination=ROOT/'artifacts/runpod-warmup-followup.json'
    elif args.after_startup_fix:
        destination=ROOT/'artifacts/runpod-warmup-startup-fix.json'
    elif args.after_worker_start:
        destination=ROOT/'artifacts/runpod-warmup-activation.json'
    elif args.retry_long_startup:
        destination=ROOT/'artifacts/runpod-warmup-long-startup.json'
    elif args.diagnostic_worker:
        destination=ROOT/'artifacts/runpod-warmup-diagnostic.json'
    elif args.loader_diagnostic:
        destination=ROOT/'artifacts/runpod-warmup-loader-diagnostic.json'
    elif args.compiler_fix:
        destination=ROOT/'artifacts/runpod-warmup-compiler-fix.json'
    with (ROOT/'artifacts/runpod-disabled-setup.lock').open('a') as lock:
        try: fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise SetupError('Another setup/rehearsal is running') from None
        if destination.exists() and json.loads(destination.read_text()).get('start_attempted'):
            raise SetupError('Rehearsal already attempted; retain its report and reconcile before any new paid work')
        journal = ROOT/'artifacts/runpod-disabled-setup.json'
        state = json.loads(journal.read_text())
        if state.get('phase')!='disabled_verified': raise SetupError('Disabled setup must be verified first')
        connection = json.loads((ROOT/'artifacts/runpod-connection-verification.json').read_text())
        if connection.get('endpoint_id')!=state['endpoint_id'] or connection.get('control_write_verified') is not True:
            raise SetupError('Dedicated control-key verification is missing')
        private = credentials(ROOT/'deploy/cloud.env')
        api = API(private['RUNPOD_API_KEY'])  # Local billing/fallback only; never sent to Render.
        plan = json.loads((ROOT/'artifacts/runpod-connection-plan.json').read_text())
        expected = payload(plan, private['R2_ACCOUNT_ID'], state['registry_id'], state['endpoint_name'])
        prior_reserved=reconciled_reservation(ROOT,state,expected) if args.after_reconciliation else Decimal('0')
        if args.after_startup_fix: prior_reserved=startup_fix_reservation(ROOT,state,expected)
        if args.after_worker_start: prior_reserved=worker_start_reservation(ROOT,state,expected)
        if args.retry_long_startup:prior_reserved=long_startup_reservation(ROOT,state,expected)
        if args.diagnostic_worker:prior_reserved=diagnostic_reservation(ROOT,state,expected)
        if args.loader_diagnostic:prior_reserved=loader_reservation(ROOT,state,expected)
        if args.compiler_fix:prior_reserved=compiler_reservation(ROOT,state,expected)
        web = Web(origin)
        username = input('Pilot username [reviewer]: ').strip() or 'reviewer'
        password = getpass.getpass('Pilot password (hidden): ')
        try:
            web.login(username, password); password = None
            before, rate = preflight(api, web, state, expected, journal,prior_reserved,
                                    'invoke-worker-v2' if args.retry_long_startup or args.diagnostic_worker or args.loader_diagnostic or args.compiler_fix else 'invoke-worker-v1' if args.after_worker_start else None)
            observer=None
            if args.retry_long_startup or args.diagnostic_worker or args.loader_diagnostic or args.compiler_fix:
                from worker_observer import WorkerObserver
                observer=WorkerObserver(api,state,destination.with_name(
                    'runpod-compiler-fix-workers.json' if args.compiler_fix else
                    'runpod-loader-diagnostic-workers.json' if args.loader_diagnostic else
                    'runpod-diagnostic-workers.json' if args.diagnostic_worker else 'runpod-long-startup-workers.json'))
            report = rehearse(api, web, state, expected, destination, before, rate,prior_reserved=prior_reserved,observer=observer)
            if report.get('account_billing_after_usd'):
                account_for_history(number(report['account_billing_after_usd']), state); save(journal, state)
            print('Saved and read-back verified:', destination)
            print('Generation:', report['generation_verified'], '| Provider stopped:', report['provider_shutdown_verified'],
                  '| App off:', report['app_shutdown_verified'])
            if report['result']!='PASS':
                raise SetupError('Rehearsal incomplete. Do not retry Start. If shutdown is unconfirmed, set endpoint min/max=0 in Runpod and inspect workers immediately.')
            print('PASS: one synthetic app warm-up and verified zero-worker shutdown. RAM and model quality remain unverified.')
            print('Worker shutdown is verified. Billing may lag; reconcile before more work.')
        finally:
            print('Budget approval may remain 1 as requested. Keep the existing dollar limits; do not repeat paid attempts blindly.',flush=True)
            try: web.call('/api/auth/logout', 'POST')
            except Exception: print('NOTICE: rehearsal-session logout not confirmed; session expires automatically.')


if __name__=='__main__':
    try: main()
    except (SetupError, PreparationError, DiagnosticError) as exc: raise SystemExit('CHECK: '+str(exc)) from None
    except (OSError, ValueError, KeyError, TypeError, EOFError, KeyboardInterrupt):
        raise SystemExit('CHECK: interrupted or local data invalid. Inspect the saved rehearsal report and Runpod worker state; do not retry paid work.') from None
