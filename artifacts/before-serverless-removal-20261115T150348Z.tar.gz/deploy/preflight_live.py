"""Read-only deployment preflight. Never creates compute or prints credentials."""
from datetime import datetime,timezone
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import urllib.error
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None


def candidates(data):
    if not isinstance(data,dict) or not isinstance(data.get('gpus'),list):
        raise ValueError('Unexpected catalog shape')
    result=[]
    for gpu in data['gpus']:
        if not isinstance(gpu,dict):continue
        if gpu.get('manufacturer')!='NVIDIA' or gpu.get('memory') not in (16,24) or not gpu.get('pool'):continue
        rate=gpu.get('price',{}).get('serverless')
        # Pod rental prices must never substitute for a missing serverless rate.
        if type(rate) not in (int,float) or not math.isfinite(rate) or rate<=0:continue
        result.append({'gpu':gpu.get('name',gpu.get('id','Unknown')),
                       'pool':gpu['pool'],'vram_gb':gpu['memory'],
                       'serverless_usd_per_hour':rate,
                       'stock':gpu.get('availability','UNKNOWN'),
                       'data_centers':[{'id':dc.get('id'),'stock':dc.get('availability','UNKNOWN')}
                                       for dc in gpu.get('dataCenters',[]) if isinstance(dc,dict)]})
    return sorted(result,key=lambda row:row['serverless_usd_per_hour'])


def command_succeeds(command):
    try:
        return subprocess.run(command,capture_output=True,text=True,timeout=12).returncode==0
    except (OSError,subprocess.SubprocessError):return False


def main():
    report={'checked_at':datetime.now(timezone.utc).isoformat(),'resources_created':False}
    report['docker_engine_ready']=command_succeeds(['docker','info','--format','{{.OSType}}/{{.Architecture}}'])
    report['docker_buildx_ready']=command_succeeds(['docker','buildx','version'])
    report['python_dependencies']={name:bool(importlib.util.find_spec(name))
                                    for name in ('fastapi','httpx','psycopg','uvicorn','boto3')}
    report['free_disk_gb']=round(shutil.disk_usage(Path(__file__).resolve().parents[1]).free/1e9,1)
    print('Docker engine:', 'PASS' if report['docker_engine_ready'] else 'UNAVAILABLE')
    print('Docker buildx:', 'PASS' if report['docker_buildx_ready'] else 'UNAVAILABLE')
    print('Free local disk:',report['free_disk_gb'],'GB')
    print('Python packages:',', '.join(name+'='+('available' if yes else 'missing')
                                    for name,yes in report['python_dependencies'].items()))
    token=os.environ.get('RUNPOD_API_KEY')
    if not token:raise SystemExit('RUNPOD_API_KEY missing. Load deploy/cloud.env in this terminal first.')
    query='?include=AVAILABILITY&product=SERVERLESS&cloud=SECURE&count=1&minCudaVersion=12.8'
    request=urllib.request.Request('https://api.runpod.io/v2/catalog/gpus'+query,
        headers={'Authorization':'Bearer '+token,'Accept':'application/json'})
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    try:
        with opener.open(request,timeout=20) as response:
            raw=response.read(4*1024*1024+1)
            if len(raw)>4*1024*1024:raise ValueError()
            report['gpu_candidates']=candidates(json.loads(raw))
    except urllib.error.HTTPError as exc:
        raise SystemExit(f'Catalog check failed: HTTP {exc.code}. Body withheld; no resources changed.') from None
    except (OSError,ValueError,TypeError):
        raise SystemExit('Catalog check failed: network or response error. No resources changed.') from None
    print('Serverless GPU catalog: PASS (one GPU, CUDA floor 12.8)')
    if not report['gpu_candidates']:print('No matching 16–24 GB NVIDIA GPUs with serverless pricing returned.')
    for gpu in report['gpu_candidates']:
        print(f"{gpu['gpu']} | {gpu['vram_gb']} GB | pool {gpu['pool']} | ${gpu['serverless_usd_per_hour']}/hour | stock {gpu['stock']}")
    path=Path(__file__).resolve().parents[1]/'artifacts/runpod-preflight.json'
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(report,indent=2)+'\n')
    print('Public catalog/build-readiness report saved:',path)
    print('No compute started, no inference submitted, no provider resources changed.')


if __name__=='__main__':main()
