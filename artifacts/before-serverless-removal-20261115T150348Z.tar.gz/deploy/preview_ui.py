"""Build the standalone UI preview. No server, credentials or network calls."""
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
STATIC=ROOT/'pilot/static'


def main():
    page=(STATIC/'index.html').read_text()
    page=re.sub(r'<link rel="stylesheet" href="/([a-z-]+\.css)">',
                lambda match:'<style>'+(STATIC/match[1]).read_text()+'</style>',page)
    page=re.sub(r'<script src="/[a-z.-]+" defer></script>','',page)
    controls='''<div class="preview-notice">INTERFACE PREVIEW · No server or GPU connection. These buttons only preview animation states.</div>
<p><button class="secondary" data-preview="off">Orb off</button> <button class="secondary" data-preview="loading">Preview loading</button> <button class="secondary" data-preview="processing">Preview generating</button> <button class="secondary" data-preview="ready">Preview ready</button></p>'''
    page=page.replace('<main id="main">','<main id="main">'+controls)
    page=page.replace('Checking connection…','Not connected · visual preview')
    page=page.replace('Checking services…','UI preview').replace('Loading cases…','No cases loaded in this offline preview.')
    page=page.replace('<button class="primary" id="create-button">','<button class="primary" id="create-button" disabled>')
    script=(STATIC/'orb.js').read_text()+'''
document.querySelectorAll('[data-preview]').forEach(b=>b.onclick=()=>{PolicyOrb.set(b.dataset.preview);document.getElementById('model-status').textContent='Animation preview: '+b.dataset.preview+' · no GPU activity';});
for(const [button,dialog] of [['new-case','new-dialog'],['about','about-dialog']])document.getElementById(button).onclick=()=>document.getElementById(dialog).showModal();
for(const [button,dialog] of [['close-dialog','new-dialog'],['close-about','about-dialog']])document.getElementById(button).onclick=()=>document.getElementById(dialog).close();
document.getElementById('create-form').onsubmit=e=>e.preventDefault();
'''
    page=page.replace('</body>','<script>'+script+'</script></body>')
    output=ROOT/'artifacts/policypilot-ui-preview.html'
    output.parent.mkdir(exist_ok=True)
    output.write_text(page)
    print('Standalone UI preview saved:',output)


if __name__=='__main__':main()
