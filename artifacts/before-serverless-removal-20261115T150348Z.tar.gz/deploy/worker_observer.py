"""Observe worker IDs and collect safe startup-log signals without mutating Runpod."""
from datetime import datetime,timezone
import threading

from create_runpod_disabled import resource_id,save,SetupError
from inspect_runpod_attempt import worker_log_read


class WorkerObserver:
    def __init__(self,api,state,destination):
        self.api=api;self.state=state;self.destination=destination
        self.done=threading.Event();self.lock=threading.Lock();self.thread=None
        self.report={'endpoint_id':state['endpoint_id'],'requests_submitted':0,
                     'resources_changed':False,'raw_logs_saved':False,'workers':{},'log_sources':[]}

    def sample(self):
        data=self.api.call('/v2/serverless/'+resource_id(self.state['endpoint_id'])+'/workers')
        rows=data.get('workers')
        if not isinstance(rows,list):raise SetupError('Worker list missing')
        now=datetime.now(timezone.utc).isoformat()
        with self.lock:
            for row in rows[:4]:
                if not isinstance(row,dict):continue
                wid=resource_id(row.get('id'))
                if wid not in self.report['workers'] and len(self.report['workers'])>=4:continue
                item=self.report['workers'].setdefault(wid,{'first_observed_at':now})
                item['last_observed_at']=now
                if row.get('status') in ('RUNNING','IDLE','INITIALIZING','THROTTLED','UNHEALTHY','STARTING','EXITED'):
                    item['last_status']=row['status']
            self.report['last_sample_at']=now
            save(self.destination,self.report)

    def _loop(self):
        while not self.done.is_set():
            try:self.sample()
            except Exception:
                with self.lock:
                    self.report['worker_read_failed']=True;save(self.destination,self.report)
                return
            if self.done.wait(5):return

    def start(self):
        save(self.destination,self.report)
        self.thread=threading.Thread(target=self._loop,daemon=True);self.thread.start()

    def capture(self):
        self.done.set()
        if self.thread:self.thread.join(timeout=1)
        with self.lock:ids=list(self.report['workers'])[:2]
        # At most two worker IDs, two sources each. Keep each read short; the
        # independent financial watchdog remains active during this collection.
        for wid in ids:
            for source in ('system','container'):
                result=worker_log_read(self.api,self.state,wid,source,duration=5)
                with self.lock:
                    self.report['log_sources'].append({'worker_id':wid,**result})
                    save(self.destination,self.report)
                if result.get('read_verified') is not True:return ids
        return ids
