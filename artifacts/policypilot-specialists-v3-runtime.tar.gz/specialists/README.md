# Small task networks: remote execution only

This is training preparation for two task-specific networks: a character-CNN /
BiLSTM source-span tagger and an MLP evidence relevance scorer. There is no
pretrained language backbone, next-token training, SLM or LLM in this module.
No specialist model has been trained or deployed yet.

The standard-library preparation and checks do not import a neural runtime,
download weights or run models on the user's computer. Actual training, model
reload, inference and memory profiling are restricted to the remote Pod. The live
app still has processing disabled and is not automatically changed by these tools.

## Preparation and custody

From the project source:

```sh
python -m specialists.prepare --version v3
python -m specialists.run
python -m unittest discover -s specialists/tests -v
```

Preparation writes:

- `data/synthetic/specialists-v1/`: synthetic train/validation span and rank labels,
  with hashes, split metadata and explicit limitations.
- `evaluation/specialists-v1/`: final held-out labels. Keep separate from training.
- `artifacts/policypilot-specialists-v3-runtime.tar.gz` (use `--version v3`):
  verified source plus only
  train/validation data. It excludes the reconstructing generator, tests and final
  held-out labels, all secrets and the earlier language-model training pipeline.

Existing outputs are verified/reused only when identical. Changed source needs a
new archive `--version`, rather than overwriting an earlier receipt. Dataset
generation changes require a separately versioned dataset location/code change.
No archive is extracted by the verifier. Archive contents and hashes are checked
by read-back; this is source packaging, not model accuracy or model execution.

The original English synthetic text has eight authored layout/wording families,
split 4 train / 2 validation / 2 final test, with disjoint case IDs. The families
still share synthetic semantics and generation logic. Case variants are not
independent real examples. This does not test PDF extraction, OCR or real claims.
Labels define relevant versus irrelevant evidence explicitly; a relevant clause
does not establish that it applies or authorizes coverage.

## Remote run after provider/budget checks

Before a paid run, verify current Runpod access, a fresh compatible GPU quote
strictly below USD 1/hour and the remaining experiment allowance after historical
spend, retained reservations, startup/idle, storage/tax and shutdown overhead.
Existing experiment and recurring storage authorizations are unchanged. No new
Pod, network volume or subscription is provisioned by this package.

Use the verified source bundle on an existing Pod with the project and data under
a mounted `/workspace`. The provider's `RUNPOD_POD_ID` must be present. These guards
prevent accidental local execution; they are not cryptographic cloud attestation.
Review the Pod's PyTorch/CUDA/driver compatibility before installing anything.
If a reviewed compatible environment is unavailable, stop instead of repeatedly
burning paid startup time. The provided CUDA 12.8 requirements are a candidate
stack, not a verified installation on a particular provider GPU.

Commands below belong in the **remote Pod's terminal**, after copying/verifying
the runtime bundle and its checksum. Do not run the installation locally:

```sh
cd /workspace/PolicyPilot
python -c "import os; from pathlib import Path; assert os.environ.get('RUNPOD_POD_ID') and os.path.ismount('/workspace') and Path.cwd().is_relative_to('/workspace')"
# Only if the reviewed Pod environment needs this stack:
python -m pip install -r specialists/requirements-cu128.txt
python -B -m specialists.run
```

After reviewing the plan, use the actual quoted rate and reconciled remaining
compute-only allowance. These values are deliberately not copied from stale bills:

```sh
python -B -m specialists.run --stage train --execute \
  --hourly-rate-usd ACTUAL_RATE_BELOW_ONE \
  --remaining-compute-usd ACTUAL_RECONCILED_ALLOWANCE \
  --max-seconds 300
```

Use only the freshly extracted runtime bundle as `/workspace/PolicyPilot`, with
no unrelated files, virtual environment or bytecode cache inside it. `-B` preserves
that frozen inventory. Config and dataset paths are bound to the verified bundle,
and each stage records the fingerprints of the exact bytes it consumes.

The single working deadline covers baseline, neural training and independent fresh-process
reload, with up to three seconds of child-stop grace also reserved in the compute
estimate. Children receive a restricted environment without provider API keys,
database, R2, GitHub or Hugging Face credentials. There are no retries. The launcher
stops its child process on timeout; **it does not stop or terminate the billed Pod**.
Do not leave paid compute running after the run or rely on this as a dollar cap.

Reports and state dicts stay under `/workspace/specialist-runs/run-*`, outside the
frozen source. A sibling `run-*.receipt.json` records completion only after archive
verification succeeds. A successful
training run requires both weight files within the byte target and independent
reload/prediction parity before manifest/package export. It does not establish
held-out quality, robust abstention or suitability for deployment. Validation
metrics are not production accuracy. Final testing must happen only after weights
and configuration are frozen, with the separate final labels kept out of training.

## Render and R2 deployment direction

The current existing Render web app was read back on 2026-11-18 as a Free service.
Its free instance has 512 MB RAM, sleeps after 15 idle minutes, and has ephemeral
local storage. Separate Render background workers do not have a free instance.
The existing deployment is web-only; enabling a queue does not create a worker.

R2 Standard includes 10 GB-month storage and operation allowances, shared with
other account usage. Small weights fit in that storage allowance when space
remains. R2 retains objects; it cannot execute the networks. Use a dedicated
private model-artifact bucket and bucket-scoped credentials, separate from source
PDFs and their cleanup lifecycle. No bucket is created or used by preparation.

Before starting the Pod, create or select a dedicated private Standard R2 model
bucket and prepare its bucket-scoped Object Read & Write key. Confirm the current
Pod quote, billed storage, and remaining experiment allowance in Runpod. Allow
time for startup, verification and backup in addition to training.

From the Pod terminal, after the launcher reports a completed run, run the backup
with the exact run archive path. The command uses the Pod's boto3 installation.
If the environment lacks it, install it on the Pod with
`python -m pip install boto3==1.43.127`.

```sh
python -B -m specialists.backup /workspace/specialist-runs/run-RUN_ID.tar.gz \
  --account-id YOUR_R2_ACCOUNT_ID --bucket YOUR_PRIVATE_MODEL_BUCKET
```

The command prompts for the two S3 keys without echoing them. It verifies the
completed training receipt, the archive and both weight members before uploading.
The R2 object key includes the archive's SHA-256, and the upload is conditional on
the key being absent. It reads the complete object back and compares its size and
checksum, then saves an `.r2.json` receipt beside the archive. Save the receipt
or its object key and SHA-256 before terminating the dedicated Pod and removing
temporary storage. Check the Pod and temporary volume are gone in the dashboard.
Keep the verified private R2 copy.

An inference deployment may download a pinned, checksum-verified artifact from R2
into an ephemeral cache on Render. Full runtime RAM, CPU latency and the combined
web/worker/OCR lifecycle must be measured on the intended instance. Weight size is
not runtime RAM. Do not add PyTorch to the live API or promise free-instance fit
from the parameter estimate. A lean CPU export may be evaluated after remote
reload works; no ONNX export/runtime has been verified here. No hosted mode or
generative worker has been replaced yet.

References: [R2 pricing](https://developers.cloudflare.com/r2/pricing/),
[R2 bucket-scoped credentials](https://developers.cloudflare.com/r2/get-started/s3/),
[R2 conditional writes](https://developers.cloudflare.com/r2/api/s3/api/),
[Render Free limits](https://render.com/docs/free),
[Render Docker instance sizes](https://render.com/hosting/docker).
