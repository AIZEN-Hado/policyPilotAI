"""Deterministic lexical encodings and source offsets for the specialists."""

import hashlib
from collections import Counter

from .contracts import DOCUMENT_KINDS, SPAN_LABELS, TOKEN_PATTERN


BIO_TAGS = ("O",) + tuple(
    f"{prefix}-{label}" for label in SPAN_LABELS for prefix in ("B", "I")
)
BIO_IDS = {tag: index for index, tag in enumerate(BIO_TAGS)}
PAD_ID = 0
WORD_HASH = b"pp-word-v1"
CHAR_HASH = b"pp-char-v1"
RANK_HASH = b"pp-rank-v1"

RANK_CUE_GROUPS = {
    "active": {"active", "applicable", "current", "effective", "operative"},
    "admission": {"admission", "admissions", "hospital", "inpatient", "overnight", "ward"},
    "cap": {"cap", "ceiling", "limit", "maximum", "threshold"},
    "excluded": {"archived", "expired", "historical", "optional", "superseded", "unrelated"},
    "paperwork": {
        "checklist", "document", "documents", "evidence", "form", "forms", "paperwork",
        "records", "submit",
    },
    "reimbursement": {"claim", "claims", "payment", "reimburse", "reimbursement"},
    "required": {"mandatory", "must", "prerequisite", "required", "requires"},
    "room": {"accommodation", "bed", "board", "room", "ward"},
}

RANK_SCALAR_NAMES = (
    "query_overlap", "document_overlap", "jaccard", "bigram_overlap",
    "all_query_terms_present", "query_length", "document_length", "document_has_digit",
) + tuple(f"kind_{kind}" for kind in DOCUMENT_KINDS) + tuple(
    f"{side}_{cue}" for cue in RANK_CUE_GROUPS for side in ("query", "document", "both")
)
RANK_MIN_FEATURES = len(RANK_SCALAR_NAMES) + 1


def _digest(value, domain):
    return int.from_bytes(
        hashlib.blake2b(value.encode("utf-8"), digest_size=8, person=domain).digest(),
        "big",
    )


def _embedding_id(value, buckets, domain):
    return 1 + _digest(value, domain) % (buckets - 1)


def tokenize_with_offsets(text):
    return [(match.group(), match.start(), match.end()) for match in TOKEN_PATTERN.finditer(text)]


def encode_span(row, config):
    """Align BIO targets to complete tokens without changing source coordinates."""
    tokens = tokenize_with_offsets(row["text"])
    if not tokens:
        raise ValueError("Span input has no tokens")
    if len(tokens) > config["max_tokens"]:
        raise ValueError(f"Span input exceeds {config['max_tokens']} tokens")
    if any(len(token) > config["max_chars_per_token"] for token, _, _ in tokens):
        raise ValueError(f"Span input has a token exceeding {config['max_chars_per_token']} characters")

    starts = {start: index for index, (_, start, _) in enumerate(tokens)}
    ends = {end: index for index, (_, _, end) in enumerate(tokens)}
    tags = [BIO_IDS["O"]] * len(tokens)
    for span in row["spans"]:
        start = starts.get(span["start"])
        end = ends.get(span["end"])
        label = span["label"]
        if start is None or end is None or start > end or label not in SPAN_LABELS:
            raise ValueError("Invalid token boundaries or label for span target")
        if any(tags[index] != BIO_IDS["O"] for index in range(start, end + 1)):
            raise ValueError("Span targets overlap")
        tags[start] = BIO_IDS[f"B-{label}"]
        for index in range(start + 1, end + 1):
            tags[index] = BIO_IDS[f"I-{label}"]

    return {
        "word_ids": [
            _embedding_id(token.casefold(), config["word_hash_buckets"], WORD_HASH)
            for token, _, _ in tokens
        ],
        "char_ids": [
            [_embedding_id(char, config["char_vocab_size"], CHAR_HASH) for char in token]
            for token, _, _ in tokens
        ],
        "tags": tags,
        "offsets": [(start, end) for _, start, end in tokens],
    }


def decode_spans(text, offsets, tag_ids):
    """Emit spans begun by B tags and discard spans with mismatched continuations."""
    if len(offsets) != len(tag_ids):
        raise ValueError("Token offsets and BIO predictions have different lengths")

    spans = []
    active = None
    previous_end = 0
    for (start, end), tag_id in zip(offsets, tag_ids):
        if not previous_end <= start < end <= len(text):
            raise ValueError("Token offsets are out of source order or bounds")
        previous_end = end
        if not 0 <= tag_id < len(BIO_TAGS):
            raise ValueError("Unknown BIO tag ID")
        prefix, _, label = BIO_TAGS[tag_id].partition("-")
        if prefix == "I":
            if active is not None and active["label"] == label:
                active["end"] = end
            else:
                active = None
            continue
        if active is not None:
            spans.append(active)
            active = None
        if prefix == "B":
            active = {"label": label, "start": start, "end": end}
    if active is not None:
        spans.append(active)
    for span in spans:
        span["value"] = text[span["start"]:span["end"]]
    return spans


def lexical_terms(text):
    return [token.casefold() for token, _, _ in tokenize_with_offsets(text) if token.isalnum()]


def ranking_features(query, text, kind, config):
    """Build scalar overlap/cue features and signed hashed lexical features."""
    size = config["features"]
    if size < RANK_MIN_FEATURES or kind not in DOCUMENT_KINDS:
        raise ValueError("Invalid ranking feature size or document kind")

    query_terms = lexical_terms(query)
    doc_terms = lexical_terms(text)
    query_set = set(query_terms)
    doc_set = set(doc_terms)
    shared = query_set & doc_set
    query_bigrams = set(zip(query_terms, query_terms[1:]))
    doc_bigrams = set(zip(doc_terms, doc_terms[1:]))
    values = [
        len(shared) / max(1, len(query_set)),
        len(shared) / max(1, len(doc_set)),
        len(shared) / max(1, len(query_set | doc_set)),
        len(query_bigrams & doc_bigrams) / max(1, len(query_bigrams)),
        float(bool(query_terms) and all(token in doc_set for token in query_terms)),
        min(len(query_terms) / 64, 1.0),
        min(len(doc_terms) / 256, 1.0),
        float(any(char.isdigit() for char in text)),
    ]
    values.extend(float(kind == known_kind) for known_kind in DOCUMENT_KINDS)
    for cue in RANK_CUE_GROUPS.values():
        query_match = bool(query_set & cue)
        doc_match = bool(doc_set & cue)
        values.extend((float(query_match), float(doc_match), float(query_match and doc_match)))

    tail = [0.0] * (size - len(values))
    channels = ("query", query_terms), ("document", doc_terms), ("shared", sorted(shared))
    for channel, terms in channels:
        for token, count in Counter(terms).items():
            hashed = _digest(f"{channel}:{token}", RANK_HASH)
            sign = 1 if hashed >> 63 else -1
            tail[hashed % len(tail)] += sign * count / len(terms)
    return values + tail


def feature_spec():
    return {
        "token_pattern": TOKEN_PATTERN.pattern,
        "offset_unit": "python_unicode_codepoint",
        "pad_id": PAD_ID,
        "bio_tags": list(BIO_TAGS),
        "document_kinds": list(DOCUMENT_KINDS),
        "hash": {
            "algorithm": "blake2b-64",
            "encoding": "utf-8",
            "byte_order": "big",
            "word_domain": WORD_HASH.decode(),
            "char_domain": CHAR_HASH.decode(),
            "rank_domain": RANK_HASH.decode(),
            "word_casefold": True,
            "char_casefold": False,
            "embedding_id_rule": "1 + hash % (buckets - 1)",
            "rank_channels": ["query", "document", "shared"],
            "rank_key_format": "channel:term",
            "rank_signed_by_high_bit": True,
        },
        "rank_scalar_features": list(RANK_SCALAR_NAMES),
        "rank_cue_groups": {name: sorted(cues) for name, cues in RANK_CUE_GROUPS.items()},
    }
