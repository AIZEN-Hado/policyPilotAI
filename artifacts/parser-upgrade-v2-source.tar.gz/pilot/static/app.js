'use strict';
const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
let cases = [], active = null, selected = null, poll = null, loading = false, processingAvailable = false;
const labels = {draft:'Draft',queued:'Queued',processing:'Processing',ready:'Review required',failed:'Needs attention'};
const badge = state => `<span class="badge ${esc(state)}">${esc(labels[state] || state)}</span>`;
function message(text, error=false) { $('message').textContent=text; $('message').className=text?(error?'error':'success'):''; }
async function api(path,options={}) {
 const response=await fetch('/api'+path,{credentials:'same-origin',...options});
 if(response.status===401){location.replace('/login');throw Error('Please sign in to continue.');}
 if(!response.ok){let data;try{data=await response.json();}catch{throw Error('The service did not respond. Check your connection.');}throw Error(typeof data.detail==='string'?data.detail:'Please check the supplied fields.');}
 return response.status===204?null:response.json();
}
function renderList(){
 const query=$('search').value.toLowerCase(); const filtered=cases.filter(c=>c.title.toLowerCase().includes(query));
 $('total').textContent=cases.length;$('ready').textContent=cases.filter(c=>c.state==='ready').length;$('processing').textContent=cases.filter(c=>['queued','processing'].includes(c.state)).length;$('failed').textContent=cases.filter(c=>c.state==='failed').length;
 $('case-list').innerHTML=filtered.length?filtered.map(c=>`<button class="case-row" data-case="${esc(c.id)}"><span><strong>${esc(c.title)}</strong><small>${esc(c.id.slice(0,8).toUpperCase())} · Health insurance</small></span>${badge(c.state)}<span class="date small">${esc(new Date(c.created_at).toLocaleDateString('en-IN'))}</span><span>→</span></button>`).join(''):`<div class="empty"><strong>${query?'No matching cases.':'Your workspace is ready.'}</strong><p>${query?'Try a different title.':'Create a case and attach its policy and claim documents to start.'}</p></div>`;
}
async function refreshList(){cases=await api('/cases');renderList();}
async function openCase(id){
 const row=await api('/cases/'+id); if(active&&active.id!==id)selected=null;
 active=row;$('overview').hidden=true;$('detail').hidden=false;renderCase();
 clearTimeout(poll);poll=setTimeout(tick,['queued','processing'].includes(active.state)?3000:10000);
}
async function tick(){if(!active||loading)return;try{await openCase(active.id);}catch(e){message(e.message,true);poll=setTimeout(tick,10000);}}
function renderCase(){
 document.dispatchEvent(new CustomEvent("policy:case",{detail:{id:active.id,processed:active.documents.length>0&&active.documents.every(d=>d.pages)}}));
 const busy=['queued','processing'].includes(active.state);
 $('case-id').textContent='CASE / '+active.id.slice(0,8).toUpperCase();$('case-title').textContent=active.title;$('case-description').textContent=active.description;$('case-state').innerHTML=badge(active.state);
 $('run').disabled=busy||!processingAvailable;$('run').textContent=!processingAvailable?'Model not connected':busy?'Processing in background…':active.state==='failed'?'Retry processing':'Process & assess';$('upload-button').disabled=busy||loading;$('delete-case').disabled=busy;$('acknowledge').disabled=active.state!=='ready';
 $('case-error').hidden=!active.error;$('case-error').textContent=active.error||'';
 $('doc-count').textContent=active.documents.length+' / 12';
 if(!selected&&active.documents.length)selected=active.documents[0].id;
 $('documents').innerHTML=active.documents.length?active.documents.map(d=>`<button class="doc-button ${d.id===selected?'selected':''}" data-doc="${esc(d.id)}"><span>${esc(d.kind)} · ${d.pages?d.pages.length+' pages':'Awaiting extraction'}</span>${esc(d.filename)}</button>`).join(''):'<p class="empty">Attach this claim’s documents below.</p>';
 renderSource();
 const result=active.result;
 $('result').innerHTML=result?`<p class="small">LIVE MODEL OUTPUT · ${esc(result.model)}</p><p>${esc(result.summary)}</p><p class="small">${esc(result.total_pages)} pages · ${esc(result.ocr_pages)} OCR pages</p>${result.context_truncated?'<div class="ocr-tag">Context limited: only selected excerpts were supplied.</div>':''}${result.evidence_coverage?.omitted_document_ids?.length?`<div class="ocr-tag">${esc(result.evidence_coverage.omitted_document_ids.length)} uploaded documents had no selected excerpts. Review their originals.</div>`:''}${result.findings.map(f=>`<article class="finding"><p>${esc(f.statement)}</p><blockquote>${esc(f.quote)}</blockquote>${f.needs_verification?'<p class="ocr-tag">Verify this source text against the original PDF.</p>':''}<button class="textbutton" data-evidence="${esc(f.document_id)}" data-page="${f.page}">${esc(f.filename)} · page ${f.page} ↗</button></article>`).join('')}${result.questions.length?'<h2>Verify before deciding</h2><ul class="question-list">'+result.questions.map(q=>`<li>${esc(q)}</li>`).join('')+'</ul>':''}<p class="small">${esc(result.notice)}</p>`:`<div class="empty"><canvas data-orb="draft" data-state="${busy?'processing':'off'}" width="90" height="90" aria-hidden="true"></canvas><br><strong>${busy?'Your documents are being processed.':'An evidence-backed draft starts here.'}</strong><p>${busy?'PDF extraction, OCR and private inference run on your server. This can take several minutes. You can return to the queue.':'Attach the policy wording, schedule and claim evidence, then select Process & assess.'}</p></div>`;
 $('events').innerHTML=active.events.map(e=>`<div class="event"><span>${esc(e.action.replaceAll('_',' '))}</span><span>${esc(e.actor)} · ${esc(new Date(e.created_at).toLocaleString('en-IN'))}</span></div>`).join('');
}
function renderSource(page){
 const doc=active.documents.find(d=>d.id===selected);$('download').hidden=!doc;
 if(!doc){$('source-title').textContent='Select a document';return;}
 $('source-title').textContent=doc.filename;$('download').href=`/api/cases/${active.id}/documents/${doc.id}`;
 $('source-content').innerHTML=doc.pages?doc.pages.map(p=>`<section class="page-text" id="page-${p.page}"><h3>Page ${p.page} · ${p.method==='ocr'?'Local OCR':'PDF text'}</h3>${p.needs_verification?'<div class="ocr-tag">Verify extracted text against the original.</div>':''}<pre>${esc(p.text||'No readable text found on this page.')}</pre></section>`).join(''):'<div class="empty"><strong>Original uploaded.</strong><p>Run processing to extract text. The original PDF is available to download.</p></div>';
 if(page)document.getElementById('page-'+page)?.scrollIntoView({block:'nearest'});
}
document.addEventListener('policy:connection',e=>{processingAvailable=Boolean(e.detail?.processing_enabled);if(active)renderCase();});
document.addEventListener('policy:evidence',e=>{if(!active)return;selected=e.detail.documentId;renderCase();renderSource(e.detail.page);});
async function back(){document.dispatchEvent(new CustomEvent('policy:case',{detail:null}));clearTimeout(poll);active=null;selected=null;$('detail').hidden=true;$('overview').hidden=false;await refreshList();}
const safely = fn => async event => {try{await fn(event);}catch(e){message(e.message,true);}};
$('sign-out').onclick=safely(async()=>{await api('/auth/logout',{method:'POST'});location.replace('/login');});
api('/auth/me').then(user=>{$('sign-out').hidden=user.auth_mode!=='session';}).catch(()=>{});
$('new-case').onclick=()=>$('new-dialog').showModal();$('close-dialog').onclick=()=>$('new-dialog').close();$('about').onclick=()=>$('about-dialog').showModal();$('close-about').onclick=()=>$('about-dialog').close();
$('home').onclick=safely(back);$('back').onclick=safely(back);$('search').oninput=renderList;
$('case-list').onclick=safely(async e=>{const b=e.target.closest('[data-case]');if(b){message('');await openCase(b.dataset.case);}});
$('documents').onclick=e=>{const b=e.target.closest('[data-doc]');if(b){selected=b.dataset.doc;renderCase();}};
$('result').onclick=e=>{const b=e.target.closest('[data-evidence]');if(b){selected=b.dataset.evidence;renderCase();renderSource(Number(b.dataset.page));}};
$('create-form').onsubmit=safely(async e=>{e.preventDefault();$('create-button').disabled=true;try{const row=await api('/cases',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:$('title').value,description:$('description').value})});$('new-dialog').close();e.target.reset();message('Case created. Attach the matching policy and claim documents.');await openCase(row.id);}finally{$('create-button').disabled=false;}});
$('upload-form').onsubmit=safely(async e=>{e.preventDefault();const file=$('file').files[0];if(!file)return;if(file.size>10*1024*1024)throw Error('Choose a PDF smaller than 10 MB.');const id=active.id;loading=true;$('upload-button').disabled=true;$('upload-button').textContent='Uploading…';try{await api(`/cases/${id}/documents?kind=${encodeURIComponent($('document-kind').value)}&filename=${encodeURIComponent(file.name)}`,{method:'PUT',headers:{'Content-Type':'application/pdf'},body:file});$('file').value='';message('Document attached. Previous draft results have been cleared.');await openCase(id);}finally{loading=false;$('upload-button').disabled=false;$('upload-button').textContent='Attach document';}});
$('run').onclick=safely(async()=>{$('run').disabled=true;try{await api(`/cases/${active.id}/assess`,{method:'POST'});message('Queued for live extraction and private inference.');await openCase(active.id);}finally{$('run').disabled=!processingAvailable||['queued','processing'].includes(active.state);}});
$('acknowledge').onclick=safely(async()=>{await api(`/cases/${active.id}/review`,{method:'POST'});message('Review acknowledgement saved. No coverage or payment was authorized.');await openCase(active.id);});
$('delete-case').onclick=safely(async()=>{if(!confirm('Delete this case? Access is removed immediately; uploaded files are queued for removal. Backups follow a separate retention policy.'))return;await api(`/cases/${active.id}`,{method:'DELETE'});await back();message('Case deleted. Uploaded files are queued for removal.');});
(async()=>{try{await refreshList();}catch(e){message(e.message,true);$('case-list').innerHTML='<p class="empty">Unable to load the workspace. Check server access and refresh.</p>';}try{const r=await api('/readiness');processingAvailable=Boolean(r.processing_enabled);$('readiness').textContent=r.inference==='registered'?'Model connection configured':r.inference==='disconnected'?'Documents available · model disconnected':'Model unavailable';}catch{$('readiness').textContent='Inference unavailable';}})();
